using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class DomainConnectionStringProvider : IDomainConnectionStringProvider
    {
        private readonly IDomainBusinessModule _domainModule;

        public DomainConnectionStringProvider(IDomainBusinessModule domainModule)
        {
            _domainModule = domainModule;
        }

        public string Get(string connectionStringName, int domainId)
        {
            var domain = _domainModule.GetDomain((EnumDomain)domainId);

            return $"{connectionStringName}_{domain.SiteCode}";
        }
    }
}
