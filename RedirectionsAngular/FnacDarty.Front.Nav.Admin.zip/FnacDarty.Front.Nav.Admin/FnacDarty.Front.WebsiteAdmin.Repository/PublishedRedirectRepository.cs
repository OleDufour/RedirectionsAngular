using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class PublishedRedirectRepository : PublishedRedirectRepositoryBase
    {
        protected override string GetPublishedRedirectsStoredProcedure
        {
            get { return "seo.sp_GetPublishedRedirects"; }
        }

        public PublishedRedirectRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }
    }
}
