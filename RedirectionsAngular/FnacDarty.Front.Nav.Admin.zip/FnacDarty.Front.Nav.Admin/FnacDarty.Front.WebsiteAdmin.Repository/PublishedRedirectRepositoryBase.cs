using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public abstract class PublishedRedirectRepositoryBase : BaseRepository, IPublishedRedirectRepository
    {

        protected abstract string GetPublishedRedirectsStoredProcedure { get; }

        public PublishedRedirectRepositoryBase(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }

        public IEnumerable<PublishedUrlRedirectDto> GetPublishedUrlRedirectDtos(string siteCode, string cultureCode)
        {
            return ExecuteSelect<PublishedUrlRedirectDto>(GetPublishedRedirectsStoredProcedure, new Dictionary<string, object>
            {
                {"SiteCode", siteCode},
                {"CultureCode", cultureCode}
            });
        }
    }
}
