using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public abstract class PublishedRewriteRepositoryBase : BaseRepository, IPublishedRewriteRepository
    {

        internal static readonly string GetUrlRewriteByIdSp = "seo.sp_GetRewriteById";
        internal static readonly string UpdateUrlRewriteSp = "seo.sp_UpdateRewrite";
        internal static readonly string AddUrlRewriteSp = "seo.sp_AddRewrite";
        internal static readonly string SearchSp = "seo.sp_GetRewriteResults";
        internal static readonly string DeleteUrlRewriteSp = "seo.sp_UpdateToDeleteRewrite";

        internal static readonly string GetUrlsByDomainSp = "seo.sp_GetRewriteByDomainId";
        internal static readonly string GetUrlsByPublicationDateSp = "seo.sp_GetModifiedRewrite";

        #region Validation

        internal static readonly string GetUrlRewritesByRewrittenUrlSp = "seo.sp_GetRewritesByRewrittenUrl";
        internal static readonly string GetUrlRewritesByNodeAndQuerySp = "seo.sp_GetRewritesByNodeAndQuery";
        internal static readonly string GetUrlRewritesByTitleSp = "seo.sp_GetRewritesByTitle";
        internal static readonly string GetUrlRewritesByMetaDescriptionSp = "seo.sp_GetRewritesByMetaDescription";

        #endregion

        protected abstract string GetPublishedRewritesStoredProcedure { get; }
        protected abstract string GetPublishedSeoDecorationsStoredProcedure { get; }
        protected abstract string GetPublishedRewrittenUrlsStoredProcedure { get; }

        public PublishedRewriteRepositoryBase(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }

        public IEnumerable<PublishedRewriteDto> GetPublishedRewrites(string siteCode, string cultureCode)
        {
            return ExecuteSelect<PublishedRewriteDto>(GetPublishedRewritesStoredProcedure, new Dictionary<string, object>
            {
                { "SiteCode", siteCode },
                { "CultureCode", cultureCode }
            });
        }

        public IEnumerable<PublishedSeoDecorationDto> GetPublishedSeoDecorations(string siteCode, string cultureCode)
        {
            return ExecuteSelect<PublishedSeoDecorationDto>(GetPublishedSeoDecorationsStoredProcedure, new Dictionary<string, object>
            {
                { "SiteCode", siteCode },
                { "CultureCode", cultureCode }
            });
        }

        public IEnumerable<string> GetPublishedRewrittenUrls(string siteCode, string cultureCode)
        {
            return ExecuteSelect<string>(GetPublishedRewrittenUrlsStoredProcedure, new Dictionary<string, object>
            {
                { "SiteCode", siteCode },
                { "CultureCode", cultureCode }
            });
        }
    }
}
