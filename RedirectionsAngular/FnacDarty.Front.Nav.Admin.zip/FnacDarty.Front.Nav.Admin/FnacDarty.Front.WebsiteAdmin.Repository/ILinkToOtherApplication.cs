﻿
using System;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public interface ILinkToOtherApplication
    {
        Uri LinkToPom { get;   }
        Uri LinkToSmile { get; }
        Uri LinkToCommunity { get; }
    }
}
