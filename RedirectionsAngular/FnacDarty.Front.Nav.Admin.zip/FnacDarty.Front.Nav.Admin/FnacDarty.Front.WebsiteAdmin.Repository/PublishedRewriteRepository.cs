using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class PublishedRewriteRepository : PublishedRewriteRepositoryBase
    {
        public PublishedRewriteRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
        }

        protected override string GetPublishedRewritesStoredProcedure
        {
            get { return "seo.sp_GetPublishedRewrites"; }
        }

        protected override string GetPublishedSeoDecorationsStoredProcedure
        {
            get { return "seo.sp_GetPublishedSeoDecorations"; }
        }

        protected override string GetPublishedRewrittenUrlsStoredProcedure
        {
            get { return "seo.sp_GetPublishedRewrittenUrls"; }
        }
    }
}
