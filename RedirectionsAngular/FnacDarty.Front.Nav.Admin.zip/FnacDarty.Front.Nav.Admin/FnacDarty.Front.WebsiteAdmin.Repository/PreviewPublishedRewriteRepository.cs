using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class PreviewPublishedRewriteRepository : PublishedRewriteRepositoryBase
    {
        public PreviewPublishedRewriteRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }

        protected override string GetPublishedRewritesStoredProcedure
        {
            get { return "seo.sp_GetPreviewPublishedRewrites"; }
        }

        protected override string GetPublishedSeoDecorationsStoredProcedure
        {
            get { return "seo.sp_GetPreviewPublishedSeoDecorations"; }
        }

        protected override string GetPublishedRewrittenUrlsStoredProcedure
        {
            get { return "seo.sp_GetPreviewPublishedRewrittenUrls"; }
        }
    }
}
