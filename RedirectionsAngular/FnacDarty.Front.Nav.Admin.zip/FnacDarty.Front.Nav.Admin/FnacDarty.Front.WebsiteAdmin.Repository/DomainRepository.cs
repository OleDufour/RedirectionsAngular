using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class DomainRepository : BaseRepository, IDomainRepository
    {
        internal static readonly string GetDomainSp = "com.sp_GetDomain";
        internal static readonly string GetDomainsSp = "com.sp_GetAllDomains";


        public DomainRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }

        public Domain GetDomainById(int domainId)
        {
            return ExecuteFirst<Domain>(GetDomainSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId}
            });
        }

        public IEnumerable<Domain> GetDomains()
        {
            return ExecuteSelect<Domain>(GetDomainsSp);
        }
    }
}
