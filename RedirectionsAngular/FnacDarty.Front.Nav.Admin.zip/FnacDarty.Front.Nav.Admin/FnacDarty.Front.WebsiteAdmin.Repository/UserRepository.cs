using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class UserRepository : BaseRepository, IUserRepository
    {
        internal static readonly string GetUsersSp = "com.sp_GetAllUsers";
        internal static readonly string GetUserByLoginSp = "com.sp_GetUserByLogin";
        internal static readonly string GetUserRolesSp = "com.sp_GetUserRoles";
        internal static readonly string GetUserByIdSp = "com.sp_GetUserById";
        internal static readonly string AddUserSp = "com.sp_AddUser";
        internal static readonly string UpdateUserSp = "com.sp_UpdateUser";
        internal static readonly string AddUserRoleSp = "com.sp_AddUserRole";
        internal static readonly string DeleteUserRoleSp = "com.sp_DeleteUserRole";
        internal static readonly string DeleteUserSp = "com.sp_DeleteUser";

        public UserRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }

        public User GetUserByLogin(string identityName)
        {
            var user = ExecuteFirstOrDefault<User>(GetUserByLoginSp, new Dictionary<string, object>()
            {
                {"Login",identityName }
            });
            if (user != null)
            {
                user.Roles = ExecuteSelect<Role>(GetUserRolesSp,
                    new Dictionary<string, object>()
                    {
                        {"UserId", user.UserId}
                    }).ToList();
            }
            return user;
        }

        public User GetUserById(Guid userId)
        {
            var user = ExecuteFirstOrDefault<User>(GetUserByIdSp, new Dictionary<string, object>()
            {
                {"UserId",userId }
            });
            if (user != null)
            {
                user.Roles = ExecuteSelect<Role>(GetUserRolesSp,
                    new Dictionary<string, object>()
                    {
                        {"UserId", user.UserId}
                    }).ToList();
            }
            return user;
        }

        public bool AddUser(User user)
        {
            return ExecuteNonQuery(AddUserSp, new Dictionary<string, object>()
            {
                {"UserId", user.UserId},
                {"Login", user.Login},
                {"IsAdmin", user.IsAdmin}
            }) > 0;
        }

        public bool DeleteUser(Guid userId)
        {
            return ExecuteNonQuery(DeleteUserSp, new Dictionary<string, object>()
            {
                {"UserId", userId}
            }) > 0;
        }

        public bool UpdateUser(User user)
        {
            return ExecuteNonQuery(UpdateUserSp, new Dictionary<string, object>()
            {
                {"UserId", user.UserId},
                {"Login", user.Login},
                {"IsAdmin", user.IsAdmin}
            }) > 0;
        }

        public bool AddUserRole(Guid userId, int userRoleId)
        {
            return ExecuteNonQuery(AddUserRoleSp, new Dictionary<string, object>()
            {
                {"UserId", userId},
                {"RoleId", userRoleId}
            }) > 0;
        }

        public bool DeleteUserRole(Guid userId, int userRoleId)
        {
            return ExecuteNonQuery(DeleteUserRoleSp, new Dictionary<string, object>()
            {
                {"UserId", userId},
                {"RoleId", userRoleId}
            }) > 0;
        }

        public IEnumerable<User> GetUsers()
        {
            var users = ExecuteSelect<User>(GetUsersSp);
            foreach (var user in users)
            {
                user.Roles = ExecuteSelect<Role>(GetUserRolesSp,
                    new Dictionary<string, object>()
                    {
                        {"UserId", user.UserId}
                    }).ToList();
            }
            return users;
        }
    }
}
