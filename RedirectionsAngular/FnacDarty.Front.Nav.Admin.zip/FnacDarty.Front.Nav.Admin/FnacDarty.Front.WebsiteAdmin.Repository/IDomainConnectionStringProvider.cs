﻿namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public interface IDomainConnectionStringProvider
    {
        string Get(string connectionStringName, int domainId);
    }
}
