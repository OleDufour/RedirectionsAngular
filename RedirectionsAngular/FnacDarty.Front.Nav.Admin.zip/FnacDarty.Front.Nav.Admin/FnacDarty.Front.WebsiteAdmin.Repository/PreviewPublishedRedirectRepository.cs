using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class PreviewPublishedRedirectRepository : PublishedRedirectRepositoryBase
    {

        protected override string GetPublishedRedirectsStoredProcedure
        {
            get { return "seo.sp_GetPreviewPublishedRedirects"; }
        }

        public PreviewPublishedRedirectRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        { }
    }
}
