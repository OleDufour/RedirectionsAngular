﻿using System;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.Repository
{
    public class LinkToOtherApplication : ILinkToOtherApplication
    {
        public LinkToOtherApplication(IConfig config)
        {
            LinkToPom = new Uri(config.GetSettingValue("LinkToOtherApplication:LinkToPom"));
            LinkToSmile = new Uri(config.GetSettingValue("LinkToOtherApplication:LinkToSmile"));
            LinkToCommunity = new Uri(config.GetSettingValue("LinkToOtherApplication:LinkToCommunity"));
        }

        public Uri LinkToPom { get; }
        public Uri LinkToSmile { get; }
        public Uri LinkToCommunity { get; }

    }
}