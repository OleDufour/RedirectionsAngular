using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.BusinessModule
{
    public class PublishedRewriteBusinessModule : BaseBusinessModule, IPublishedRewriteBusinessModule
    {
        private const string PublishedRewriteCacheKeyFormat = "IPublishedRewriteModule.PublishedRewrites.{0}.{1}";
        private const string PublishedSeoDecorationCacheKeyFormat = "IPublishedRewriteModule.PublishedSeoDecorations.{0}.{1}";

        public IPublishedRewriteRepository PublishedRewriteRepository;
        public ILocalCache LocalCache;
        public IRestClient RestClient;

        public PublishedRewriteBusinessModule
        (
            ILogger logger,
            IConfig config,
            IPublishedRewriteRepository publishedRewriteRepository,
            ILocalCache localCache,
            IRestClient restClient
        ) : base(logger, config, localCache)
        {
            PublishedRewriteRepository = publishedRewriteRepository;
            LocalCache = localCache;
            RestClient = restClient;
        }

        public IEnumerable<PublishedRewriteDto> GetPublishedRewrites(string siteCode, string cultureCode)
        {
            return GetCache(PublishedRewriteCacheKeyFormat, siteCode, cultureCode, PublishedRewriteRepository.GetPublishedRewrites);
        }

        public IEnumerable<PublishedSeoDecorationDto> GetPublishedSeoDecorations(string siteCode, string cultureCode)
        {
            return GetCache(PublishedSeoDecorationCacheKeyFormat, siteCode, cultureCode, PublishedRewriteRepository.GetPublishedSeoDecorations);
        }

        public IEnumerable<string> GetPublishedRewrittenUrls(string siteCode, string cultureCode)
        {
            return PublishedRewriteRepository.GetPublishedRewrittenUrls(siteCode, cultureCode);
        }

        public bool NotifyInvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            try
            {
                // Invalidation du cache sur les n APIs mises en place
                var isAtLeastOneCacheInvalidatedAndReloaded = false;
                var vipApiUrls = Config.GetSettingValue("VipApiUrls:Rewrite");
                var configs = RestClientConfigurationManager.GetList(vipApiUrls);

                foreach (var config in configs)
                {
                    RestClient.BaseAddress = config.BaseAddress;
                    RestClient.Timeout = config.Timeout;
                    RestClient.NumberOfAttempts = config.NumberOfAttempts;
                    RestClient.TimeToSleepBetweenAttempts = config.TimeToSleepBetweenAttempts;

                    // Si une API ne répond pas (service ou serveur tombé), cela ne doit pas empêcher la publication (d'où le OU logique)
                    isAtLeastOneCacheInvalidatedAndReloaded |= RestClient.Delete($"InvalidateAndReloadCache/{siteCode}/{cultureCode}");
                }

                return isAtLeastOneCacheInvalidatedAndReloaded;
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, "PublishedUrlRewriteModule.NotifyInvalidateAndReloadCache");
                return false;
            }
        }

        public bool InvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            try
            {
                // Invalidate
                InvalidateCache(PublishedRewriteCacheKeyFormat, siteCode, cultureCode); 
                InvalidateCache(PublishedSeoDecorationCacheKeyFormat, siteCode, cultureCode); 

                // Reload
                GetPublishedSeoDecorations(siteCode, cultureCode);
                GetPublishedRewrittenUrls(siteCode, cultureCode);

                return true;
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, "PublishedUrlRewriteModule.InvalidateAndReloadCache");
                return false;
            }
        }

    }
}
