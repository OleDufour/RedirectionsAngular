using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.BusinessModule
{
    public class DomainBusinessModule : BaseBusinessModule, IDomainBusinessModule
    {
        public IDomainRepository DomainRepository;
        public ILocalCache LocalCache;

        private const string DomainsCacheKey = "Domains";

        public DomainBusinessModule(IDomainRepository domainRepository, ILogger logger, IConfig config, ILocalCache localCache)
            : base(logger, config)
        {
            DomainRepository = domainRepository;
            LocalCache = localCache;
        }

        public IEnumerable<Domain> GetDomains()
        {
            if (LocalCache.Contains(DomainsCacheKey))
            {
                return LocalCache.Get<List<Domain>>(DomainsCacheKey);
            }
            else
            {
                var domains = DomainRepository.GetDomains();
                LocalCache.Set(DomainsCacheKey, domains.ToList());
                return domains.ToList();
            }
        }

        public Domain GetDomain(EnumDomain domain)
        {
            return GetDomains().FirstOrDefault(d => d.DomainId == (int)domain);
        }
    }
}
