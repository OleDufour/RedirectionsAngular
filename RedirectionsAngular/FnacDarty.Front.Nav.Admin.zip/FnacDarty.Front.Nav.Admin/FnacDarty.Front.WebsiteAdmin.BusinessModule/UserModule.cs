using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.BusinessModule
{
    public class UserBusinessModule : BaseBusinessModule, IUserBusinessModule
    {
        public IUserRepository UserRepository;

        public UserBusinessModule(ILogger logger, IConfig config, IUserRepository userRepository) 
            : base(logger, config)
        {
            UserRepository = userRepository;
        }

        public User GetUserByLogin(string identityName)
        {
            return UserRepository.GetUserByLogin(identityName);
        }

        public User GetUserById(Guid userId)
        {
            return UserRepository.GetUserById(userId);
        }

        public bool AddUser(User user)
        {
            using (var transaction = new TransactionScope())
            {
                if (UserRepository.AddUser(user))
                {
                    foreach (var userRole in user.Roles)
                    {
                        if (!UserRepository.AddUserRole(user.UserId, userRole.RoleId))
                            return false;
                    }
                    transaction.Complete();
                    return true;
                }
                return false;
            }
        }

        public bool UpdateUser(User user)
        {
            var oldUser = UserRepository.GetUserById(user.UserId);

            using (var transaction = new TransactionScope())
            {
                if (UserRepository.UpdateUser(user))
                {
                    // ajout des roles
                    foreach (var userRole in user.Roles)
                    {
                        // ajout des roles
                        if (oldUser.Roles.All(or => or.RoleId != userRole.RoleId))
                        {
                            if (!UserRepository.AddUserRole(user.UserId, userRole.RoleId))
                                return false;
                        }
                    }

                    // suppression des roles
                    foreach (var oldUserRole in oldUser.Roles)
                    {
                        if (user.Roles.All(r => r.RoleId != oldUserRole.RoleId))
                        {
                            if (!UserRepository.DeleteUserRole(user.UserId, oldUserRole.RoleId))
                                return false;
                        }
                    }
                    transaction.Complete();
                    return true;
                }
                return false;
            }
        }

        public bool DeleteUser(Guid userId)
        {
            var user = UserRepository.GetUserById(userId);
            if (user != null)
                using (var transaction = new TransactionScope())
                {
                    foreach (var userRole in user.Roles)
                    {
                        //delete user role
                        if (!UserRepository.DeleteUserRole(userId, userRole.RoleId))
                        {
                            return false;
                        }
                    }

                    //delete user
                    if (UserRepository.DeleteUser(userId))
                    {
                        transaction.Complete();
                        return true;
                    }

                }
            return false;
        }

        public IEnumerable<User> GetUsers()
        {
            return UserRepository.GetUsers();
        }
    }
}
