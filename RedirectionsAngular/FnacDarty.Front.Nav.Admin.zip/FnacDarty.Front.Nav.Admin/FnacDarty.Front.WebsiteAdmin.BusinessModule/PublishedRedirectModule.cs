using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.BusinessModule
{
    public class PublishedRedirectBusinessModule : BaseBusinessModule, IPublishedRedirectBusinessModule
    {
        private const string PublishedUrlRedirectCacheKeyFormat = "IPublishedRedirectModule.PublishedUrlRedirects.{0}.{1}";

        public IPublishedRedirectRepository PublishedRedirectRepository;
        public ILocalCache LocalCache;
        public IRestClient RestClient;

        public PublishedRedirectBusinessModule
        (
            ILogger logger,
            IConfig config,
            IPublishedRedirectRepository publishedRedirectRepository,
            ILocalCache localCache,
            IRestClient restClient
        ) : base(logger, config, localCache)
        {
            PublishedRedirectRepository = publishedRedirectRepository;
            LocalCache = localCache;
            RestClient = restClient;
        }

        public IEnumerable<PublishedUrlRedirectDto> GetPublishedUrlRedirectDtos(string siteCode, string cultureCode)
        {
            return GetCache(PublishedUrlRedirectCacheKeyFormat, siteCode, cultureCode, PublishedRedirectRepository.GetPublishedUrlRedirectDtos);
        }

        public bool NotifyInvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            try
            {
                // Invalidation du cache sur les n APIs mises en place
                var isAtLeastOneCacheInvalidatedAndReloaded = false;
                var vipApiUrls = Config.GetSettingValue("VipApiUrls:Redirect");
                var configs = RestClientConfigurationManager.GetList(vipApiUrls);

                foreach (var config in configs)
                {
                    RestClient.BaseAddress = config.BaseAddress;
                    RestClient.Timeout = config.Timeout;
                    RestClient.NumberOfAttempts = config.NumberOfAttempts;
                    RestClient.TimeToSleepBetweenAttempts = config.TimeToSleepBetweenAttempts;

                    // Si une API ne répond pas (service ou serveur tombé), cela ne doit pas empêcher la publication (d'où le OU logique)
                    isAtLeastOneCacheInvalidatedAndReloaded |= RestClient.Delete($"InvalidateAndReloadCache/{siteCode}/{cultureCode}");
                }

                return isAtLeastOneCacheInvalidatedAndReloaded;
            }
            catch (Exception exception)
            {
                Logger.LogError(exception,"PublishedRedirectBusinessModule.NotifyInvalidateAndReloadCache");
                return false;
            }
        }

        public bool InvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            try
            {
                // Invalidate
                InvalidateCache(PublishedUrlRedirectCacheKeyFormat, siteCode, cultureCode);

                // Reload
                GetPublishedUrlRedirectDtos(siteCode, cultureCode);

                return true;
            }
            catch (Exception exception)
            {
                Logger.LogError(exception,"PublishedRedirectBusinessModule.InitCache");
                return false;
            }
        }
    }
}
