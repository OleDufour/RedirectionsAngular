using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
 

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite
{
    public class ModuleRegistration : ModuleRegistrationBase
    {
        public override IServiceCollection RegisterServices(IServiceCollection services)
        {
            services.AddSingleton<IDtoModelMapper<DataTransfer.UrlRewrite, UrlRewriteViewModel>, UrlRewriteViewModelMapper>();
            services.AddSingleton<IUrlRewritePublicationRequestRepository, UrlRewritePublicationRequestRepository>();

            services.AddSingleton<IUrlRewriteRepository, UrlRewriteRepository>();
            services.AddSingleton<IUrlRewriteHistoryRepository, UrlRewriteHistoryRepository>();
            services.AddSingleton<IUrlRewritePublicationRepository, UrlRewritePublicationRepository>();

            services.AddSingleton<IDataTablesRepository<DataTransfer.UrlRewrite>, UrlRewriteDataTablesRepository>();

            services.AddSingleton<IUrlRewriteBusinessModule, UrlRewriteBusinessModule>();

            return services;
        }

        public override AuthorizationOptions RegisterAuthorizations(AuthorizationOptions authorizationOptions)
        {

            authorizationOptions.AddPolicy(AuthorizePolicyConsts.Rewrite_Read_Write, policy =>
            {
                policy.AddRequirements(new AuthorizedUserRequirement(false,
                    new[]
                    {
                        EnumUserRole.URL_FR_FR_READ,
                        EnumUserRole.URL_FR_FR_WRITE,
                        EnumUserRole.URL_FR_FR_PRO_READ,
                        EnumUserRole.URL_FR_FR_PRO_WRITE,
                        EnumUserRole.URL_FR_BE_READ,
                        EnumUserRole.URL_FR_BE_WRITE,
                        EnumUserRole.URL_NL_BE_READ,
                        EnumUserRole.URL_NL_BE_WRITE,
                        EnumUserRole.URL_FR_CH_READ,
                        EnumUserRole.URL_FR_CH_WRITE,
                        EnumUserRole.URL_ES_ES_READ,
                        EnumUserRole.URL_ES_ES_WRITE,
                        EnumUserRole.URL_PT_PT_READ,
                        EnumUserRole.URL_PT_PT_WRITE
                    }
                ));
                policy.RequireAuthenticatedUser();
                policy.AuthenticationSchemes.Add("Windows");
            });
            authorizationOptions.AddPolicy(AuthorizePolicyConsts.Rewrite_Read, policy =>
            {
                policy.AddRequirements(new AuthorizedUserRequirement(false,
                    new[]
                    {
                        EnumUserRole.URL_FR_FR_READ,
                        EnumUserRole.URL_FR_FR_PRO_READ,
                        EnumUserRole.URL_FR_BE_READ,
                        EnumUserRole.URL_NL_BE_READ,
                        EnumUserRole.URL_FR_CH_READ,
                        EnumUserRole.URL_ES_ES_READ,
                        EnumUserRole.URL_PT_PT_READ
                    }
                ));
                policy.RequireAuthenticatedUser();
                policy.AuthenticationSchemes.Add("Windows");
            });

            return authorizationOptions;
        }

        public override IDynamicMenuBuilder RegisterMenu(IDynamicMenuBuilder menuBuilder)
        {
            menuBuilder.AddSection(nameof(UrlRewriteResources.app_url_rewrite_menu), new[]
            {
                new MenuItem()
                {
                    Label = nameof(UrlRewriteResources.app_url_rewrite_menu),
                    Icon = "fa-calculator",
                    SubItems = new List<SubMenuItem>
                    {
                        new SubMenuItem
                        {
                            Area = "UrlRewrite",
                            Controller = "UrlRewrite",
                            Action = "Index",
                            Label = nameof(UrlRewriteResources.app_search),
                            AuthorizationRequired = AuthorizePolicyConsts.Rewrite_Read
                        },
                        new SubMenuItem
                        {
                            Area = "UrlRewrite",
                            Controller = "UrlRewrite",
                            Action = "Add",
                            Label = nameof(UrlRewriteResources.app_add),
                            AuthorizationRequired = AuthorizePolicyConsts.Rewrite_Read_Write
                        },
                        
                        new SubMenuItem
                        {
                            Area = "UrlRewrite",
                            Controller = "UrlRewrite",
                            Action = "Publication",
                            Label = nameof(UrlRewriteResources.app_publish),
                            AuthorizationRequired = AuthorizePolicyConsts.Rewrite_Read_Write
                        }
                    }
                },
            }, UrlRewriteResources.ResourceManager);

            return menuBuilder;
        }
    }
}
