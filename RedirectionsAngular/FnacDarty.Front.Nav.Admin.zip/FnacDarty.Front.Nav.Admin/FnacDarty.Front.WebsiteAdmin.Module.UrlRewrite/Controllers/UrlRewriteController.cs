using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models.Common;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Controllers;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
 
using DataTablesParameters = FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer.DataTablesParameters;
using IUrlRewriteBusinessModule = FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.IUrlRewriteBusinessModule;
using UrlRewritePaging = FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer.UrlRewritePaging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Controllers
{
    [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
    [Area("UrlRewrite")]
    public class UrlRewriteController : ApplicationController
    {
        public IUrlRewriteBusinessModule UrlRewriteBusinessModule;
        public IDomainBusinessModule DomainBusinessModule;
        public IDtoModelMapper<DataTransfer.UrlRewrite, UrlRewriteViewModel> UrlRewriteViewModelMapper;
        public IDtoModelMapper<Domain, DomainModel> DomainModelMapper;

        private const string ControllerRolePattern = "URL";

        public UrlRewriteController(IUrlRewriteBusinessModule urlRewriteBusinessModule, IDomainBusinessModule domainBusinessModule,
            IDtoModelMapper<DataTransfer.UrlRewrite, UrlRewriteViewModel> urlRewriteViewModelMapper,
            IDtoModelMapper<Domain, DomainModel> domainModelMapper,
            ILogger logger,
            IAccessControl accessControl) : base(logger, accessControl)
        {
            UrlRewriteBusinessModule = urlRewriteBusinessModule;
            DomainBusinessModule = domainBusinessModule;
            UrlRewriteViewModelMapper = urlRewriteViewModelMapper;
            DomainModelMapper = domainModelMapper;
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
        [Route("urlrewrite")]
        public ActionResult Index()
        {
            var domains = DomainBusinessModule.GetDomains();
            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            var autorizedDomainsReadWrite = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var autorizedDomainsReadOnly = GetAuthorizedReadOnlyDomain(ControllerRolePattern);

            var templates = Enum.GetValues(typeof(EnumRewriteType))
                                    .Cast<EnumRewriteType>()
                                    .Select(d => new { name = d.ToString(), value = ((int)d).ToString() }).ToList();
            
            templates.Insert(0, new { name = UrlRewriteResources.app_url_rewrite_alltype, value = string.Empty });

            ViewBag.Templates = templates;

            var searchViewModel = new UrlRewriteSearchViewModel
            {
                AuthorizedDomainsReadOnly = DomainModelMapper.DtosToModels(domains.Where(d => autorizedDomainsReadOnly.Contains((EnumDomain)d.DomainId)).ToList()).ToList(),
                AuthorizedDomainsReadWrite = DomainModelMapper.DtosToModels(domains.Where(d => autorizedDomainsReadWrite.Contains((EnumDomain)d.DomainId)).ToList()).ToList()
            };

            var domain = searchViewModel.AuthorizedDomainsReadOnly.FirstOrDefault();
            if (domain != null)
                searchViewModel.Domain = domain.DomainId;

            return View(searchViewModel);
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read_Write)]
        [Route("urlrewrite/add")]
        public ActionResult Add()
        {
            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId)).ToList();

            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            ViewBag.Templates = Enum.GetValues(typeof(EnumRewriteType)).Cast<EnumRewriteType>();

            var model = new UrlRewriteViewModel()
            {
                DomainId = domains.FirstOrDefault()?.DomainId ?? (int)EnumDomain.FR_FR,
                RewriteTypeId = (int)EnumRewriteType.Search
            };

            return View("AddOrEdit", model);
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read_Write)]
        [Route("urlrewrite/edit/{urlRewriteId:int}/{editSuccess?}")]
        public ActionResult Edit(int urlRewriteId, bool editSuccess = false)
        {
            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId)).ToList();

            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            ViewBag.Templates = Enum.GetValues(typeof(EnumRewriteType)).Cast<EnumRewriteType>();

            var urlRewriteDto = UrlRewriteBusinessModule.GetUrlRewrite(urlRewriteId);
            if (urlRewriteDto != null)
            {
                var viewModel = UrlRewriteViewModelMapper.DtoToModel(urlRewriteDto);

                //Get history data
                viewModel.History = GetUrlRewriteHistories(urlRewriteId);
                ViewBag.EditSuccess = editSuccess;
                return View("AddOrEdit", viewModel);
            }
            return RedirectToAction("Index");
        }

        private IEnumerable<UrlRewriteHistoryViewModel> GetUrlRewriteHistories(int urlRewriteId)
        {
            var urlRewriteHistory = UrlRewriteBusinessModule.GetUrlRewriteHistories(urlRewriteId).ToList();
            if (urlRewriteHistory != null && urlRewriteHistory.Count > 0)
            {
                return GetHistoryViewModel(urlRewriteHistory);
            }
            return Enumerable.Empty<UrlRewriteHistoryViewModel>();
        }

        private static IEnumerable<UrlRewriteHistoryViewModel> GetHistoryViewModel(IEnumerable<DataTransfer.UrlRewriteHistory> urlRewriteHistory)
        {
            return urlRewriteHistory.Select(item => new UrlRewriteHistoryViewModel
            {
                RewriteId = item.RewriteId,
                RewriteTypeId = item.RewriteTypeId,
                Node = item.Node,
                Query = item.Query,
                MobileRealUrl = item.MobileRealUrl,
                DesktopRealUrl = item.DesktopRealUrl,
                RewrittenUrl = item.RewrittenUrl,
                Title = item.Title,
                MetaDescription = item.MetaDescription,
                H1Tag = item.H1Tag,
                SeoData = item.SeoData,
                CreationDate = item.CreationDate.ToString("yyyy/MM/dd HH:mm:ss"),
                CreationUser = item.CreationUser,
                PublicationRequestId = item.PublicationRequestId?.ToString() ?? string.Empty,
                PublicationDate = item.PublicationRequestDate?.ToString("yyyy/MM/dd HH:mm:ss") ?? string.Empty,
                PublicationUser = item.PublicationRequestUser ?? string.Empty,
                ActionType = ((EnumActionType)item.ActionTypeId).ToString()
            }).OrderByDescending(h => h.CreationDate);
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read_Write)]
        [Route("urlrewrite/duplicate/{urlRewriteId:int}")]
        public ActionResult Duplicate(int urlRewriteId)
        {
            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId)).ToList();

            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            ViewBag.Templates = Enum.GetValues(typeof(EnumRewriteType)).Cast<EnumRewriteType>();

            var urlRewriteDto = UrlRewriteBusinessModule.GetUrlRewrite(urlRewriteId);

            if (urlRewriteDto != null)
            {
                // Pour la duplication
                var viewModel = UrlRewriteViewModelMapper.DtoToModel(urlRewriteDto);
                viewModel.RewriteId = null;
                viewModel.IsDeleted = false;
                return View("AddOrEdit", viewModel);
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read_Write)]
        [Route("urlrewrite/AddOrEdit")]
        public JsonResult AddOrEdit(UrlRewriteViewModel urlRewriteViewModel)
        {
            if (!ModelState.IsValid)
            {
                return Json(new ResultModel
                {
                    Success = false,
                    Message = $"{UrlRewriteResources.app_errors_list} :<ul>" +
                        string.Join("", ModelStateErrors().Select(m => "<li>" + m + "</li>")) + "</ul>"
                });
            }

            // Mapping
            var urlRewriteDto = UrlRewriteViewModelMapper.ModelToDto(urlRewriteViewModel);
            if (urlRewriteDto.RewriteId.HasValue && urlRewriteDto.RewriteId.Value > 0)
            {
                urlRewriteDto.ModificationUser = ApplicationUser.Identity.Name;
                urlRewriteDto.ModificationDate = DateTime.Now;
            }
            else
            {
                urlRewriteDto.CreationUser = ApplicationUser.Identity.Name;
                urlRewriteDto.CreationDate = DateTime.Now;
            }

            // Validation
            var errorsResult = UrlRewriteBusinessModule.Validate(urlRewriteDto);

            if (errorsResult.Count > 0)
            {
                ModelState.Clear();
                foreach (var item in errorsResult)
                {
                    ModelState.AddModelError(item.Key, item.Value);
                }
            }
            else
            {
                // Ajout ou modication
                if (urlRewriteDto.RewriteId.HasValue && urlRewriteDto.RewriteId.Value > 0)
                {
                    //modification
                    bool result = false;
                    try
                    {
                        result = UrlRewriteBusinessModule.UpdateUrlRewrite(urlRewriteDto);
                    }
                    catch (NotImplementedException)
                    {                        
                        return Json(new ResultModel
                        {
                            Success = false,
                            Message = UrlRewriteResources.app_nonexisting_element,
                            Data = new { IsDeleted = true }
                        });
                    }

                    if (result)
                    {
                        return Json(new ResultModel
                        {
                            Success = true,
                            Data = new { RewriteId = urlRewriteDto.RewriteId.Value, historyitems = GetUrlRewriteHistories(urlRewriteDto.RewriteId.Value) },
                            Message = UrlRewriteResources.app_update_success
                        });
                    }
                    else
                    {
                        return Json(new ResultModel
                        {
                            Success = false,
                            Message = UrlRewriteResources.app_already_deleted,
                            Data = new { IsDeleted = true }
                        });
                    }
                }
                else
                {
                    //ajout
                    urlRewriteDto = UrlRewriteBusinessModule.AddUrlRewrite(urlRewriteDto);
                    if (urlRewriteDto.RewriteId.HasValue && urlRewriteDto.RewriteId.Value > 0)
                    {
                        return Json(new ResultModel
                        {
                            Success = true,
                            Message = UrlRewriteResources.app_add_success,
                            Data = new { RewriteId = urlRewriteDto.RewriteId.Value, historyitems = GetUrlRewriteHistories(urlRewriteDto.RewriteId.Value) },
                        });
                    }
                    else
                    {
                        return Json(new ResultModel
                        {
                            Success = false,
                            Message = UrlRewriteResources.app_add_error
                        });
                    }
                }
            }

            return Json(new ResultModel
            {
                Success = false,
                Message = $"{UrlRewriteResources.app_errors_list} :<ul>" +
                                     string.Join("", ModelStateErrors().Select(m => "<li>" + m + "</li>")) + "</ul>"
            });
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read_Write)]
        [Route("urlrewrite/delete/{urlRewriteId:int}")]
        public ResultModel Delete(int urlRewriteId)
        {
            var urlRewrite = UrlRewriteBusinessModule.GetUrlRewrite(urlRewriteId);
            if (urlRewrite == null)
            {
                return new ResultModel
                {
                    Success = false,
                    Message = UrlRewriteResources.app_rewrite_not_exist
                };
            }

            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern).Select(d => (short)d);
            if (!authorizedReadWriteDomain.Contains(urlRewrite.DomainId))
            {
                throw new Exception(UrlRewriteResources.app_unauthorized_edit);
            }

            if (urlRewrite.DeletionDate.HasValue)
            {
                return new ResultModel
                {
                    Success = false,
                    Message = UrlRewriteResources.app_already_delete_error
                };
            }

            urlRewrite.DeletionDate = DateTime.Now;
            urlRewrite.DeletionUser = ApplicationUser.Identity.Name;
            var result = UrlRewriteBusinessModule.DeleteUrlRewrite(urlRewrite);

            return new ResultModel()
            {
                Success = result,
                Message = result ? UrlRewriteResources.app_delete_success : UrlRewriteResources.app_delete_error
            };
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
        [Route("urlrewrite/history/{urlRewriteId:int}")]
        public ResultModel History(int urlRewriteId)
        {
            var urlRewrite = UrlRewriteBusinessModule.GetUrlRewrite(urlRewriteId);
            var urlRewriteHistory = UrlRewriteBusinessModule.GetUrlRewriteHistories(urlRewriteId);

            var historyViewModel = new
            {
                urlRewrite.RewriteTypeId,
                urlRewrite.Node,
                Query = urlRewrite.Query ?? "",
                MobileRealUrl = urlRewrite?.MobileRealUrl ?? "",
                DesktopRealUrl = urlRewrite?.DesktopRealUrl ?? "",
                RewrittenUrl = urlRewrite?.RewrittenUrl ?? "",
                HistoryItems = GetUrlRewriteHistories(urlRewriteId)
            };
            return GetSuccessResultModel(string.Empty, historyViewModel);
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
        [Route("urlrewrite/getdatatablerewrites")]
        public DataTablesReturnData<UrlRewriteViewModel> GetDataTableRewrites(DataTablesParameters parameters)
        {
            var r = new UrlRewritePaging();
            r.DomainId = (short)parameters.DomainId;
            r.OrderByColumn = UrlRewriteBusinessModule.OrderByColumn(parameters);
            r.AscOrDesc = UrlRewriteBusinessModule.AscOrDesc(parameters);
            r.PageNo = parameters.Start / parameters.Length + 1;
            r.PageSize = parameters.Length;
            r.IncludeDeletions = parameters.IncludeDeletions;

            foreach (var p in parameters.Columns)
            {
                switch (p.Data)
                {
                    case nameof(r.Node):
                        if (int.TryParse(p.Search.Value, out int node))
                        {
                            r.Node = node;
                        }
                        else
                        {
                            r.Node = 0;
                        }
                        ; break;
                    case nameof(r.Query): r.Query= p.Search.Value; break;
                    case nameof(r.RewrittenUrl): r.RewrittenUrl = p.Search.Value; break;
                    case nameof(r.Title): r.Title = p.Search.Value; break;
                    case nameof(r.MetaDescription): r.MetaDescription = p.Search.Value; break;
                    case nameof(r.H1Tag): r.H1Tag = p.Search.Value; break;
                    case nameof(r.RewriteTypeId): r.RewriteTypeId = Convert.ToInt16(p.Search.Value); break;
                }
            }
            var res = UrlRewriteBusinessModule.GetUrlRewritesForPaging(r, out var filteredCount, out var totalCount);
            return new DataTablesReturnData<UrlRewriteViewModel>
            {
                Draw = parameters.Draw,
                RecordsFiltered = filteredCount,
                RecordsTotal = totalCount,
                Data = UrlRewriteViewModelMapper.DtosToModels(res)
            };
        }

        #region Publication

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
        [Route("urlrewrite/publication")]
        public ActionResult Publication()
        {
            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId));

            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            var model = new PublicationDomainsViewModel()
            {
                DomainsToPublish = DomainModelMapper.DtosToModels(domains).ToList()
            };

            return View(model);
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read_Write)]
        [Route("urlrewrite/publish/{domainId:int}/{isproduction:bool}")]
        public JsonResult Publish(int domainId, bool isProduction)
        {
            var authorizedDomains = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedDomains.Contains((EnumDomain)d.DomainId));

            if (domains.Any(d => d.DomainId == domainId))
            {
                bool isPublished = false;
                string errorMessage = null;

                try
                {
                    var domain = DomainBusinessModule.GetDomain((EnumDomain)domainId);
                    isPublished = UrlRewriteBusinessModule.PublishUrlRewriteDomain((EnumDomain)domainId, ApplicationUser.Identity.Name, domain.SiteCode, domain.CultureCode, isProduction);
                }
                catch (Exception exception)
                {
                    Logger.LogError(exception, "Erreur UrlRewriteController - Publish");
                    errorMessage = UrlRewriteResources.app_publish_error;
                }

                if (!isPublished)
                {
                    return Json(new ResultModel()
                    {
                        Success = false,
                        Message = $"{UrlRewriteResources.app_publish_error} - {(EnumDomain)domainId} !"
                    });
                }
            }
            else
            {
                return Json(new ResultModel()
                {
                    Success = false,
                    Message = $"{UrlRewriteResources.app_publish_unauthorized} - {(EnumDomain)domainId} !"
                });
            }

            return Json(new ResultModel()
            {
                Success = true,
                Message = UrlRewriteResources.app_publish_ok
            });
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
        [Route("urlrewrite/getpublicationrequesthistory/{domainId:int}")]
        public ResultModel GetPublicationRequestHistory(int domainId)
        {
            if (!Enum.IsDefined(typeof(EnumDomain), domainId))
            {
                Logger.LogError("Erreur UrlRewriteController - GetPublicationRequestHistory", $"Parametre invalide domainId : {domainId}");
                return GetGenericFailureResultModel($"{UrlRewriteResources.app_url_search_error} Parametre invalide");
            }

            var authorizedDomains = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedDomains.Contains((EnumDomain)d.DomainId));

            try
            {
                var historyPublication = UrlRewriteBusinessModule.GetPublicationRequestHistory((EnumDomain)domainId)
                                                        .OrderByDescending(h => h.PublicationRequestDate);

                var currentPublicationRequest = UrlRewriteBusinessModule.GetCurrentPublicationRequest((EnumDomain)domainId);
                var data = historyPublication.Select(item =>
                    new PublicationRequestViewModel
                    {
                        PublicationRequestId = item.PublicationRequestId,
                        PublicationRequestDate = item.PublicationRequestDate.ToString("yyyy/MM/dd HH:mm:ss"),
                        PublicationRequestUser = item.PublicationRequestUser,
                        DomainId = item.DomainId,
                        IsPublishable = currentPublicationRequest != null && item.PublicationRequestId < currentPublicationRequest.PublicationRequestId,
                        IsCurrentPublication = currentPublicationRequest != null && item.PublicationRequestId == currentPublicationRequest.PublicationRequestId
                    })
                    .ToList();

                return GetSuccessResultModel(string.Empty, data);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception,"Erreur UrlRewriteController - Search");
                return GetGenericFailureResultModel($"{UrlRewriteResources.app_url_search_error} {exception.Message}");
            }
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("urlrewrite/getpublicationrequestdetails/{publicationRequestId:int}/{domainId:int}")]
        public ResultModel GetPublicationRequestDetails(int publicationRequestId, int domainId)
        {
            try
            {
                var res = UrlRewriteBusinessModule.GetPublicationRequestDetails(publicationRequestId, domainId);
                var data = GetHistoryViewModel(res);

                return GetSuccessResultModel(string.Empty, data);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception,"Erreur RedirectController - GetPublicationRequestDetails");
                return GetGenericFailureResultModel($"{UrlRewriteResources.app_url_search_error} {exception.Message}");
            }
        }

        [Authorize(Policy = AuthorizePolicyConsts.Rewrite_Read)]
        [Route("urlrewrite/getdrafturlsrewritten/{domainId:int}")]
        public ResultModel GetdraftUrlsRewritten(int domainId)
        {
            if (!Enum.IsDefined(typeof(EnumDomain), domainId))
            {
                Logger.LogError("Erreur UrlRewriteController - GetDraftUrlRewrite", $"Parametre invalide domainId : {domainId}");
                return GetGenericFailureResultModel($"{UrlRewriteResources.app_url_search_error} Parametre invalide");
            }

            var authorizedDomains = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedDomains.Contains((EnumDomain)d.DomainId));

            try
            {
                var urls = UrlRewriteBusinessModule.GetDraftUrlRewrite((EnumDomain)domainId);
                var data = GetHistoryViewModel(urls);

                return GetSuccessResultModel(string.Empty, data);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception,"Erreur UrlRewriteController - GetdraftUrlsRewritten");
                return GetGenericFailureResultModel($"{UrlRewriteResources.app_url_search_error} {exception.Message}");
            }
        }


        #endregion Publication

    }
}
