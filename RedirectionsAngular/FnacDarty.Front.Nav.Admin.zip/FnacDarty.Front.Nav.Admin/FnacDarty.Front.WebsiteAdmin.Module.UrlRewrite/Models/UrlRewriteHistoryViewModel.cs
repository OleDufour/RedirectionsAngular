using System.ComponentModel.DataAnnotations;
 
namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models
{
    public class UrlRewriteHistoryViewModel
    {
        public int? RewriteId { get; set; }

        [Display(Name = "app_domain", ResourceType = typeof(UrlRewriteResources))]
        public int DomainId { get; set; }

        [Display(Name = "app_url_field_type", ResourceType = typeof(UrlRewriteResources))]
        public int RewriteTypeId { get; set; }

        [Display(Name = "app_url_field_url_node", ResourceType = typeof(UrlRewriteResources))]
        public int? Node { get; set; }

        [StringLength(2048)]
        [Display(Name = "app_url_field_url_query", ResourceType = typeof(UrlRewriteResources))]
        public string Query { get; set; }

        [Required(ErrorMessageResourceName = "app_url_real_mobile_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        public string MobileRealUrl { get; set; }

        [Required(ErrorMessageResourceName = "app_url_real_desktop_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        public string DesktopRealUrl { get; set; }

        public string RewrittenUrl { get; set; }

        [Display(Name = "app_url_field_url_title", ResourceType = typeof(UrlRewriteResources))]
        public string Title { get; set; }

        [Display(Name = "app_url_field_url_meta", ResourceType = typeof(UrlRewriteResources))]
        public string MetaDescription { get; set; }

        [Display(Name = "app_url_field_url_h1", ResourceType = typeof(UrlRewriteResources))]
        public string H1Tag { get; set; }

        [Display(Name = "app_url_field_url_seo", ResourceType = typeof(UrlRewriteResources))]
        public string SeoData { get; set; }

        [Display(Name = "app_url_field_date_action", ResourceType = typeof(UrlRewriteResources))]
        public string CreationDate { get; set; }

        [Display(Name = "app_url_field_user", ResourceType = typeof(UrlRewriteResources))]
        public string CreationUser { get; set; }

        [Display(Name = "app_url_field_publication_date", ResourceType = typeof(UrlRewriteResources))]
        public string PublicationDate { get; set; }

        [Display(Name = "app_url_field_publication_by", ResourceType = typeof(UrlRewriteResources))]
        public string PublicationUser { get; set; }

        [Display(Name = "app_url_field_publication_id", ResourceType = typeof(UrlRewriteResources))]
        public string PublicationRequestId { get; set; }

        [Display(Name = "app_action_type", ResourceType = typeof(UrlRewriteResources))]
        public string ActionType { get; set; }
    }
}
