using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FnacDarty.Front.WebsiteAdmin.WebCommon.CustomAttributes;
 

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models
{
    public class UrlRewriteViewModel
    {
        public int? RewriteId { get; set; }

        [Display(Name = "app_domain", ResourceType = typeof(UrlRewriteResources))]
        public int DomainId { get; set; }

        [Display(Name = "app_url_field_type", ResourceType = typeof(UrlRewriteResources))]
        public int RewriteTypeId { get; set; }

        [Display(Name = "app_url_field_url_node", ResourceType = typeof(UrlRewriteResources))]
        public int? Node { get; set; }

        [StringLength(2048)]
        [Display(Name = "app_url_field_url_query", ResourceType = typeof(UrlRewriteResources))]
        public string Query { get; set; }

        [StringLength(2048)]
        [Display(Name = "app_url_field_url_real_mobile", ResourceType = typeof(UrlRewriteResources))]
        public string MobileRealUrl { get; set; }

        [StringLength(2048)]
        [Display(Name = "app_url_field_url_real_desktop", ResourceType = typeof(UrlRewriteResources))]
        public string DesktopRealUrl { get; set; }

        [StringLength(128)]
        [Display(Name = "app_url_field_url_rewritten", ResourceType = typeof(UrlRewriteResources))]
        [RegularExpression(@"^/[a-zA-Z0-9-_\./]*$", ErrorMessageResourceName = "app_url_rewrite_alphanumeric", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        public string RewrittenUrl { get; set; }

        [Display(Name = "app_url_field_url_title", ResourceType = typeof(UrlRewriteResources))]
        [Required(ErrorMessageResourceName = "app_url_title_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        [StringLength(120)]
        public string Title { get; set; }

        [Display(Name = "app_url_field_url_meta", ResourceType = typeof(UrlRewriteResources))]
        [Required(ErrorMessageResourceName = "app_url_meta_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        [StringLength(256)]
        public string MetaDescription { get; set; }

        [Display(Name = "app_url_field_url_h1", ResourceType = typeof(UrlRewriteResources))]
        [Required(ErrorMessageResourceName = "app_url_h1_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        [StringLength(128)]
        public string H1Tag { get; set; }

        [Display(Name = "app_url_field_url_seo", ResourceType = typeof(UrlRewriteResources))]
        [Required(ErrorMessageResourceName = "app_url_seo_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        [StringLength(2048)]
        [PropertyHtmlValidator("SeoData")]
        public string SeoData { get; set; }


        public bool IsDeleted { get; set; }

        public IEnumerable<UrlRewriteHistoryViewModel> History { get; set; }


    }
}
