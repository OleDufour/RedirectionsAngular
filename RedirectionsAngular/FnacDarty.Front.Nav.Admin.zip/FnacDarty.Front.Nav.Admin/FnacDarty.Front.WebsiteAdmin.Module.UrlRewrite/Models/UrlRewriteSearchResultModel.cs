using System;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models
{
    public class UrlRewriteSearchResultModel
    {
        public int RewriteId { get; set; }

        public int RewriteTypeId { get; set; }

        public int? Node { get; set; }

        public string Query { get; set; }

        public string MobileRealUrl { get; set; }

        public string DesktopRealUrl { get; set; }

        public string RewrittenUrl { get; set; }

        public string Title { get; set; }

        public string MetaDescription { get; set; }

        public string H1Tag { get; set; }

        public string SeoData { get; set; }
        
        public string ModificationUser { get; set; }

        public string PublicationUser { get; set; }

        public DateTime ModificationDate { get; set; }

        public DateTime? PublicationDate { get; set; }

        public DateTime? DeletionDate { get; set; }
    }
}
