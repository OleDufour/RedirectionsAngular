using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;
 

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models
{
    public class UrlRewriteSearchViewModel
    {
        [Display(Name = "app_domain", ResourceType = typeof(UrlRewriteResources))]
        public int Domain { get; set; }

        [Display(Name = "app_url_field_type", ResourceType = typeof(UrlRewriteResources))]
        public int? RewriteTypeId { get; set; }
    
        [Display(Name = "app_url_field_url_node", ResourceType = typeof(UrlRewriteResources))]
        public int? Node { get; set; }

        [Required(ErrorMessageResourceName = "app_url_query_mondatory", ErrorMessageResourceType = typeof(UrlRewriteResources))]
        [StringLength(2048)]
        [Display(Name = "app_url_field_url_query", ResourceType = typeof(UrlRewriteResources))]
        public string Query { get; set; }

        [Display(Name = "app_url_field_url_real_mobile", ResourceType = typeof(UrlRewriteResources))]
        public string MobileRealUrl { get; set; }

        [Display(Name = "app_url_field_url_real_desktop", ResourceType = typeof(UrlRewriteResources))]
        public string DesktopRealUrl { get; set; }

        [Display(Name = "app_url_field_url_rewritten", ResourceType = typeof(UrlRewriteResources))]
        public string RewrittenUrl { get; set; }

        [Display(Name = "app_url_field_url_title", ResourceType = typeof(UrlRewriteResources))]
        public string Title { get; set; }

        [Display(Name = "app_url_field_url_meta", ResourceType = typeof(UrlRewriteResources))]
        public string MetaDescription { get; set; }

        [Display(Name = "app_url_field_url_h1", ResourceType = typeof(UrlRewriteResources))]
        public string H1Tag { get; set; }

        public IEnumerable<DomainModel> AuthorizedDomainsReadOnly { get; set; }

        public IEnumerable<DomainModel> AuthorizedDomainsReadWrite { get; set; }

        public IEnumerable<UrlRewriteSearchResultModel> UrlRewriteSearchResultModels { get; set; }

        public bool IncludeDeletions{ get; set; }

}
}
