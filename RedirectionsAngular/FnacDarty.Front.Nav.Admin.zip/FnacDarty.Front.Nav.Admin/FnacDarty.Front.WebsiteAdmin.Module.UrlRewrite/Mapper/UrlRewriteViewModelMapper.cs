using System.Collections.Generic;
using System.Web;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Models;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Mapper
{
    public class UrlRewriteViewModelMapper : DtoModelMapperBase<DataTransfer.UrlRewrite, UrlRewriteViewModel>
    {
        public override UrlRewriteViewModel DtoToModel(DataTransfer.UrlRewrite dto)
        {
            return new UrlRewriteViewModel()
            {
                RewriteId = dto.RewriteId,
                RewriteTypeId = dto.RewriteTypeId,
                Node = dto.Node,
                Query = dto.Query,
                MobileRealUrl = dto.MobileRealUrl,
                DesktopRealUrl = dto.DesktopRealUrl,
                H1Tag = dto.H1Tag,
                MetaDescription = dto.MetaDescription,
                Title = dto.Title,
                RewrittenUrl = dto.RewrittenUrl,
                SeoData = dto.SeoData,
                DomainId = dto.DomainId,
                IsDeleted = dto.DeletionDate.HasValue
            };
        }

        public override DataTransfer.UrlRewrite ModelToDto(UrlRewriteViewModel viewModel)
        {
            var decodedQuery = HttpUtility.UrlDecode(viewModel.Query);
            var dto = new DataTransfer.UrlRewrite()
            {
                RewriteId = viewModel.RewriteId,
                RewriteTypeId = (short)viewModel.RewriteTypeId,
                Node = viewModel.Node,
                Query = decodedQuery,
                H1Tag = viewModel.H1Tag,
                MetaDescription = viewModel.MetaDescription,
                Title = viewModel.Title,
                RewrittenUrl = viewModel.RewrittenUrl,
                SeoData = viewModel.SeoData,
                DomainId = (short)viewModel.DomainId,
                UrlRewriteHistory = new List<UrlRewriteHistory>()
            };

            switch (viewModel.RewriteTypeId)
            {
                case (int)EnumRewriteType.Search:
                    dto.MobileRealUrl = $"/Mobile/Search/SearchText?{decodedQuery}";
                    dto.DesktopRealUrl = $"/Nav/Core/Search/ResultList.aspx?{decodedQuery}";
                    break;
                case (int)EnumRewriteType.Node:
                    dto.MobileRealUrl = $"/Mobile/Search/SearchLabel?PID={viewModel.Node}";
                    dto.DesktopRealUrl = $"/Nav/Core/Search/ResultList.aspx?PID={viewModel.Node}";
                    if (!string.IsNullOrEmpty(decodedQuery))
                    {
                        dto.MobileRealUrl += $"&{decodedQuery}";
                        dto.DesktopRealUrl += $"&{decodedQuery}";
                    }
                    break;
            }

            return dto;
        }
    }
}
