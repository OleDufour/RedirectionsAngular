using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public class UrlRewriteHistoryRepository : BaseRepository, IUrlRewriteHistoryRepository
    {
        private readonly IDbConnectionFactory dbConnectionFactory;

        internal static readonly string GetUrlRewriteHistorySp = "seo.sp_GetRewriteHistoryItems";
        internal static readonly string AddUrlRewriteHistorySp = "seo.sp_AddRewriteHistory";
        internal static readonly string AddPublicationInfosToUrlRewriteHistorySp = "seo.sp_UpdateRewritePublicationHistory";

        public UrlRewriteHistoryRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
            this.dbConnectionFactory = dbConnectionFactory;
        }

        public IEnumerable<UrlRewriteHistory> GetUrlRewriteHistories(int urlRewriteId)
        {
            return ExecuteSelect<UrlRewriteHistory>(GetUrlRewriteHistorySp, new Dictionary<string, object>()
            {
                {"RewriteId", urlRewriteId}
            });
        }

        public int AddUrlRewriteHistory(UrlRewriteHistory urlRewriteHistory)
        {
            return ExecuteScalar<int>(AddUrlRewriteHistorySp, new Dictionary<string, object>()
            {
                {"RewriteId", urlRewriteHistory.RewriteId},
                {"RewriteTypeId", urlRewriteHistory.RewriteTypeId},
                {"Node", urlRewriteHistory.Node},
                {"Query", urlRewriteHistory.Query},
                {"MobileRealUrl", urlRewriteHistory.MobileRealUrl},
                {"DesktopRealUrl", urlRewriteHistory.DesktopRealUrl},
                {"RewrittenUrl", urlRewriteHistory.RewrittenUrl},
                {"Title", urlRewriteHistory.Title},
                {"MetaDescription", urlRewriteHistory.MetaDescription},
                {"H1Tag", urlRewriteHistory.H1Tag},
                {"SeoData", urlRewriteHistory.SeoData},
                {"CreationDate", urlRewriteHistory.CreationDate},
                {"CreationUser", urlRewriteHistory.CreationUser},
                {"ActionTypeId", urlRewriteHistory.ActionTypeId}
            });
        }

        public bool AddPublicationInfosToHistory(int domainId, int publicationRequestId)
        {
            using (var connection = dbConnectionFactory.CreateConnection())
            {
                var cmd = (SqlCommand)CreateCommand(AddPublicationInfosToUrlRewriteHistorySp, connection, new Dictionary<string, object>()
                {
                    {"DomainId", domainId},
                    {"PublicationRequestId", publicationRequestId}
                });

                return ExecuteNonQuery(AddPublicationInfosToUrlRewriteHistorySp, cmd) > 0;
            }
        }

        private static DataTable CreateDataTable(IEnumerable<int> ids)
        {
            var table = new DataTable();
            table.Columns.Add("RewriteId", typeof(int));
            foreach (var id in ids)
            {
                table.Rows.Add(id);
            }
            return table;
        }
    }
}
