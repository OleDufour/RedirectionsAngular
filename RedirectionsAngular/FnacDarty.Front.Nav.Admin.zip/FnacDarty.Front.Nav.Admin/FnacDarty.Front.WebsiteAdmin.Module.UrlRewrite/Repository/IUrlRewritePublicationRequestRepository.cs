using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;
using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public interface IUrlRewritePublicationRequestRepository : IPublicationRequestRepository
    {
        IEnumerable<UrlRewritePublicationRequest> GetPublicationRequest(PublicationRequestCriteria criteria);

        UrlRewritePublicationRequest GetCurrentRewritePublicationForDomain(int domainId);
        IEnumerable<UrlRewriteHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId);
    }
}
