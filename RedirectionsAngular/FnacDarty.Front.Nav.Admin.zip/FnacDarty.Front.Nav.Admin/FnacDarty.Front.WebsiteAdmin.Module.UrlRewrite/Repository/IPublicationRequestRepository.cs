using System;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public interface IPublicationRequestRepository
    {
        int AddPublicationRequest(int domainId, DateTime publicationDate, string publicationUser, bool isProduction);
    }
}
