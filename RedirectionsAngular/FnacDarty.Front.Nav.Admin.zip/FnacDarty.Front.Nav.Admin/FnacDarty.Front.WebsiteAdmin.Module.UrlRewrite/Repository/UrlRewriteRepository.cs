using System;
using System.Collections.Generic;
using System.Data;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public class UrlRewriteRepository : BaseRepository, IUrlRewriteRepository
    {

        internal static readonly string GetUrlRewriteByIdSp = "seo.sp_GetRewriteById";
        internal static readonly string UpdateUrlRewriteSp = "seo.sp_UpdateRewrite";
        internal static readonly string AddUrlRewriteSp = "seo.sp_AddRewrite";
        internal static readonly string SearchSp = "seo.sp_GetRewriteResults";
        internal static readonly string DeleteUrlRewriteSp = "seo.sp_UpdateToDeleteRewrite";

        internal static readonly string GetDraftUrlsRewrittenSp = "seo.sp_GetDraftUrlsRewritten";
        internal static readonly string GetUrlsByDomainSp = "seo.sp_GetRewriteByDomainId";
        internal static readonly string GetUrlsByPublicationDateSp = "seo.sp_GetModifiedRewrite";

        internal static readonly string GetUrlRewritesByRewrittenUrlSp = "seo.sp_GetRewritesByRewrittenUrl";
        internal static readonly string GetUrlRewritesByNodeAndQuerySp = "seo.sp_GetRewritesByNodeAndQuery";
        internal static readonly string GetUrlRewritesByTitleSp = "seo.sp_GetRewritesByTitle";
        internal static readonly string GetUrlRewritesByMetaDescriptionSp = "seo.sp_GetRewritesByMetaDescription";

        internal static readonly string GetRewritesForPagingSp = "seo.sp_GetRewritesForPaging";

        public UrlRewriteRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
        }


        #region Methods
        
        public DataTransfer.UrlRewrite GetUrlRewrite(int urlRewriteId)
        {
            return ExecuteFirstOrDefault<DataTransfer.UrlRewrite>(GetUrlRewriteByIdSp, new Dictionary<string, object>()
            {
                {"RewriteId", urlRewriteId }
            });
        }

        public int AddUrlRewrite(DataTransfer.UrlRewrite urlRewrite)
        {
            return ExecuteScalar<int>(AddUrlRewriteSp, new Dictionary<string, object>()
            {
                {"DomainId", urlRewrite.DomainId},
                {"RewriteTypeId", urlRewrite.RewriteTypeId},
                {"Node", urlRewrite.Node},
                {"Query", urlRewrite.Query},
                {"MobileRealUrl", urlRewrite.MobileRealUrl},
                {"DesktopRealUrl", urlRewrite.DesktopRealUrl},
                {"RewrittenUrl", urlRewrite.RewrittenUrl},
                {"Title", urlRewrite.Title},
                {"MetaDescription", urlRewrite.MetaDescription},
                {"H1Tag", urlRewrite.H1Tag},
                {"SeoData", urlRewrite.SeoData},
                {"CreationDate", urlRewrite.CreationDate},
                {"CreationUser", urlRewrite.CreationUser},
            });
        }

        public bool UpdateUrlRewrite(DataTransfer.UrlRewrite urlRewrite)
        {
            return ExecuteNonQuery(UpdateUrlRewriteSp, new Dictionary<string, object>()
            {
                {"RewriteId", urlRewrite.RewriteId},
                {"DomainId", urlRewrite.DomainId},
                {"RewriteTypeId", urlRewrite.RewriteTypeId},
                {"Node", urlRewrite.Node},
                {"Query", urlRewrite.Query},
                {"MobileRealUrl", urlRewrite.MobileRealUrl},
                {"DesktopRealUrl", urlRewrite.DesktopRealUrl},
                {"RewrittenUrl", urlRewrite.RewrittenUrl},
                {"Title", urlRewrite.Title},
                {"MetaDescription", urlRewrite.MetaDescription},
                {"H1Tag", urlRewrite.H1Tag},
                {"SeoData", urlRewrite.SeoData},
                {"ModificationDate", urlRewrite.ModificationDate},
                {"ModificationUser", urlRewrite.ModificationUser},
            }) > 0;
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByDomain(int domainId)
        {
            return ExecuteSelect<DataTransfer.UrlRewrite>(GetUrlsByDomainSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId}
            });
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlsModifiedSince(int domainId, DateTime modificationDate)
        {
            return ExecuteSelect<DataTransfer.UrlRewrite>(GetUrlsByPublicationDateSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId},
                {"ModificationDate", modificationDate}
            });
        }

        public bool DeleteUrlRewrite(DataTransfer.UrlRewrite urlRewrite)
        {
            return ExecuteNonQuery(DeleteUrlRewriteSp,
                new Dictionary<string, object>
                {
                    {"RewriteId", urlRewrite.RewriteId},
                    {"DeletionDate", urlRewrite.DeletionDate},
                    {"DeletionUser", urlRewrite.DeletionUser}
                }) > 0;
        }

        public IEnumerable<DataTransfer.UrlRewriteHistory> GetDraftUrlRewrite(int domainId)
        {
            return ExecuteSelect<DataTransfer.UrlRewriteHistory>(GetDraftUrlsRewrittenSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId}
            });
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByNodeAndQuery(int domainId, int? node, string query)
        {
            return ExecuteSelect<DataTransfer.UrlRewrite>(GetUrlRewritesByNodeAndQuerySp, new Dictionary<string, object>()
            {
                {"DomainId", domainId},
                {"Node", node},
                {"Query", query}
            });
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByRewrittenUrl(int domainId, string rewrittenUrl)
        {
            return ExecuteSelect<DataTransfer.UrlRewrite>(GetUrlRewritesByRewrittenUrlSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId},
                {"RewrittenUrl", rewrittenUrl}
            });
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByTitle(int domainId, string title)
        {
            return ExecuteSelect<DataTransfer.UrlRewrite>(GetUrlRewritesByTitleSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId},
                {"Title", title}
            });
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByMetaDescription(int domainId, string metaDescription)
        {
            return ExecuteSelect<DataTransfer.UrlRewrite>(GetUrlRewritesByMetaDescriptionSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId},
                {"MetaDescription", metaDescription}
            });
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesForPaging(DataTransfer.UrlRewritePaging r, out int filteredCount, out int totalCount)
        {
            using (var cnx = CreateConnection())
            {
                var cmd = CreateCommand(GetRewritesForPagingSp, cnx);
                CreateParameter(cmd, "DomainId", r.DomainId);
                CreateParameter(cmd, "Node", r.Node);
                CreateParameter(cmd, "Query", r.Query);
                CreateParameter(cmd, "RewrittenUrl", r.RewrittenUrl);
                CreateParameter(cmd, "Title", r.Title);
                CreateParameter(cmd, "MetaDescription", r.MetaDescription);
                CreateParameter(cmd, "H1Tag", r.H1Tag);
                CreateParameter(cmd, "RewriteTypeId", r.RewriteTypeId);                
                CreateParameter(cmd, "PageSize", r.PageSize);
                CreateParameter(cmd, "PageNo", r.PageNo);
                CreateParameter(cmd, "OrderByColumn", r.OrderByColumn);
                CreateParameter(cmd, "AscOrDesc", r.AscOrDesc);
                CreateParameter(cmd, "IncludeDeletions", r.IncludeDeletions);
                var filteredCountParam = CreateOutPutParameter(cmd, "RecordCount", DbType.Int32);
                var totalCountParam = CreateOutPutParameter(cmd, "TotalRecordCount", DbType.Int32);
                var res = ExecuteSelect<DataTransfer.UrlRewrite>(cmd);
                filteredCount = GetOutPutIntParameter(filteredCountParam);
                totalCount = GetOutPutIntParameter(totalCountParam);
                return res;
            }          
        }

        private static int GetOutPutIntParameter(IDbDataParameter intParam)
        {
            int res = 0;
            if (intParam.Value != DBNull.Value)
                res = Convert.ToInt32(intParam.Value);
            return res;
        }

        #endregion
    }
}
