
namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public interface IUrlRewritePublicationRepository
    {
        bool PublishUrlRewrite(int publicationRequestId, int domainId, bool isProduction);

    }
}
