using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public interface IUrlRewriteRepository
    {
        DataTransfer.UrlRewrite GetUrlRewrite(int urlRewriteId);

        int AddUrlRewrite(DataTransfer.UrlRewrite urlRewrite);

        bool UpdateUrlRewrite(DataTransfer.UrlRewrite urlRewrite);       

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByDomain(int domainId);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByNodeAndQuery(int domainId, int? node, string query);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByTitle(int domainId, string title);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByMetaDescription(int domainId, string metaDescription);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesByRewrittenUrl(int domainId, string rewrittenUrl);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlsModifiedSince(int domainId, DateTime modificationDate);

        bool DeleteUrlRewrite(DataTransfer.UrlRewrite urlRewrite);

        IEnumerable<UrlRewriteHistory> GetDraftUrlRewrite(int domainId);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesForPaging(UrlRewritePaging r, out int filteredCount, out int totalCount);
    }
}
