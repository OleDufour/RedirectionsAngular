using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public class UrlRewritePublicationRepository : BaseRepository, IUrlRewritePublicationRepository
    {

        internal static readonly string PublishUrlRewriteForDomainSp = "seo.sp_PublishDomainRewrites";
        internal static readonly string GetCurrentRewritePublicationForDomainSp = "seo.sp_GetCurrentRewritePublication";
        internal static readonly string PublishPreviewUrlRewriteForDomainSp = "seo.sp_PublishPreviewDomainRewrites";

        public UrlRewritePublicationRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
        }

        public bool PublishUrlRewrite(int publicationRequestId, int domainId, bool isProduction)
        {
            var procedureName = isProduction
                    ? PublishUrlRewriteForDomainSp
                    : PublishPreviewUrlRewriteForDomainSp;

            return ExecuteNonQuery(procedureName, new Dictionary<string, object>()
            {
                {"PublicationRequestId", publicationRequestId},
                {"DomainId", domainId}
            }) > 0;
        }
    }
}
