using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public class UrlRewritePublicationRequestRepository : BaseRepository, IUrlRewritePublicationRequestRepository
    {

        internal static readonly string AddRewritePublicationRequestSp = "seo.sp_AddRewritePublicationRequest";
        internal static readonly string GetRewritePublicationRequestSp = "seo.sp_GetRewritePublicationRequest";
        internal static readonly string AddPreviewRewritePublicationRequestSp = "seo.sp_AddPreviewRewritePublicationRequest";
        internal static readonly string GetCurrentRewritePublicationForDomainSp = "seo.sp_GetCurrentRewritePublication";
        internal static readonly string GetRewritePublicationRequestDetailsSp = "seo.sp_GetRewritePublicationRequestDetails";

        public UrlRewritePublicationRequestRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
        }

        public int AddPublicationRequest(int domainId, DateTime publicationDate, string publicationUser, bool isProduction)
        {
            var procedureName = isProduction
                ? AddRewritePublicationRequestSp
                : AddPreviewRewritePublicationRequestSp;

            return ExecuteScalar<int>(procedureName, new Dictionary<string, object>
            {
                {"DomainId", domainId},
                {"PublicationDate", publicationDate},
                {"PublicationUser", publicationUser}
            });
        }

        public IEnumerable<DataTransfer.UrlRewritePublicationRequest> GetPublicationRequest(DataTransfer.PublicationRequestCriteria criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            return ExecuteSelect<DataTransfer.UrlRewritePublicationRequest>(GetRewritePublicationRequestSp, new Dictionary<string, object>()
            {
                {"DomainId", criteria.DomainId}
            });
        }

        public DataTransfer.UrlRewritePublicationRequest GetCurrentRewritePublicationForDomain(int domainId)
        {
            return ExecuteFirstOrDefault<DataTransfer.UrlRewritePublicationRequest>(GetCurrentRewritePublicationForDomainSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId}
            });
        }

        public IEnumerable<DataTransfer.UrlRewriteHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId)
        {
            return ExecuteSelect<DataTransfer.UrlRewriteHistory>(GetRewritePublicationRequestDetailsSp, new Dictionary<string, object>()
            {
                {"PublicationRequestId", publicationRequestId},
                {"DomainId", domainId},

            });
        }
    }
}
