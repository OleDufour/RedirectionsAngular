using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public class UrlRewriteDataTablesRepository : BaseDataTablesRepository<DataTransfer.UrlRewrite>
    {
        public UrlRewriteDataTablesRepository(IDbConnectionFactory dbConnectionFactory) : base(dbConnectionFactory) { }

        public override string TableName => "seo.Rewrite";

        public override string ConnectionString { get; }

        public override Dictionary<string, string> ColumnNameMapping => new Dictionary<string, string>()
        {
            { "RewriteId", "RewriteId" },
            { "Node", "Node" },
            { "Query", "Query" },
            { "RewrittenUrl", "RewrittenUrl" },
            { "Title", "Title" },
            { "MetaDescription", "MetaDescription" },
            { "H1Tag", "H1Tag" },
        };
    }
}
