using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository
{
    public interface IUrlRewriteHistoryRepository
    {
        IEnumerable<UrlRewriteHistory> GetUrlRewriteHistories(int urlRewriteId);
        int AddUrlRewriteHistory(UrlRewriteHistory urlRewriteHistory);
        bool AddPublicationInfosToHistory(int domainId, int publicationRequestId);
    }
}
