var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.UrlRewrite = fnacdarty.Portal.Repository.UrlRewrite || {};

define(["jquery", "core", "template", "datatables", "moment", "messenger", "urlRewriteHistoryComponent", "Vue", "dropdownComponent"],

    function ($, core, template, datatables, moment, messenger, urlRewriteHistoryComponent, Vue, dropdownComponent) {

        function addDeleteEvent() {
            //Add click event for anchor
            $(".js-urlrewrite-delete").unbind("click");
            $(".js-urlrewrite-delete").click(function (e) {
                var urlrewriteid = $(this).attr('data-urlrewriteid');
                var msg = Messenger().post({
                    message: fnacdarty.Portal.Repository.UrlRewrite.Wording.DeleteQuestion,
                    type: 'info',
                    actions: {
                        cancel: {
                            label: fnacdarty.Portal.Repository.UrlRewrite.Wording.No,
                            action: function () {
                                return msg.update({
                                    message: fnacdarty.Portal.Repository.UrlRewrite.Wording.DeleteCanceled,
                                    type: 'success',
                                    actions: true,
                                    showCloseButton: true
                                });
                            }
                        },
                        confirm: {
                            label: fnacdarty.Portal.Repository.UrlRewrite.Wording.Yes,
                            action: function () {
                                fnacdarty.Portal.Repository.UrlRewrite.Delete(urlrewriteid,
                                    function (response) {
                                        if (response.Success) {
                                            msg.update({
                                                message: response.Message,
                                                type: 'success',
                                                actions: true,
                                                showCloseButton: true
                                            });
                                            $(`.js-urlrewrite-delete[data-urlrewriteid='${urlrewriteid}']`).css('visibility', 'hidden');
                                        } else {
                                            msg.update({
                                                message: response.Message,
                                                type: 'error',
                                                actions: false,
                                                showCloseButton: true
                                            });
                                        }
                                    });
                            }
                        }
                    }
                });
                return false;
            });
        }

        // module definition
        return {
            ready: function (model) {


                let colummNames = ["RewriteId", "Node", "Query", "RewrittenUrl", "Title", "MetaDescription", "H1Tag", "RewriteTypeId"];

                let columnDefinition = [
                    { "data": colummNames[0] },                     // RewriteId
                    { "data": colummNames[1], "orderable": false }, // Node
                    { "data": colummNames[2] },                     // Query
                    { "data": colummNames[3], "orderable": false }, // RewrittenUrl
                    { "data": colummNames[4] },                     // Title
                    { "data": colummNames[5], "orderable": false },  // MetaDescription
                    { "data": colummNames[6], "orderable": false }, // H1Tag
                    { "data": colummNames[7] }                      // RewriteType
                ];

                var viewModel = {
                    SearchFilters: {
                        Domain: '',
                        Node: null,
                        Query: '',
                        RewrittenUrl: '',
                        Title: '',
                        MetaDescription: '',
                        H1Tag: '',
                        RewriteType: null,
                        IncludeDeletions: false
                    },
                
                    UrlRewriteSearchResultModels: model.UrlRewriteSearchResultModels,
                    ShowResult: false,
                    HistoryRealUrl: "",
                    HistoryItems: [],
                    ReadOnly: true,
                    AuthorizedDomainsReadWrite: model.AuthorizedDomainsReadWrite,
                    AuthorizedDomainsReadOnly: model.AuthorizedDomainsReadOnly,
                    IncludeDeletions: model.IncludeDeletions                
                };

                var app = new Vue({
                    el: '#main-content',

                    data: viewModel,

                    components: {
                        urlRewriteHistoryComponent, dropdownComponent, 
                    },
                    methods: {
                        updateDomain: function (selectedOption) {
                            this.SearchFilters.Domain = selectedOption.value;                            
                        },

                        updateTemplate: function (selectedOption) {
                            this.SearchFilters.RewriteType = selectedOption.value;
                            this.SearchFilters.Node = null;
                        },

                        SearchRewrites: function () {
                            template.displayLoader();
                            var $table = $("#Rewrite-Table");
                            var vm = this;
                            $table.dataTable({
                                searching: false,
                                autoWidth: false,
                                order: [[0, "asc"]],
                                responsive: true,
                                language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                                lengthMenu: [
                                    [10, 25, 50, 100],
                                    [10, 25, 50, 100]
                                ],
                                processing: true,
                                serverSide: true,
                                ajax: {
                                    url: fnacdarty.Portal.Repository.UrlRewrite.DataTableUrl,
                                    method: "POST",
                                    "data": function (d) {
                                        d.domainId = vm.SearchFilters.Domain;
                                        d.IncludeDeletions = vm.SearchFilters.IncludeDeletions;
                                        d.columns[1].search.value = vm.SearchFilters.Node;
                                        d.columns[2].search.value = vm.SearchFilters.Query;
                                        d.columns[3].search.value = vm.SearchFilters.RewrittenUrl;
                                        d.columns[4].search.value = vm.SearchFilters.Title;
                                        d.columns[5].search.value = vm.SearchFilters.MetaDescription;
                                        d.columns[6].search.value = vm.SearchFilters.H1Tag;
                                        d.columns[7].search.value = vm.SearchFilters.RewriteType;
                                    }
                                },
                                bDestroy: true,
                                columns: columnDefinition,
                                aoColumnDefs: [

                                    {
                                        "targets": [0],
                                        "visible": false
                                    },
                                    {
                                        "aTargets": [7],
                                        "width": '100px',

                                        "mData": "RewriteId",
                                      "mRender": function (data, type, full) {
                                        
                                            var hidden = full.DeletionDate ? "style='visibility: hidden'" : ''; // l'élément doit prendre de la place
                                            var result = '<div class="btn-group">';
                                            result += full.ReadOnly ? '' : '<a href="' + fnacdarty.Portal.Repository.UrlRewrite.EditUrl + '/' + full.RewriteId + '" class="btn btn-sm btn-info"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-container="body" data-original-title="' + fnacdarty.Portal.Repository.UrlRewrite.Wording.Modify + '" data-placement="top"> <i class="fa fa-pencil"></i></a>';
                                            result += '<a ' + hidden + 'data-urlrewriteid="' + full.RewriteId + '" class="btn btn-sm btn-danger js-urlrewrite-delete"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-container="body" data-original-title="' + fnacdarty.Portal.Repository.UrlRewrite.Wording.Delete + '"  data-placement="top"> <i class="fa fa-trash"></i></a>';
                                            result += '<a data-urlrewriteid="' + full.RewriteId + '" class="btn btn-sm btn-warning " data-toggle="modal" data-container="body" data-target="#HistoryModal" rel="tooltip" data-animate="animated tada" data-original-title="' + fnacdarty.Portal.Repository.UrlRewrite.Wording.History + '" data-placement="top"><i class="fa fa-history"></i></a>';
                                            result += '</div>';
                                            return result;
                                        }
                                    }
                                ],
                                drawCallback: function (settings) {
                                    template.hideLoader();
                                    template.tooltipsPopovers();
                                    addDeleteEvent();
                                }
                            });

                            vm.ShowResult = true;

                            setTimeout(function () {
                                $('html,body').animate({
                                    scrollTop: $("#searchResult").offset().top
                                }, 'slow');
                            }, 200);
                        }
                    },

                    mounted() {
                        this.SearchFilters.Domain = dropdown_domain_selection.value;
                    },

                    computed: {
                        isSearchMode: function () {
                            return this.SearchFilters.RewriteType != '' && this.SearchFilters.RewriteType === 1;
                        },

                        isNodeMode: function () {
                            return this.SearchFilters.RewriteType != '' && this.SearchFilters.RewriteType === 2;
                        }
                    }
                });

                window.app = app;

                //common init template js
                template.intiJsTemplate();

                $("#HistoryModal").on("shown.bs.modal", function (event) {
                    var button = $(event.relatedTarget);
                    var urlRewriteId = button.data("urlrewriteid");
                    app.HistoryItems = [];
                    template.displayLoader();

                    // Récupération de l'historique
                    fnacdarty.Portal.Repository.UrlRewrite.GetHistory(urlRewriteId ,
                        function (response) {
                            if (response.Success) {
                                app.HistoryRealUrl = response.Data.RealUrl;
                                app.HistoryItems = response.Data.HistoryItems;
                            } else {
                                app.HistoryRealUrl = "";
                                app.HistoryItems = [];
                            }
                            template.hideLoader();
                        });
                });
            }
        };
    });
