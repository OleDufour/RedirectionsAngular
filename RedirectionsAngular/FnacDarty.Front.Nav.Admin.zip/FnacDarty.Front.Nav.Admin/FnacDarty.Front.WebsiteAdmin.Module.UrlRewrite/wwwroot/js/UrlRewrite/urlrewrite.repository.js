var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.UrlRewrite = fnacdarty.Portal.Repository.UrlRewrite || {};


fnacdarty.Portal.Repository.UrlRewrite.Search = function (model, callback) {
  $.ajax({
    type: "POST",
    url: fnacdarty.Portal.Repository.UrlRewrite.SearchUrl,
    dataType: "json",
    data: model,
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.Search" });
    }
  });
};

fnacdarty.Portal.Repository.UrlRewrite.GetHistory = function (model, callback) {
  $.ajax({
    type: "GET",
    url: fnacdarty.Portal.Repository.UrlRewrite.HistoryUrl+'/'+ model,
    dataType: "json",
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.History" });
    }
  });
};

fnacdarty.Portal.Repository.UrlRewrite.Save = function (model, callback) {
  $.ajax({
    type: "POST",
    url: fnacdarty.Portal.Repository.UrlRewrite.SaveUrl,
    dataType: "json",
    data: model,
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.Save" });
    }
  });
};


fnacdarty.Portal.Repository.UrlRewrite.Delete = function (model, callback) {

  $.ajax({
    type: "POST",
    url: fnacdarty.Portal.Repository.UrlRewrite.DeleteUrl + "/" + model,
    dataType: "json",
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.Delete" });
    }
  });
};


fnacdarty.Portal.Repository.UrlRewrite.Publish = function (model, callback) {
  $.ajax({
    type: "POST",
    url: fnacdarty.Portal.Repository.UrlRewrite.PublishRewriteUrl + '/' + model.domainId + '/' + model.isProduction,
    dataType: "json",
    data: model,
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.Publish" });
    }
  });
};



fnacdarty.Portal.Repository.UrlRewrite.GetPublicationHistory = function (model, callback) {
  $.ajax({
    type: "GET",
    url: fnacdarty.Portal.Repository.UrlRewrite.GetPublicationHistoryUrl + '/' + model.domainId,
    dataType: "json",
    data: model,
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.GetPublicationHistory" });
    }
  });
};


fnacdarty.Portal.Repository.UrlRewrite.GetdraftUrlsRewritten = function (model, callback) {
  $.ajax({
    type: "GET",
    url: fnacdarty.Portal.Repository.UrlRewrite.GetdraftUrlsRewrittenUrl + '/' + model.domainId,
    dataType: "json",
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.GetdraftUrlsRewritten" });
    }
  });
};

fnacdarty.Portal.Repository.UrlRewrite.GetPublicationDetails = function (model, callback) {
  $.ajax({
    type: "GET",
    url: fnacdarty.Portal.Repository.UrlRewrite.GetPublicationDetailsUrl + '/' + model.publicationRequestId + '/' + model.domainId,
    dataType: "json",
    data: model,
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : UrlRewrite.GetPublicationHistory" });
    }
  });
};
