var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.UrlRewrite = fnacdarty.Portal.Repository.UrlRewrite || {};

define(["jquery", "core", "template", "Vue", "dropdownComponent", "urlRewriteHistoryComponent", "inputCounterComponent", "vuelidate", "validators"],

    function ($, core, template, Vue, dropdownComponent, urlRewriteHistoryComponent, inputCounterComponent, vuelidate, validators) {

        // module definition

        return {
            ready: function (model) {

                Vue.use(vuelidate.default);

                var app = new Vue({

                    el: '#main-content',

                    data() {
                        return {
                            viewModel: model
                        };
                    },

                    validations() {
                        var viewModel = {};
                        if (this.isSearchMode) {
                            viewModel = {
                                Node: {
                                },
                                Query: {
                                    required: validators.required,
                                },
                                RewrittenUrl: {
                                    required: validators.required,
                                },
                                Title: {
                                    required: validators.required
                                },
                                H1Tag: {
                                    required: validators.required
                                },
                                MetaDescription: {
                                    required: validators.required
                                },
                                SeoData: {
                                    required: validators.required
                                }
                            };
                        } else {
                            viewModel = {
                                Node: {
                                    numeric: validators.numeric,
                                    minValue: validators.minValue(1),
                                    required: validators.required
                                },
                                Query: {
                                },
                                RewrittenUrl: {
                                    required: validators.required
                                },
                                Title: {
                                    required: validators.required
                                },
                                H1Tag: {
                                    required: validators.required
                                },
                                MetaDescription: {
                                    required: validators.required
                                },
                                SeoData: {
                                    required: validators.required
                                }
                            };
                        }
                        return { viewModel: viewModel };
                    },

                    components: {
                        dropdownComponent,
                        urlRewriteHistoryComponent,
                        inputCounterComponent
                    },

                    mounted() {
                        //init common js for template
                        template.intiJsTemplate();
                    },

                    methods:
                    {
                        save: function () {
                            this.$v.viewModel.$touch();
                            if (!this.isAlphanumericUnderscorePatternOk()) {
                                template.showMessage("Le formulaire n'est pas valide", "error");
                               return;
                            }
                            template.displayLoader();
                            if (!this.$v.viewModel.$invalid) {
                                var vm = this;
                                fnacdarty.Portal.Repository.UrlRewrite.Save(vm.viewModel,
                                    function (response) {
                                            template.hideLoader();                                                   
                                        if (response.Success && response.Data != null) {
                                                template.showMessage(response.Message, "info");    
                                            setTimeout(function () {
                                                vm.viewModel.RewriteId = response.Data.RewriteId;
                                                vm.viewModel.History = response.Data.historyitems;

                                            }, 1000);
                                            }
                                        else // element has been deleted or doesn't exist at all in the db.
                                            template.showMessage(response.Message, "error");   
                                    });
                            }
                            else {
                                template.showMessage("Le formulaire n'est pas valide", "error");
                            }
                            template.hideLoader();
                        },

                        updateDomain: function (selectedOption) {
                            this.viewModel.DomainId = selectedOption.value;
                        },

                        updateTemplate: function (selectedOption) {
                            this.viewModel.RewriteTypeId = selectedOption.value;
                            this.viewModel.Node = null;
                        },

                        duplicate: function () {
                            var duplicateUrl = `${fnacdarty.Portal.Repository.UrlRewrite.DuplicateUrl}${this.viewModel.RewriteId}`;
                            var win = window.open(duplicateUrl , '_blank');
                            win.focus();
                        },

                        formatRewrittenUrl: function () {
                            if (!$.isEmptyObject(this.viewModel.RewrittenUrl) && !this.viewModel.RewrittenUrl.startsWith('/')) {
                                this.viewModel.RewrittenUrl = "/" + this.viewModel.RewrittenUrl;
                            }
                        },
                        isAlphanumericUnderscorePatternOk: function () {
                            if (!this.viewModel.RewrittenUrl) return true;
                            var rewrittenUrlWithoutPrefix = '';
                            if (this.viewModel.RewrittenUrl.startsWith('/'))
                                rewrittenUrlWithoutPrefix = this.viewModel.RewrittenUrl.substring(1, this.viewModel.RewrittenUrl.length);
                            else
                                rewrittenUrlWithoutPrefix = this.viewModel.RewrittenUrl;
                            return regexRewrittenUrl.test(rewrittenUrlWithoutPrefix);
                        }

                    },

                    watch: {
                    },

                    computed: {
                        isUpdateMode: function () {
                            return this.viewModel.RewriteId > 0;
                        },

                        isSearchMode: function () {
                            return this.viewModel.RewriteTypeId === 1;
                        },

                        isDeletedRewrite: function () {
                            return this.viewModel.IsDeleted;
                        },

                        isNodeMode: function () {
                            return this.viewModel.RewriteTypeId === 2;
                        }
                    }
                });

                window.app = app;
            }
        };
    });
