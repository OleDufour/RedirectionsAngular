var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.UrlRewrite = fnacdarty.Portal.Repository.UrlRewrite || {};

define(["jquery", "core", "template", "Vue"],

    function ($, core, template, Vue) {

        let publicationDetailsComponent = Vue.component('data-table-urlrewrite-publication-details', {
            template: '<table class="table table-striped display wrapper" width="100%"></table>',
            props: ['publicationsdetails', 'showhistorybutton', 'modalid'],
            data() {
                return {
                    headers: [
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Node },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Query },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.RewrittenUrl },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Title },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Meta },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.H1 },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Seo },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.DateAction },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.ActionType },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.UserAction },
                        { title: '#' }
                    ],
                    rows: [],
                    dtHandle: null,
                    models: []
                };
            },
            watch: {
                publicationsdetails(val) {
                    console.log('publicationsdetails');
                    console.log(val);
                    this.updateData(val);
                }
            },
            methods: {
                updateData(data) {
                    var vm = this;
                    vm.models = data;
                    vm.rows = [];
                    
                    if (vm.models && vm.models.length > 0) {
                        vm.models.forEach(function (item) {
                            var row = [];

                            var stateRow = '';
                            if (item.ActionType === "Delete") {
                                stateRow = `<span class="badge badge-warning">${fnacdarty.Portal.Repository.UrlRewrite.Wording.Deleted}</span>`;
                            } else if (item.ActionType === "Add") {
                                stateRow = `<span class="badge badge-success">${fnacdarty.Portal.Repository.UrlRewrite.Wording.Added}</span>`;
                            } else if (item.ActionType === "Update") {
                                stateRow = `<span class="badge badge-secondary">${fnacdarty.Portal.Repository.UrlRewrite.Wording.Modified}</span>`;
                            }

                            var actionsRow = '<div class="btn-group">';
                            //edit button
                            actionsRow = actionsRow +
                                '<a href="'
                                + fnacdarty.Portal.Repository.UrlRewrite.EditUrl
                                + '/' + item.RewriteId
                                + '" target="_blank" class=" btn btn-sm btn-info" rel="tooltip" data-container="body" data-animate="animated tada" data-toggle="tooltip" data-original-title="'
                                + fnacdarty.Portal.Repository.UrlRewrite.Wording.Modify
                                + '"> <i class="fa fa-pencil"></i></a>';

                            if (vm.showhistorybutton) {
                                actionsRow = actionsRow + '<button style="margin-right:5px;" class="btn btn-sm btn-warning" data-urlrewriteid="'
                                    + item.RewriteId
                                    + '" data-toggle="modal" data-toggle="modal" data-container="body" data-target="#' + vm.modalid + '" rel="tooltip" data-animate="animated tada" data-original-title="'
                                    + fnacdarty.Portal.Repository.UrlRewrite.Wording.History
                                    + '"><i class="fa fa-history"></i></button>';
                            }
                            actionsRow = actionsRow + '</div>';


                            row.push(item.Node);
                            row.push(item.Query);
                            row.push(item.RewrittenUrl);
                            row.push(item.Title);
                            row.push(item.MetaDescription);
                            row.push(item.H1Tag);
                            row.push(item.SeoData);
                            row.push(item.CreationDate);
                            row.push(stateRow);
                            row.push(item.CreationUser);
                            
                            row.push(actionsRow);

                            vm.rows.push(row);
                        });
                    }
                    vm.dtHandle.clear();
                    vm.dtHandle.rows.add(vm.rows);
                    vm.dtHandle.draw();

                }
            },
            mounted() {
                var vm = this;
                vm.dtHandle = $(this.$el).DataTable({
                    columns: vm.headers,
                    data: vm.rows,
                    responsive: true,
                    columnDefs: [
                        { width: 70, targets: 10, "orderable": false }
                    ],
                    language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                    aLengthMenu: [
                        [10, 25, 50, 100, -1],
                        [10, 25, 50, 100, "Tous"]
                    ],
                    bDestroy: true,
                    drawCallback: function () {
                        template.hideLoader();
                        template.tooltipsPopovers();
                    }
                });
            }
        });

        // module definition
        return publicationDetailsComponent;
    });
