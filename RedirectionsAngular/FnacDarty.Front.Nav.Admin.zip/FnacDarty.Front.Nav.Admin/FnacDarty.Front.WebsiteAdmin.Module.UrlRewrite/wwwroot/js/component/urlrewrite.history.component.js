var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.UrlRewrite = fnacdarty.Portal.Repository.UrlRewrite || {};

define(["jquery", "core", "template", "Vue"],

    function ($, core, template, Vue) {

        let InitRows = function (items) {
            var rows = [];
            if (Array.isArray(items)) {
                items.forEach(function (item) {
                    var row = [];

                    var stateRow = '';
                    if (item.ActionType === "Delete") {
                        stateRow = `<span class="badge badge-warning">${fnacdarty.Portal.Repository.UrlRewrite.Wording.Deleted}</span>`;
                    } else if (item.ActionType === "Add") {
                        stateRow = `<span class="badge badge-success">${fnacdarty.Portal.Repository.UrlRewrite.Wording.Added}</span>`;
                    } else if (item.ActionType === "Update") {
                        stateRow = `<span class="badge badge-secondary">${fnacdarty.Portal.Repository.UrlRewrite.Wording.Modified}</span>`;
                    }

                    row.push(item.Node);
                    row.push(item.Query);
                    row.push(item.RewrittenUrl);
                    row.push(item.Title);
                    row.push(item.MetaDescription);
                    row.push(item.H1Tag);
                    row.push(item.SeoData);
                    row.push(item.CreationDate);
                    row.push(stateRow);
                    row.push(item.CreationUser);
                    row.push(item.PublicationDate);
                    row.push(item.PublicationUser);
                    row.push(item.PublicationRequestId);

                    rows.push(row);
                });
            }
            return rows;
        };

        let historyComponent = Vue.component('data-table-rewrite-history', {
            template: '<table class="table table-striped display wrapper" width="100%"></table>',
            props: ['historyitems'],
            data() {
                return {
                    headers: [
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Node },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Query },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.RewrittenUrl },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Title },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Meta },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.H1 },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.Seo },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.DateAction },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.ActionType },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.UserAction },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.PublishedDate },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.PublishedBy },
                        { title: fnacdarty.Portal.Repository.UrlRewrite.Wording.PublicationId }
                    ]
                };
            },
            watch: {
                historyitems(val, oldVal) {
                    var vm = this;
                    vm.rows = InitRows(val);
                    vm.dtHandle.clear();
                    vm.dtHandle.rows.add(vm.rows);
                    vm.dtHandle.draw();
                }
            },
            mounted() {
                var vm = this;
                vm.rows = InitRows(vm.historyitems);
                vm.dtHandle = $(this.$el).DataTable({
                    columns: vm.headers,
                    data: vm.rows,
                    responsive: true,
                    columnDefs: [
                        { width: 50, targets: 5 }
                    ],
                    language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                    aLengthMenu: [
                        [10, 25, 50, 100, -1],
                        [10, 25, 50, 100, "Tous"]
                    ],
                    bDestroy: true,
                    drawCallback: function () {
                        template.hideLoader();
                        template.tooltipsPopovers();
                    }
                });
            }
        });

        // module definition
        return historyComponent;
    });
