using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer
{
    public class UrlRewrite
    {
        public UrlRewrite() => UrlRewriteHistory = new HashSet<UrlRewriteHistory>();

        public int? RewriteId { get; set; }

        [Required]
        public short DomainId { get; set; }

        [Required]
        public short RewriteTypeId { get; set; }

        public int? Node { get; set; }

        [StringLength(1800)]
        public string Query { get; set; }

        [Required]
        [StringLength(2048)]
        public string MobileRealUrl { get; set; }

        [Required]
        [StringLength(2048)]
        public string DesktopRealUrl { get; set; }

        [StringLength(128)]
        public string RewrittenUrl { get; set; }

        [Required]
        [StringLength(120)]
        public string Title { get; set; }

        [Required]
        [StringLength(256)]
        public string MetaDescription { get; set; }

        [Required]
        [StringLength(128)]
        public string H1Tag { get; set; }

        [Required]
        [StringLength(2048)]
        public string SeoData { get; set; }

        public DateTime CreationDate { get; set; }

        [Required]
        [StringLength(100)]
        public string CreationUser { get; set; }

        public DateTime? ModificationDate { get; set; }

        [StringLength(100)]
        public string ModificationUser { get; set; }

        public DateTime? DeletionDate { get; set; }

        [StringLength(200)]
        public string DeletionUser { get; set; }

        public virtual ICollection<UrlRewriteHistory> UrlRewriteHistory { get; set; }
    }



    public class UrlRewritePaging : UrlRewrite
    {
        /// <summary>
        /// Number of redirects to display when paging
        /// </summary>
        public int PageSize { get; set; }
        public int PageNo { get; set; }

        public string OrderByColumn { get; set; }
        public string AscOrDesc { get; set; }

        public bool IncludeDeletions { get; set; }
    }
}
