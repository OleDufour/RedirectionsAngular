using System;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer
{
    public class UrlRewriteHistory : ICloneable
    {
        [Required]
        public int RewriteId { get; set; }

        public short RewriteTypeId { get; set; }

        public int? Node { get; set; }

        [StringLength(1800)]
        public string Query { get; set; }

        [Required]
        [StringLength(2048)]
        public string MobileRealUrl { get; set; }

        [Required]
        [StringLength(2048)]
        public string DesktopRealUrl { get; set; }

        [StringLength(128)]
        public string RewrittenUrl { get; set; }

        [Required]
        [StringLength(120)]
        public string Title { get; set; }

        [Required]
        [StringLength(256)]
        public string MetaDescription { get; set; }

        [Required]
        [StringLength(128)]
        public string H1Tag { get; set; }

        [Required]
        [StringLength(2048)]
        public string SeoData { get; set; }

        public DateTime CreationDate { get; set; }

        [StringLength(100)]
        public string CreationUser { get; set; }

        public int? PublicationRequestId { get; set; }

        public DateTime? PublicationRequestDate { get; set; }

        public string PublicationRequestUser { get; set; }

        public short ActionTypeId { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }

    }
}
