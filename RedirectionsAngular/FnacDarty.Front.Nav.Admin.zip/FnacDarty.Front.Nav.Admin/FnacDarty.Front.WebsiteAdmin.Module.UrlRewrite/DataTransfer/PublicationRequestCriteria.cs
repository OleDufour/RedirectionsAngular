namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer
{
    public class PublicationRequestCriteria
    {
        public int DomainId { get; set; }

        public int? EnvId { get; set; }
    }
}
