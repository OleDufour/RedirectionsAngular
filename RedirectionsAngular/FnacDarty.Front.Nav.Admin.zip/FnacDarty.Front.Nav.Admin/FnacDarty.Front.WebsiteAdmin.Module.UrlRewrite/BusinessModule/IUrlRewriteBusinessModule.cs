using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule
{
    public interface IUrlRewriteBusinessModule
    {
        DataTransfer.UrlRewrite GetUrlRewrite(int urlRewriteId);

        DataTransfer.UrlRewrite AddUrlRewrite(DataTransfer.UrlRewrite urlRewrite);

        bool UpdateUrlRewrite(DataTransfer.UrlRewrite urlRewrite);

        IEnumerable<DataTransfer.UrlRewriteHistory> GetUrlRewriteHistories(int urlRewriteId);

        IDictionary<string, string> Validate(DataTransfer.UrlRewrite urlRewrite);

        bool PublishUrlRewriteDomain(EnumDomain domain, string user, string siteCode, string cultureCode, bool isProduction);

        bool DeleteUrlRewrite(DataTransfer.UrlRewrite urlRewrite);

        IEnumerable<DataTransfer.UrlRewritePublicationRequest> GetPublicationRequestHistory(EnumDomain domainId);

        IEnumerable<DataTransfer.UrlRewriteHistory> GetDraftUrlRewrite(EnumDomain domainId);

        DataTransfer.UrlRewritePublicationRequest GetCurrentPublicationRequest(EnumDomain domainId);

       IEnumerable<DataTransfer.UrlRewriteHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId);

        string OrderByColumn(DataTransfer.DataTablesParameters parameters);

        string AscOrDesc(DataTransfer.DataTablesParameters parameters);

        IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesForPaging(DataTransfer.UrlRewritePaging r, out int filteredCount, out int totalCount);
    }
}
