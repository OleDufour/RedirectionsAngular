using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
using HtmlAgilityPack;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule
{
    public class UrlRewriteBusinessModule : BaseBusinessModule, IUrlRewriteBusinessModule
    {
        #region Attributs

        public IUrlRewriteRepository UrlRewriteRepository;
        public IUrlRewriteHistoryRepository UrlRewriteHistoryRepository;
        public IUrlRewritePublicationRequestRepository PublicationRequestRepository;
        public IUrlRewritePublicationRepository UrlRewritePublicationRepository;
        public IDataTablesRepository<DataTransfer.UrlRewrite> UrlRewriteDataTablesRepository;
        public IRestClient RestClient;

        private readonly IList<IValidator<DataTransfer.UrlRewrite>> _validators;

        #endregion Attributs

        #region Constructeurs

        public UrlRewriteBusinessModule(IUrlRewriteRepository urlRewriteRepository,
            IUrlRewriteHistoryRepository urlRewriteHistoryRepository,
            IUrlRewritePublicationRequestRepository publicationRequestRepository,
            IUrlRewritePublicationRepository urlRewritePublicationRepository,
            IDataTablesRepository<DataTransfer.UrlRewrite> urlRewriteDataTablesRepository,
            ILogger logger,
            IConfig config,
            IRestClient restClient)
            : base(logger, config)
        {
            UrlRewriteRepository = urlRewriteRepository;
            UrlRewriteHistoryRepository = urlRewriteHistoryRepository;
            PublicationRequestRepository = publicationRequestRepository;
            UrlRewritePublicationRepository = urlRewritePublicationRepository;
            UrlRewriteDataTablesRepository = urlRewriteDataTablesRepository;
            RestClient = restClient;

            _validators = new List<IValidator<DataTransfer.UrlRewrite>>
            {
                new UrlRewriteValidatorRewrittenUrl(UrlRewriteRepository),
                new UrlRewriteValidatorRealUrl(UrlRewriteRepository),
                new UrlRewriteValidatorTitle(UrlRewriteRepository),
                new UrlRewriteValidatorMetaDescription(UrlRewriteRepository)
            };
        }

        #endregion Constructeurs

        #region Methodes

        public DataTransfer.UrlRewrite GetUrlRewrite(int urlRewriteId)
        {
            return UrlRewriteRepository.GetUrlRewrite(urlRewriteId);
        }

        public IDictionary<string, string> Validate(DataTransfer.UrlRewrite urlRewrite)
        {
            var result = new Dictionary<string, string>();
            foreach (var validator in _validators)
            {
                result.Merge(validator.Validate(urlRewrite));
            }
            return result;
        }

        public DataTransfer.UrlRewrite AddUrlRewrite(DataTransfer.UrlRewrite urlRewrite)
        {
            using (var transaction = new TransactionScope())
            {
                // SeoData : auto-correction du HTML
                urlRewrite.SeoData = HtmlAutoFix(urlRewrite.SeoData);

                var urlRewriteId = UrlRewriteRepository.AddUrlRewrite(urlRewrite);
                if (urlRewriteId > 0)
                {
                    urlRewrite.RewriteId = urlRewriteId;
                    var historyResult = UrlRewriteHistoryRepository.AddUrlRewriteHistory(new DataTransfer.UrlRewriteHistory()
                    {
                        RewriteId = urlRewriteId,
                        RewriteTypeId = urlRewrite.RewriteTypeId,
                        Node = urlRewrite.Node,
                        Query = urlRewrite.Query,
                        H1Tag = urlRewrite.H1Tag,
                        MetaDescription = urlRewrite.MetaDescription,
                        MobileRealUrl = urlRewrite.MobileRealUrl,
                        DesktopRealUrl = urlRewrite.DesktopRealUrl,
                        RewrittenUrl = urlRewrite.RewrittenUrl,
                        SeoData = urlRewrite.SeoData,
                        Title = urlRewrite.Title,
                        CreationDate = urlRewrite.CreationDate,
                        CreationUser = urlRewrite.CreationUser,
                        ActionTypeId = (short) EnumActionType.Add
                    });

                    if (historyResult > 0)
                    {
                        transaction.Complete();
                        return urlRewrite;
                    }
                }
            }

            return urlRewrite;
        }

        public bool UpdateUrlRewrite(DataTransfer.UrlRewrite urlRewrite)
        {
            var urlRewriteVerify = UrlRewriteRepository.GetUrlRewrite(urlRewrite.RewriteId.Value);
            if (urlRewriteVerify == null)
                throw new NotImplementedException();
            if (urlRewriteVerify.DeletionDate.HasValue)
                return false;

            using (var transaction = new TransactionScope())
            {
                // SeoData : auto-correction du HTML
                urlRewrite.SeoData = HtmlAutoFix(urlRewrite.SeoData);

                var result = UrlRewriteRepository.UpdateUrlRewrite(urlRewrite);
                if (result && urlRewrite.RewriteId.HasValue && urlRewrite.ModificationDate.HasValue)
                {
                    var historyResult = UrlRewriteHistoryRepository.AddUrlRewriteHistory(new DataTransfer.UrlRewriteHistory()
                    {
                        RewriteId = urlRewrite.RewriteId.Value,
                        RewriteTypeId = urlRewrite.RewriteTypeId,
                        Node = urlRewrite.Node,
                        Query = urlRewrite.Query,
                        H1Tag = urlRewrite.H1Tag,
                        MetaDescription = urlRewrite.MetaDescription,
                        MobileRealUrl = urlRewrite.MobileRealUrl,
                        DesktopRealUrl = urlRewrite.DesktopRealUrl,
                        RewrittenUrl = urlRewrite.RewrittenUrl,
                        SeoData = urlRewrite.SeoData,
                        Title = urlRewrite.Title,
                        CreationDate = urlRewrite.ModificationDate.Value,
                        CreationUser = urlRewrite.ModificationUser,
                        ActionTypeId = (short)EnumActionType.Update
                    });
                    if (historyResult > 0)
                    {
                        transaction.Complete();
                        return true;
                    }
                }
            }
            return false;
        }

        private string HtmlAutoFix(string html)
        {
            if (string.IsNullOrEmpty(html))
            {
                return string.Empty;
            }

            var doc = new HtmlDocument();
            doc.LoadHtml(html);

            return doc.DocumentNode.OuterHtml;
        }

        public IEnumerable<DataTransfer.UrlRewriteHistory> GetUrlRewriteHistories(int urlRewriteId)
        {
            var rewriteHistory = UrlRewriteHistoryRepository.GetUrlRewriteHistories(urlRewriteId);
            rewriteHistory = KeepPublicationOnlyForLastItem(rewriteHistory);
            return rewriteHistory;
        }

        private IEnumerable<DataTransfer.UrlRewriteHistory> KeepPublicationOnlyForLastItem(IEnumerable<DataTransfer.UrlRewriteHistory> rewriteHistory)
        {
            // On group par publication Id.
            var groups = rewriteHistory.Where(i => i.PublicationRequestId.HasValue).GroupBy(i => i.PublicationRequestId);
            foreach (var group in groups)
            {
                // On trie par date et on laisse le premier avec les infos de publication.
                var toUpdate = group.OrderByDescending(i => i.CreationDate).Skip(1);
                foreach (var item in toUpdate)
                {
                    item.PublicationRequestDate = null;
                    item.PublicationRequestId = null;
                    item.PublicationRequestUser = null;
                }
            }
            return rewriteHistory;
        }

        public bool PublishUrlRewriteDomain(EnumDomain domain, string user, string siteCode, string cultureCode, bool isProduction)
        {
            using (var transactionScope = new TransactionScope())
            {
                var domainId = (int)domain;
                var now = DateTime.Now;
                var newPublicationRequestId = PublicationRequestRepository.AddPublicationRequest(domainId, now, user, isProduction);
                var historyAdded = true;

                if (isProduction)
                {
                    historyAdded = UrlRewriteHistoryRepository.AddPublicationInfosToHistory(domainId, newPublicationRequestId);
                }

                if (historyAdded && UrlRewritePublicationRepository.PublishUrlRewrite(newPublicationRequestId, domainId, isProduction))
                {
                    var isCacheInvalidatedAndReloaded = NotifyInvalidateAndReloadApiCache(siteCode, cultureCode, isProduction);

                    if (isCacheInvalidatedAndReloaded)
                    {
                        transactionScope.Complete();
                        return true;
                    }
                }
            }

            return false;
        }

        public bool DeleteUrlRewrite(DataTransfer.UrlRewrite urlRewrite)
        {
            if (urlRewrite == null)
            {
                throw new ArgumentNullException(nameof(urlRewrite));
            }

            using (var transactionScope = new TransactionScope())
            {
                var isDeleted = UrlRewriteRepository.DeleteUrlRewrite(urlRewrite);
                if (isDeleted && urlRewrite.RewriteId.HasValue)
                {
                    var historyResult = UrlRewriteHistoryRepository.AddUrlRewriteHistory(new DataTransfer.UrlRewriteHistory()
                    {
                        RewriteId = urlRewrite.RewriteId.Value,
                        RewriteTypeId = urlRewrite.RewriteTypeId,
                        Node = urlRewrite.Node,
                        Query = urlRewrite.Query,
                        H1Tag = urlRewrite.H1Tag,
                        MetaDescription = urlRewrite.MetaDescription,
                        MobileRealUrl = urlRewrite.MobileRealUrl,
                        DesktopRealUrl = urlRewrite.DesktopRealUrl,
                        RewrittenUrl = urlRewrite.RewrittenUrl,
                        SeoData = urlRewrite.SeoData,
                        Title = urlRewrite.Title,
                        CreationDate = urlRewrite.DeletionDate ?? DateTime.Now,
                        CreationUser = urlRewrite.DeletionUser,
                        ActionTypeId = (short)EnumActionType.Delete
                    });

                    if (historyResult > 0)
                    {
                        transactionScope.Complete();
                        return true;
                    }
                }
            }
            return false;
        }

        public IEnumerable<DataTransfer.UrlRewritePublicationRequest> GetPublicationRequestHistory(EnumDomain domainId)
        {
            return PublicationRequestRepository.GetPublicationRequest(new DataTransfer.PublicationRequestCriteria { DomainId = (int)domainId });
        }

        public IEnumerable<DataTransfer.UrlRewriteHistory> GetDraftUrlRewrite(EnumDomain domainId)
        {
            var res = UrlRewriteRepository.GetDraftUrlRewrite((int)domainId);
            return FilterPublicationDetails(res);
        }

      
        public DataTransfer.UrlRewritePublicationRequest GetCurrentPublicationRequest(EnumDomain domainId)
        {
            return PublicationRequestRepository.GetCurrentRewritePublicationForDomain((int)domainId);
        }

        private bool NotifyInvalidateAndReloadApiCache(string siteCode, string cultureCode, bool isProduction)
        {
            // Invalidation du cache sur les n APIs mises en place (on passe par une VIP => Load Balancer)
            var apiConfig = isProduction
                ? Config.GetSettingValue($"Api:Release:{siteCode}:{cultureCode}:Rewrite")
                : Config.GetSettingValue($"Api:Unstable:{siteCode}:{cultureCode}:Rewrite");
            var config = RestClientConfigurationManager.Get(apiConfig);

            RestClient.BaseAddress = config.BaseAddress;
            RestClient.Timeout = config.Timeout;
            RestClient.NumberOfAttempts = config.NumberOfAttempts;
            RestClient.TimeToSleepBetweenAttempts = config.TimeToSleepBetweenAttempts;

            var isCacheInvalidatedAndReloaded = RestClient.Delete($"NotifyInvalidateAndReloadCache/{siteCode}/{cultureCode}");

            return isCacheInvalidatedAndReloaded;
        }

        public IEnumerable<DataTransfer.UrlRewriteHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId)
        {            
            var res = PublicationRequestRepository.GetPublicationRequestDetails(publicationRequestId, domainId);
            return FilterPublicationDetails(res);
        }

        private IEnumerable<DataTransfer.UrlRewriteHistory> FilterPublicationDetails(IEnumerable<DataTransfer.UrlRewriteHistory> details)
        {
            var res = new List<DataTransfer.UrlRewriteHistory>();
            var groups = details.GroupBy(i => i.RewriteId);
            foreach (var group in groups)
            {
                if (WasDeleted(group))
                {
                    if (!WasAdded(group))
                    {
                        // On prend que les éléments qui ont été supprimé et pas ajouté pour la meme publication.
                        res.Add(group.First(i => (EnumActionType)i.ActionTypeId == EnumActionType.Delete));
                    }
                }
                else
                {
                    if (WasAdded(group))
                    {
                        if (WasModified(group))
                        {
                            var item = GetLastModified(group).Clone() as DataTransfer.UrlRewriteHistory;
                            item.ActionTypeId = (short)EnumActionType.Add;
                            // l'élément a été ajouté puis modifié, on prend la dernière modification mais on met l'action a ajouté.
                            res.Add(item);
                        }
                        else
                        {
                            // On n'a qu'un ajout du coup. On prend l'élément qui a été ajouté.
                            res.Add(group.First());
                        }
                    }
                    else
                    {
                        // On n'a que des modifications, on prend que la dernière.
                        res.Add(GetLastModified(group));
                    }
                }
            }
            return res;
        }

        private DataTransfer.UrlRewriteHistory GetLastModified(IGrouping<int, DataTransfer.UrlRewriteHistory> group)
        {
            return group.OrderByDescending(i => i.CreationDate).First();
        }

        private bool WasAdded(IGrouping<int, DataTransfer.UrlRewriteHistory> group)
        {
            return group.Any(i => (EnumActionType)i.ActionTypeId == EnumActionType.Add);
        }

        private bool WasModified(IGrouping<int, DataTransfer.UrlRewriteHistory> group)
        {
            return group.Any(i => (EnumActionType)i.ActionTypeId == EnumActionType.Update);
        }

        private bool WasDeleted(IGrouping<int, DataTransfer.UrlRewriteHistory> group)
        {
            return group.Any(i => (EnumActionType)i.ActionTypeId == EnumActionType.Delete);
        }

        public string OrderByColumn(DataTransfer.DataTablesParameters parameters)
        {
            var orderByColumn = UrlRewriteDataTablesRepository.ColumnNameMapping[parameters.Columns[parameters.Order[0].Column].Data];
            return orderByColumn;
        }

        public string AscOrDesc(DataTransfer.DataTablesParameters parameters)
        {
            var ascOrDesc = parameters.Order[0].Dir;
            return ascOrDesc;
        }

        public IEnumerable<DataTransfer.UrlRewrite> GetUrlRewritesForPaging(DataTransfer.UrlRewritePaging r, out int filteredCount, out int totalCount)
        {
            var urlRewrites = UrlRewriteRepository.GetUrlRewritesForPaging(r, out filteredCount, out totalCount);
            return urlRewrites;
        }



        #endregion Methodes
    }
}
