using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation
{
    public interface IValidator<T> where T : class
    {
        Dictionary<string, string> Validate(T model);
    }
}
