using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
 
namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation
{
    public class UrlRewriteValidatorRealUrl : UrlRewriteValidatorUrlBase
    {
        public UrlRewriteValidatorRealUrl(
            IUrlRewriteRepository urlRewriteRepository
            ) : base(urlRewriteRepository) { }

        public override Func<DataTransfer.UrlRewrite, string> Expression => (model) => model.MobileRealUrl;

        public override Dictionary<string, string> Validate(DataTransfer.UrlRewrite model)
        {
            var errors = base.ValidateWithPattern(model, "'Query'");

            if (UrlRewriteRepository.GetUrlRewritesByNodeAndQuery(model.DomainId, model.Node, model.Query)
                                        .Any(u => u.RewriteId.HasValue && u.RewriteId.Value != model.RewriteId))
            {
                if (model.Node.HasValue)
                {                 
                    errors.Add("Node", UrlRewriteResources.app_urlrewrite_existant_node);
                }
                else if (!string.IsNullOrWhiteSpace(model.Query))
                {
                    errors.Add("Query", UrlRewriteResources.app_urlrewrite_existant_query);
                }
                else
                {
                    errors.Add("Query", UrlRewriteResources.app_urlrewrite_existante_node_or_query);
                }

            }

            return errors;
        }
    }
}
