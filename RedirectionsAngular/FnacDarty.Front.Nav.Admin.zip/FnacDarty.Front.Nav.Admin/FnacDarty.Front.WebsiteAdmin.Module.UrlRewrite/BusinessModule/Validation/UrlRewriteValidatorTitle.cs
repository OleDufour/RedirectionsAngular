using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
 

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation
{
    public class UrlRewriteValidatorTitle : IValidator<DataTransfer.UrlRewrite>
    {
        public IUrlRewriteRepository UrlRewriteRepository;

        public UrlRewriteValidatorTitle (
            IUrlRewriteRepository urlRewriteRepository
            )
        {
            UrlRewriteRepository = urlRewriteRepository;
        }

        public Dictionary<string, string> Validate(DataTransfer.UrlRewrite model)
        {
            if (!string.IsNullOrWhiteSpace(model.Title)
                && UrlRewriteRepository.GetUrlRewritesByTitle(model.DomainId, model.Title)
                                        .Any(u => u.RewriteId.HasValue && u.RewriteId.Value != model.RewriteId))
            {
                return new Dictionary<string, string> { { "Title", UrlRewriteResources.app_urlrewrite_existant_title } };
            }
            return null;
        }
    }
}
