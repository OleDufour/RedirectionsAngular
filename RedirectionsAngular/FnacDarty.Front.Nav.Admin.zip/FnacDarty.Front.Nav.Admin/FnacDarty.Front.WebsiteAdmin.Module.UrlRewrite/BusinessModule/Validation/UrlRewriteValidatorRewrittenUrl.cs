using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
 

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation
{
    public class UrlRewriteValidatorRewrittenUrl : UrlRewriteValidatorUrlBase
    {
        public UrlRewriteValidatorRewrittenUrl(
            IUrlRewriteRepository urlRewriteRepository
        ) : base(urlRewriteRepository) { }

        public override Func<DataTransfer.UrlRewrite, string> Expression => (model) => model.RewrittenUrl;

        public override Dictionary<string, string> Validate(DataTransfer.UrlRewrite model)
        {
            var errors = ValidateWithPattern(model, "L'url décorée");

            if (!string.IsNullOrWhiteSpace(model.RewrittenUrl)
                       && UrlRewriteRepository.GetUrlRewritesByRewrittenUrl(model.DomainId, model.RewrittenUrl)
                                               .Any(u => u.RewriteId.HasValue && u.RewriteId.Value != model.RewriteId))
            {
                errors.Add("RewritetenUrl", UrlRewriteResources.app_urlrewrite_decoratedurl);
            }

            return errors;
        }
    }
}
