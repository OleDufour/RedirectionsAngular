using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
 

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation
{
    public abstract class UrlRewriteValidatorUrlBase : IValidator<DataTransfer.UrlRewrite>
    {
        public IUrlRewriteRepository UrlRewriteRepository;

        public UrlRewriteValidatorUrlBase(IUrlRewriteRepository urlRewriteRepository)
        {
            UrlRewriteRepository = urlRewriteRepository;
        }

        public IList<string> Patterns => new List<string> { @"http://", @"https://", @".fnac." };

        public abstract Func<DataTransfer.UrlRewrite, string> Expression { get; }

        public Dictionary<string, string> ValidateWithPattern(DataTransfer.UrlRewrite model, string nameField)
        {
            var errors = new Dictionary<string, string>();
            if (Expression(model) != null)
            {
                foreach (var pattern in Patterns)
                {
                    if (Expression(model).Contains(pattern, StringComparison.OrdinalIgnoreCase))
                    {
                        string errorContain = string.Format(UrlRewriteResources.app_should_not_contain, nameField, pattern);
                        errors.Add(pattern + Expression(model), errorContain);
                    }
                }

                if (!Expression(model).StartsWith('/'))
                    errors.Add($"/{Expression(model)}", "Le chemin doit commencer par un '/'");
            }

            return errors;
        }

        public abstract Dictionary<string, string> Validate(DataTransfer.UrlRewrite model);
    }
}
