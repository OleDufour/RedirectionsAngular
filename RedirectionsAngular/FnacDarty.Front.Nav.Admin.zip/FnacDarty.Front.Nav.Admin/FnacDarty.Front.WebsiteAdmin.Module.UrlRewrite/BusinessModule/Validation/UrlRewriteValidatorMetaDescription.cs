using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
 


namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule.Validation
{
    public class UrlRewriteValidatorMetaDescription : IValidator<DataTransfer.UrlRewrite>
    {
        public IUrlRewriteRepository UrlRewriteRepository;

        public UrlRewriteValidatorMetaDescription(
            IUrlRewriteRepository urlRewriteRepository
            )
        {
            UrlRewriteRepository = urlRewriteRepository;
        }

        public Dictionary<string, string> Validate(DataTransfer.UrlRewrite model)
        {
            if (!string.IsNullOrWhiteSpace(model.MetaDescription)
                && UrlRewriteRepository.GetUrlRewritesByMetaDescription(model.DomainId, model.MetaDescription)
                                        .Any(u => u.RewriteId.HasValue && u.RewriteId.Value != model.RewriteId))
            {
                string err = string.Format(UrlRewriteResources.app_urlrewrite_existant_metadescription, model.MetaDescription);
                return new Dictionary<string, string> { { "MetaDesciption", err } };
            }
            return null;
        }
    }
}
