using System;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule
{
    public abstract class BaseBusinessModule
    {
        public ILogger Logger;
        public IConfig Config;
        ILocalCache LocalCache;

        public BaseBusinessModule(ILogger logger, IConfig config, ILocalCache localCache)
        {
            Logger = logger;
            Config = config;
            LocalCache = localCache;
        }

        public BaseBusinessModule(ILogger logger, IConfig config )
        {
            Logger = logger;
            Config = config;
           
        }

        public T GetCache<T>(string cacheKeyTemplate, string siteCode, string cultureCode, Func<string, string, T> method)
        {
            var cacheKey = GetCacheKey(cacheKeyTemplate, siteCode, cultureCode);
            var cachedObject = LocalCache.Get<T>(cacheKey);

            if (cachedObject == null)
            {
                cachedObject = method(siteCode, cultureCode);
                LocalCache.Set(cacheKey, cachedObject);
            }

            return cachedObject;
        }

        public void InvalidateCache(string cacheKeyTemplate, string siteCode, string cultureCode)
        {
            var cacheKey = GetCacheKey(cacheKeyTemplate, siteCode, cultureCode);
            if (LocalCache.Contains(cacheKey))
            {
                LocalCache.Remove(cacheKey);
            }
        }

        private static string GetCacheKey(string cacheKeyTemplate, string siteCode, string cultureCode)
        {
            return string.Format(cacheKeyTemplate, siteCode.ToLowerInvariant(), cultureCode.ToLowerInvariant());
        }
    }
}
