using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Repository
{
    public interface IPublishedRewriteRepository
    {
        IEnumerable<PublishedRewriteDto> GetPublishedRewrites(string siteCode, string cultureCode);
        IEnumerable<PublishedSeoDecorationDto> GetPublishedSeoDecorations(string siteCode, string cultureCode);
        IEnumerable<string> GetPublishedRewrittenUrls(string siteCode, string cultureCode);
    }
}
