using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Repository
{
    public interface IUserRepository
    {
        User GetUserByLogin(string identityName);

        User GetUserById(Guid userId);

        bool AddUser(User user);

        bool DeleteUser(Guid userId);

        bool UpdateUser(User user);

        bool AddUserRole(Guid userId, int userRoleId);

        bool DeleteUserRole(Guid userId, int userRoleId);

        IEnumerable<User> GetUsers();
    }
}
