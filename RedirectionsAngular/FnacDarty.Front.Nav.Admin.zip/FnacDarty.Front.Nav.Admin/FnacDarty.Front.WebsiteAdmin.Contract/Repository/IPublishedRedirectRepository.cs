﻿using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Repository
{
    public interface IPublishedRedirectRepository
    {
        IEnumerable<PublishedUrlRedirectDto> GetPublishedUrlRedirectDtos(string siteCode, string cultureCode);
    }
}
