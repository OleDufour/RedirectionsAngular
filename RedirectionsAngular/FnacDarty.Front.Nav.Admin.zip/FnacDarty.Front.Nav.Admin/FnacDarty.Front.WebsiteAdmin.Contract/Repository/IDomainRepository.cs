using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Repository
{
    public interface IDomainRepository
    {
        Domain GetDomainById(int domainId);
        IEnumerable<Domain> GetDomains();
    }
}
