using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Module
{
    public interface IPublishedRewriteBusinessModule
    {
        IEnumerable<PublishedRewriteDto> GetPublishedRewrites(string siteCode, string cultureCode);
        IEnumerable<PublishedSeoDecorationDto> GetPublishedSeoDecorations(string siteCode, string cultureCode);
        IEnumerable<string> GetPublishedRewrittenUrls(string siteCode, string cultureCode);
        bool NotifyInvalidateAndReloadCache(string siteCode, string cultureCode);
        bool InvalidateAndReloadCache(string siteCode, string cultureCode);
    }
}
