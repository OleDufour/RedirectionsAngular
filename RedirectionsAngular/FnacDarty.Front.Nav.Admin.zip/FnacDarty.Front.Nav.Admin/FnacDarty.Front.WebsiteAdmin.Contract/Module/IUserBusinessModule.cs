using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Module
{
    public interface IUserBusinessModule
    {
        User GetUserByLogin(string identityName);

        User GetUserById(Guid userId);
        
        bool AddUser(User user);

        bool UpdateUser(User user);

        bool DeleteUser(Guid userId);

        IEnumerable<User> GetUsers();
    }
}
