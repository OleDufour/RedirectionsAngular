﻿using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Module
{
    public interface IPublishedRedirectBusinessModule
    {
        IEnumerable<PublishedUrlRedirectDto> GetPublishedUrlRedirectDtos(string siteCode, string cultureCode);
        bool NotifyInvalidateAndReloadCache(string siteCode, string cultureCode);
        bool InvalidateAndReloadCache(string siteCode, string cultureCode);
    }
}
