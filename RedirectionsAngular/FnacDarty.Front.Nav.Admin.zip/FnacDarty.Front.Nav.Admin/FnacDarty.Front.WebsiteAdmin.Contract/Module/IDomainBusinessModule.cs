using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Contract.Module
{
    public interface IDomainBusinessModule
    {
        IEnumerable<Domain> GetDomains();

        Domain GetDomain(EnumDomain domain);
    }
}
