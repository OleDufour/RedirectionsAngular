using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.Repository;
using FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes;
using NSubstitute;
using Xunit;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.UrlRewrite
{
    public class UrlRewriteModuleTests
    {

        

        public UrlRewriteModuleTests()
        {
        }

     
        [Theory]
        [MemberData(nameof(UrlRewriteFakes.GetAddedAndDeleted), MemberType = typeof (UrlRewriteFakes))]
        public void ShouldNotGetAddedAndDeletedDraft(List<UrlRewriteHistory> details)
        {
            var _urlRewiteRepo = Substitute.For<IUrlRewriteRepository>();
            var _urlRewiteHistoryRepo = Substitute.For<IUrlRewriteHistoryRepository>();
            var rewriteModule = new UrlRewriteBusinessModule(_urlRewiteRepo, _urlRewiteHistoryRepo, null,null, null, null, null, null);
            _urlRewiteRepo.GetDraftUrlRewrite(Arg.Any<int>()).Returns(details);
            var res = rewriteModule.GetDraftUrlRewrite(EnumDomain.FR_FR);
            Assert.Empty(res);
        }

        [Theory]
        [MemberData(nameof(UrlRewriteFakes.GetAddedAndModified), MemberType = typeof(UrlRewriteFakes))]
        public void ShouldGetLastModifiedWithActionAdded(IEnumerable<UrlRewriteHistory> details)
        {
            var _urlRewiteRepo = Substitute.For<IUrlRewriteRepository>();
            var _urlRewiteHistoryRepo = Substitute.For<IUrlRewriteHistoryRepository>();
            var rewriteModule = new UrlRewriteBusinessModule(_urlRewiteRepo, _urlRewiteHistoryRepo, null, null, null, null, null, null);
            _urlRewiteRepo.GetDraftUrlRewrite(Arg.Any<int>()).Returns(details);
            var res = rewriteModule.GetDraftUrlRewrite(EnumDomain.FR_FR);
            Assert.Single(res);

            var latest = details.OrderByDescending(x => x.CreationDate).First().CreationDate;
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Add && i.CreationDate == latest);
        }

        [Theory]
        [MemberData(nameof(UrlRewriteFakes.GetAddedOnly), MemberType = typeof(UrlRewriteFakes))]
        public void ShouldGetOnlyOneAdded(List<UrlRewriteHistory> details)
        {
            var _urlRewiteRepo = Substitute.For<IUrlRewriteRepository>();
            var _urlRewiteHistoryRepo = Substitute.For<IUrlRewriteHistoryRepository>();
            var rewriteModule = new UrlRewriteBusinessModule(_urlRewiteRepo, _urlRewiteHistoryRepo, null, null, null, null, null, null);
            _urlRewiteRepo.GetDraftUrlRewrite(Arg.Any<int>()).Returns(details);
            var res = rewriteModule.GetDraftUrlRewrite(EnumDomain.FR_FR);
            Assert.Single(res);
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Add);
        }

        [Theory]
        [MemberData(nameof(UrlRewriteFakes.GetModifiedOnly), MemberType = typeof(UrlRewriteFakes))]
        public void ShouldGetOnlyOneModified(List<UrlRewriteHistory> details)
        {
            var _urlRewiteRepo = Substitute.For<IUrlRewriteRepository>();
            var _urlRewiteHistoryRepo = Substitute.For<IUrlRewriteHistoryRepository>();
            var rewriteModule = new UrlRewriteBusinessModule(_urlRewiteRepo, _urlRewiteHistoryRepo, null, null, null, null, null, null);
            _urlRewiteRepo.GetDraftUrlRewrite(Arg.Any<int>()).Returns(details);
            var res = rewriteModule.GetDraftUrlRewrite(EnumDomain.FR_FR);
            Assert.Single(res);
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Update && i.CreationUser == RedirectFakes.ModifiedHistory1_2.CreationUser);
        }

        [Theory]
        [MemberData(nameof(UrlRewriteFakes.GetDeleteAndNotAdded), MemberType = typeof(UrlRewriteFakes))]
        public void ShouldGetOnlyOneDeleted(List<UrlRewriteHistory> details)
        {
            var _urlRewiteRepo = Substitute.For<IUrlRewriteRepository>();
            var _urlRewiteHistoryRepo = Substitute.For<IUrlRewriteHistoryRepository>();
            var rewriteModule = new UrlRewriteBusinessModule(_urlRewiteRepo, _urlRewiteHistoryRepo, null, null, null, null, null, null);
            _urlRewiteRepo.GetDraftUrlRewrite(Arg.Any<int>()).Returns(details);
            var res = rewriteModule.GetDraftUrlRewrite(EnumDomain.FR_FR);
            Assert.Single(res);
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Delete);
        }
    }
}
