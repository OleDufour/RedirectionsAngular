using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using userDataTransfer = FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Support.AccessControl;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes
{
    public class UserFakeRepo : IUserRepository
    {
        public List<userDataTransfer.User> _users = new List<userDataTransfer.User>();

        public bool AddUser(userDataTransfer.User user)
        {
            if (_users.Any(u => u.Login.ToLowerInvariant() == user.Login.ToLowerInvariant()))
                return false;
            _users.Add(new userDataTransfer.User()
            {
                IsAdmin = user.IsAdmin,
                Login = user.Login,
                Roles = new List<Role>(),
                UserId = user.UserId
            });
            return true;
        }

        public bool AddUserRole(Guid userId, int userRoleId)
        {
            var user = _users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
                return false;

            if (user.Roles.Any(x => x.RoleId == userRoleId))
                return false;
            user.Roles.Add(new Role { RoleId = userRoleId });
            return true;
        }

        public bool DeleteUser(Guid userId)
        {
            var user = _users.FirstOrDefault(u => u.UserId == userId);
            if (user == null)
                return false;
            _users.Remove(new userDataTransfer.User { UserId = userId });
            return false;
        }

        public bool DeleteUserRole(Guid userId, int userRoleId)
        {
            var user = _users.FirstOrDefault(u => u.UserId == userId);
            if (!user.Roles.Any(x => x.RoleId == userRoleId))
                return false;

            var usRoleList = user.Roles.ToList();
            for (int i = usRoleList.Count - 1; i >= 0; i--)
            {
                if (usRoleList[i].RoleId == userRoleId)
                    usRoleList.RemoveAt(i);                
            }      

            return true;
        }

        public userDataTransfer.User GetUserById(Guid userId)
        {
            return _users.FirstOrDefault(u => u.UserId == userId);
        }

        public userDataTransfer.User GetUserByLogin(string identityName)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<userDataTransfer.User> GetUsers()
        {
            throw new NotImplementedException();
        }

        public bool UpdateUser(userDataTransfer.User user)
        {
            var userToUpdate = _users.Where(c => c.UserId == user.UserId).FirstOrDefault();
            if (userToUpdate == null)
                return false;
            userToUpdate = user;
            return true;
        }
    }
    public static class UserFakes
    {
        public static FnacDirectFrHqPrincipal AdminUser = new FnacDirectFrHqPrincipal
        {
            HaveAccess = true,
            IsAdmin = true,
            Login = "FRHQ\\test",
            UserId = new Guid("45db0bd8-cd1a-4035-95bf-6d513ec79864")
        };

        static Role r = new Role { RoleId = 1, RoleName = "abc" };
        static Role r2 = new Role { RoleId = 2, RoleName = "def" };

        public static userDataTransfer.User UserRep = new userDataTransfer.User
        {
            IsAdmin = true,
            Login = "FRHQ\\test",
            Roles = new List<Role>() { r },
            UserId = new Guid("45db0bd8-cd1a-4035-95bf-6d513ec79800")

        };

        public static userDataTransfer.User UserRepDuplicatedRoles = new userDataTransfer.User
        {
            IsAdmin = true,
            Login = "FRHQ\\test",
            Roles = new List<Role>() { r, r },
            UserId = new Guid("45db0bd8-cd1a-4035-95bf-6d513ec79800")

        };

        public static userDataTransfer.User UserUpdated = new userDataTransfer.User
        {
            IsAdmin = false,
            Login = "FRHQ\\test2",
            Roles = new List<Role>() { r2 },
            UserId = new Guid("45db0bd8-cd1a-4035-95bf-6d513ec79800")

        };



        public static IEnumerable<object[]> GetAdded()
        {
            yield return new object[]
            {
                new List< userDataTransfer.User>() { UserRep }
            };
        }
    }
}
