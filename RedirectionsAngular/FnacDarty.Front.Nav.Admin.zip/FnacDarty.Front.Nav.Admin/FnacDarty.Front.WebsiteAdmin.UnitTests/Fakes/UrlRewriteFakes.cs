using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Module.UrlRewrite.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes
{
    public static class UrlRewriteFakes
    {

        public static readonly UrlRewriteHistory AddedHistory1 = new UrlRewriteHistory
        {
            RewriteId = 1,
            RewriteTypeId = (short)EnumRewriteType.Search,
            Query = "Query",
            H1Tag = "H1Tag",
            MetaDescription = "MetaDescription",
            MobileRealUrl = "MobileRealUrl",
            DesktopRealUrl = "DesktopRealUrl",
            RewrittenUrl = "RewrittenUrl",
            SeoData = "SeoData",
            Title = "Title",
            CreationDate = DateTime.Now.AddMinutes(-10),
            CreationUser = "AddUser",
            ActionTypeId = (short)EnumActionType.Add
        };

        public static readonly UrlRewriteHistory DeletedHistory1 = new UrlRewriteHistory
        {
            RewriteId = 1,
            RewriteTypeId = (short)EnumRewriteType.Search,
            Query = "Query",
            H1Tag = "H1Tag",
            MetaDescription = "MetaDescription",
            MobileRealUrl = "MobileRealUrl",
            DesktopRealUrl = "DesktopRealUrl",
            RewrittenUrl = "RewrittenUrl",
            SeoData = "SeoData",
            Title = "Title",
            CreationDate = DateTime.Now,
            CreationUser = "DeleteUser",
            ActionTypeId = (short)EnumActionType.Delete
        };

        public static readonly UrlRewriteHistory ModifiedHistory1 = new UrlRewriteHistory
        {
            RewriteId = 1,
            RewriteTypeId = (short)EnumRewriteType.Search,
            Query = "Query",
            H1Tag = "H1Tag",
            MetaDescription = "MetaDescription",
            MobileRealUrl = "MobileRealUrl",
            DesktopRealUrl = "DesktopRealUrl",
            RewrittenUrl = "RewrittenUrl",
            SeoData = "SeoData",
            Title = "Title",
            CreationDate = DateTime.Now.AddMinutes(-5),
            CreationUser = "ModifyUser",
            ActionTypeId = (short)EnumActionType.Update
        };

        public static readonly UrlRewriteHistory ModifiedHistory1_2 = new UrlRewriteHistory
        {
            RewriteId = 1,
            RewriteTypeId = (short)EnumRewriteType.Search,
            Query = "Query",
            H1Tag = "H1Tag",
            MetaDescription = "MetaDescription",
            MobileRealUrl = "MobileRealUrl",
            DesktopRealUrl = "DesktopRealUrl",
            RewrittenUrl = "RewrittenUrl",
            SeoData = "SeoData",
            Title = "Title",
            CreationDate = DateTime.Now.AddMinutes(-3),
            CreationUser = "ModifyUser2",
            ActionTypeId = (short)EnumActionType.Update
        };
    

        public static IEnumerable<object[]> GetAddedAndDeleted()
        {
            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1, ModifiedHistory1, ModifiedHistory1_2, DeletedHistory1 }
            };

            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1,  DeletedHistory1 }
            };

            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1, ModifiedHistory1_2, DeletedHistory1 }
            };
        }

        public static IEnumerable<object[]> GetAddedAndModified()
        {
            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1, ModifiedHistory1, ModifiedHistory1_2 }
            };

            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1, ModifiedHistory1_2 }
            };
        }

        public static IEnumerable<object[]> GetAddedOnly()
        {
            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1}
            };

            yield return new object[]
            {
                new List<UrlRewriteHistory>() { AddedHistory1, AddedHistory1}
            };

        }

        public static IEnumerable<object[]> GetModifiedOnly()
        {
            yield return new object[]
            {
                new List<UrlRewriteHistory>() { ModifiedHistory1_2 }
            };

            yield return new object[]
            {
                new List<UrlRewriteHistory>() { ModifiedHistory1_2, ModifiedHistory1 }
            };
        }

        public static IEnumerable<object[]> GetDeleteAndNotAdded()
        {
            yield return new object[]
            {
                new List<UrlRewriteHistory>() { ModifiedHistory1, DeletedHistory1 }
            };

            yield return new object[]
            {
                new List<UrlRewriteHistory>() { DeletedHistory1 }
            };
        }

    }
}
