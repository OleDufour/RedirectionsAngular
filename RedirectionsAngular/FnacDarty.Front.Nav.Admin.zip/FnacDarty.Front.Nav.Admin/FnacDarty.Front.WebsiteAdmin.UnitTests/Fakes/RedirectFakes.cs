using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes
{
    public static class RedirectFakes
    {
        public static Module.Redirect.DataTransfer.Redirect DefaultRedirect = new Module.Redirect.DataTransfer.Redirect
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = 1,
            RedirectType = 301,
            Source = "123",
            SourceType = 1,
            Target = "456",
            TargetType = 1
        };

        public static Module.Redirect.DataTransfer.Redirect CascadeRedirect = new Module.Redirect.DataTransfer.Redirect
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = 1,
            RedirectType = 301,
            Source = "456",
            SourceType = 1,
            Target = "4561111",
            TargetType = 1
        };

        public static Module.Redirect.DataTransfer.Redirect DeletedRedirect = new Module.Redirect.DataTransfer.Redirect
        {
            RedirectId = 1,
            DeletionDate = DateTime.Now,
            CreationUser = "test",
            DomainId = 1,
            RedirectType = 301,
            Source = "123",
            SourceType = 1,
            Target = "456",
            TargetType = 1
        };

        public static Module.Redirect.DataTransfer.Redirect NullRedirect = null;

        public static RedirectModel DefaultRedirectModel = new RedirectModel
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = EnumDomain.FR_FR,
            RedirectType = EnumRedirectType.Found,
            Source = "123",
            SourceType = EnumSourceTypeTargetType.Node,
            Target = "456",
            TargetType = EnumSourceTypeTargetType.Node
        };

        public static readonly RedirectModel InvalidSourceTypeRedirectModel = new RedirectModel
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = EnumDomain.FR_FR,
            RedirectType = EnumRedirectType.Found,
            Source = "123",
            SourceType = (EnumSourceTypeTargetType)99999,
            Target = "456",
            TargetType = EnumSourceTypeTargetType.Node
        };
        public static readonly RedirectModel InvalidSourceModel = new RedirectModel
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = EnumDomain.FR_FR,
            RedirectType = EnumRedirectType.Found,
            Source = "aaaaaaa",
            SourceType = EnumSourceTypeTargetType.Node,
            Target = "456",
            TargetType = EnumSourceTypeTargetType.Node
        };

        public static readonly RedirectModel InvalidTargetModel = new RedirectModel
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = EnumDomain.FR_FR,
            RedirectType = EnumRedirectType.Found,
            Source = "456",
            SourceType = EnumSourceTypeTargetType.Node,
            Target = "pppppp",
            TargetType = EnumSourceTypeTargetType.Node
        };

        public static readonly RedirectModel NullSourceModel = new RedirectModel
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = EnumDomain.FR_FR,
            RedirectType = EnumRedirectType.Found,
            Source = null,
            SourceType = EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = EnumSourceTypeTargetType.Node
        };

        public static readonly RedirectModel NullDomainModel = new RedirectModel
        {
            CreationDate = DateTime.Now,
            CreationUser = "test",
            DomainId = null,
            RedirectType = EnumRedirectType.Found,
            Source = "456",
            SourceType = EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = EnumSourceTypeTargetType.Node
        };

        public static readonly RedirectModel DeletedModel = new RedirectModel
        {
            DeletionDate = DateTime.Now,
            CreationUser = "test",
            DomainId = null,
            RedirectType = EnumRedirectType.Found,
            Source = "456",
            SourceType = EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = EnumSourceTypeTargetType.Node
        };

        public static readonly RedirectHistory AddedHistory1 = new RedirectHistory
        {
            RedirectId = 1,
            CreationDate = DateTime.Now.AddMinutes(-10),
            CreationUser = "AddUser",
            RedirectType = (short)EnumRedirectType.Found,
            Source = "456",
            SourceType = (short)EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = (short)EnumSourceTypeTargetType.Node,
            ActionTypeId = (short)EnumActionType.Add,
        };


        public static readonly RedirectHistory AddedHistoryPublication1 = new RedirectHistory
        {
            RedirectId = 1,
            PublicationRequestDate = DateTime.Now.AddDays(-1),
            PublicationRequestId = 123,
            PublicationRequestUser = "publication1",
            CreationDate = DateTime.Now.AddDays(-1)

        };

        public static readonly RedirectHistory AddedHistoryPublication2 = new RedirectHistory
        {
            RedirectId = 1,
            PublicationRequestDate = DateTime.Now.AddDays(0),
            PublicationRequestId = 123,
            PublicationRequestUser = "publication2",
            CreationDate = DateTime.MinValue
        };


        public static readonly RedirectHistory DeletedHistory1 = new RedirectHistory
        {
            RedirectId = 1,
            CreationDate = DateTime.Now,
            CreationUser = "DeleteUser",
            RedirectType = (short)EnumRedirectType.Found,
            Source = "456",
            SourceType = (short)EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = (short)EnumSourceTypeTargetType.Node,
            ActionTypeId = (short)EnumActionType.Delete,
        };

        public static readonly RedirectHistory ModifiedHistory1 = new RedirectHistory
        {
            RedirectId = 1,
            CreationDate = DateTime.Now.AddMinutes(-5),
            CreationUser = "ModifyUser",
            RedirectType = (short)EnumRedirectType.Found,
            Source = "456",
            SourceType = (short)EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = (short)EnumSourceTypeTargetType.Node,
            ActionTypeId = (short)EnumActionType.Update,
            PublicationRequestId = 1
        };

        public static readonly RedirectHistory ModifiedHistory1_2 = new RedirectHistory
        {
            RedirectId = 1,
            CreationDate = DateTime.Now.AddMinutes(-3),
            CreationUser = "ModifyUser2",           
            RedirectType = (short)EnumRedirectType.Found,
            Source = "456",
            SourceType = (short)EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = (short)EnumSourceTypeTargetType.Node,
            ActionTypeId = (short)EnumActionType.Update,
        };

        public static readonly RedirectHistory ModifiedHistory1_3 = new RedirectHistory
        {
            RedirectId = 1,
            CreationDate = DateTime.Now.AddMinutes(-3),
            CreationUser = "ModifyUser3",
            RedirectType = (short)EnumRedirectType.Found,
            Source = "456",
            SourceType = (short)EnumSourceTypeTargetType.Node,
            Target = "123",
            TargetType = (short)EnumSourceTypeTargetType.Node,
            ActionTypeId = (short)EnumActionType.Update,
        };


        public static IEnumerable<object[]> InvalidModels()
        {
            yield return new object[] { InvalidSourceTypeRedirectModel };
            yield return new object[] { InvalidSourceModel };
            yield return new object[] { InvalidTargetModel };
            yield return new object[] { NullSourceModel };
            yield return new object[] { NullDomainModel };
        }

        public static IEnumerable<object[]> GetAddedAndDeleted()
        {
            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1, ModifiedHistory1, ModifiedHistory1_2, DeletedHistory1 }
            };

            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1,  DeletedHistory1 }
            };

            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1, ModifiedHistory1_2, DeletedHistory1 }
            };
        }

        public static IEnumerable<object[]> GetAddedAndModified()
        {
            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1, ModifiedHistory1, ModifiedHistory1_2 }
            };

            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1, ModifiedHistory1_2 }
            };
        }

        public static IEnumerable<object[]> GetAddedOnly()
        {
            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1}
            };

            yield return new object[]
            {
                new List<RedirectHistory>() { AddedHistory1, AddedHistory1}
            };

        }

        public static IEnumerable<object[]> GetModifiedOnly()
        {
            yield return new object[]
            {
                new List<RedirectHistory>() { ModifiedHistory1_2 }
            };

            yield return new object[]
            {
                new List<RedirectHistory>() { ModifiedHistory1_2, ModifiedHistory1 }
            };
        }

        public static IEnumerable<object[]> GetDeleteAndNotAdded()
        {
            yield return new object[]
            {
                new List<RedirectHistory>() { ModifiedHistory1, DeletedHistory1 }
            };

            yield return new object[]
            {
                new List<RedirectHistory>() { DeletedHistory1 }
            };
        }

        public static IEnumerable<object[]> GetPublishedHistory()
        {
            yield return new object[]
            {
                new List<RedirectHistory>{ AddedHistoryPublication1,AddedHistoryPublication2 }
            };
        }

        public static IEnumerable<object[]> GetAddedAndDeletedSimple()
        {
            yield return new object[]
            {
                new List<RedirectHistory>{ AddedHistory1, DeletedHistory1 }
            };
        }
    }
}
