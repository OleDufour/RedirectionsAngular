﻿using System;
using NSubstitute;
using Xunit;

using FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using userDataTransfer = FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.BusinessModule;
using Microsoft.Extensions.Logging;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.User
{
    public class UserTests
    {
        IUserBusinessModule _userModule = null; 
              [Fact]
        public void ShouldAddUser()
        {
            bool res = AddUser(UserFakes.UserRep);
            Assert.True(res);
        }

        private   bool AddUser(userDataTransfer.User user)
        {
            var userRepository = new UserFakeRepo();
            var logger = Substitute.For<ILogger>();
            var config = Substitute.For<IConfig>();

            _userModule = new UserBusinessModule(logger, config, userRepository);
            bool res = _userModule.AddUser(user);
            return res;
        }

        [Fact]
        public void ShouldAddUserWithSubstitute()
        {
            var userRepository = Substitute.For<IUserRepository>();
            var logger = Substitute.For<ILogger>();
            var config = Substitute.For<IConfig>();

            userRepository.AddUser(Arg.Any<userDataTransfer.User>()).Returns(true);
            userRepository.AddUserRole(Arg.Any<Guid>(), Arg.Any<int>()).Returns(true);

            IUserBusinessModule _userModule = new UserBusinessModule(logger, config, userRepository);

            bool res = _userModule.AddUser(UserFakes.UserRep);
            Assert.True(res);

            userRepository.Received(1).AddUser(Arg.Any<userDataTransfer.User>());
            userRepository.Received(UserFakes.UserRep.Roles.Count).AddUserRole(Arg.Any<Guid>(), Arg.Any<int>());
        }

        [Fact]
        public void ShouldNotAddUserBecauseUserAlreadyExist()
        {
            var userRepository = new UserFakeRepo();
            var logger = Substitute.For<ILogger>();
            var config = Substitute.For<IConfig>();

            IUserBusinessModule _userModule = new UserBusinessModule(logger, config, userRepository);

            bool res = _userModule.AddUser(UserFakes.UserRep);

            Assert.True(res);
            res = _userModule.AddUser(UserFakes.UserRep);
            Assert.False(res);
        }

        [Fact]
        public void ShouldNotAddUserBecauseUserRolesAreDuplicated()
        {
            var userRepository = new UserFakeRepo();
            var logger = Substitute.For<ILogger>();
            var config = Substitute.For<IConfig>();

            IUserBusinessModule _userModule = new UserBusinessModule(logger, config, userRepository);

            bool res = _userModule.AddUser(UserFakes.UserRepDuplicatedRoles);
            Assert.False(res);
        }

        [Fact]
        public void ShouldNotBeAbleToDeleteNonExistingUser()
        {
            var userRepository = new UserFakeRepo();
            var logger = Substitute.For<ILogger>();
            var config = Substitute.For<IConfig>();
            IUserBusinessModule _userModule = new UserBusinessModule(logger, config, userRepository);

            bool res = _userModule.DeleteUser(new Guid());
            Assert.False(res);
        }

        [Fact]
        public void UpdateExistingUser()
        {
            var userRepository = new UserFakeRepo();
            var logger = Substitute.For<ILogger>();
            var config = Substitute.For<IConfig>();
              _userModule = new UserBusinessModule(logger, config, userRepository);

            AddUser(UserFakes.UserRep);

            bool res = _userModule.UpdateUser(UserFakes.UserUpdated);
            Assert.True(res);
        }
    }
}
