using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Helper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;
using FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes;
using NSubstitute;
using Xunit;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.Redirect
{
    public class RedirectHelperTests
    {
        private IRedirectBusinessModule redirectModule;
        private IDtoModelMapper<Module.Redirect.DataTransfer.Redirect, RedirectModel> dtoToViewModelMapper;

        public RedirectHelperTests()
        {
            redirectModule = Substitute.For<IRedirectBusinessModule>();
            dtoToViewModelMapper = Substitute.For<IDtoModelMapper<Module.Redirect.DataTransfer.Redirect, RedirectModel>>();
        }

        [Fact]
        public void ShouldThrowDuplicateException()
        {
            var dto = RedirectFakes.DefaultRedirect;
            var redirects = new List<Module.Redirect.DataTransfer.Redirect>();
            var helper = new RedirectHelper(redirectModule, dtoToViewModelMapper);
            RedirectModel record = RedirectFakes.DefaultRedirectModel;
            dtoToViewModelMapper.ModelToDto(record).Returns(dto);
            redirectModule.When(x => x.CheckForValidity(dto)).Do(x => { throw new DuplicateException(); });
            Assert.Throws<DuplicateException>(() => helper.GetValidDto(record, redirects));
        }

        [Fact]
        public void ShouldThrowDuplicateExceptionInFile()
        {
            var redirects = new List<Module.Redirect.DataTransfer.Redirect>
            {
                RedirectFakes.DefaultRedirect
            };

            var helper = new RedirectHelper(redirectModule, dtoToViewModelMapper);
            RedirectModel record = RedirectFakes.DefaultRedirectModel;
            dtoToViewModelMapper.ModelToDto(record).Returns(RedirectFakes.DefaultRedirect);

            Assert.Throws<DuplicateException>(() => helper.GetValidDto(record, redirects));
        }

        [Fact]
        public void ShouldThrowCascadeException()
        {
            var dto = RedirectFakes.DefaultRedirect;
            var redirects = new List<Module.Redirect.DataTransfer.Redirect>();
            var helper = new RedirectHelper(redirectModule, dtoToViewModelMapper);
            RedirectModel record = RedirectFakes.DefaultRedirectModel;
            dtoToViewModelMapper.ModelToDto(record).Returns(dto);
            redirectModule.When(x => x.CheckForValidity(dto)).Do(x => { throw new CascadeException(); });
            Assert.Throws<CascadeException>(() => helper.GetValidDto(record, redirects));
        }

        [Fact]
        public void ShouldThrowCascadeExceptionInFile()
        {
            var redirects = new List<Module.Redirect.DataTransfer.Redirect>
            {
                RedirectFakes.CascadeRedirect
            };

            var helper = new RedirectHelper(redirectModule, dtoToViewModelMapper);
            RedirectModel record = RedirectFakes.DefaultRedirectModel;
            dtoToViewModelMapper.ModelToDto(record).Returns(RedirectFakes.DefaultRedirect);
            Assert.Throws<CascadeException>(() => helper.GetValidDto(record, redirects));
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.InvalidModels), MemberType = typeof(RedirectFakes))]
        public void ShouldThrowInvalidRedirectException(RedirectModel model)
        {
            var redirects = new List<Module.Redirect.DataTransfer.Redirect>();

            var helper = new RedirectHelper(redirectModule, dtoToViewModelMapper);
            Assert.Throws<InvalidRedirectException>(() => helper.GetValidDto(model, redirects));
        }
    }
}
