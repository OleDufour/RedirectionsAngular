﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;
using FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes;
using NSubstitute;
using Xunit;
namespace FnacDarty.Front.WebsiteAdmin.UnitTests.Redirect
{
    public class ValidatorsSourceTargetTests
    {
        [Theory]
        [InlineData(EnumSourceTypeTargetType.Artist, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Brand, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunitySecondaryHome, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunityContributor, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunityPost, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunityTag, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Format, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Node, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Product, "1", true)]
        [InlineData(EnumSourceTypeTargetType.ProductPureMarketPlace, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Series, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Store, "1", false)] // is not defined as a source
        [InlineData(EnumSourceTypeTargetType.Path, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Path, "http://fakepath", false)] // shouldn't be a url
        [InlineData(EnumSourceTypeTargetType.Url, "http://google.fr", false)]// is not defined as a source
        [InlineData(EnumSourceTypeTargetType.Work, "1", true)]

        [InlineData(EnumSourceTypeTargetType.Artist, "FakeArtist", false)]
        [InlineData(EnumSourceTypeTargetType.Brand, "FakeBrand", false)]
        [InlineData(EnumSourceTypeTargetType.CommunityPost, "FakeCommunityPost", false)]
        [InlineData(EnumSourceTypeTargetType.CommunityContributor, "FakeCommunityContributor", false)]
        [InlineData(EnumSourceTypeTargetType.CommunitySecondaryHome, "FakeCommunitySecondaryHome", false)]
        [InlineData(EnumSourceTypeTargetType.CommunityTag, "FakeCommunityTag", false)]
        [InlineData(EnumSourceTypeTargetType.Format, "FakeFormat", false)]
        [InlineData(EnumSourceTypeTargetType.Node, "fakenode", false)]
        [InlineData(EnumSourceTypeTargetType.Product, "FakeProduct", false)]
        [InlineData(EnumSourceTypeTargetType.ProductPureMarketPlace, "FakeProductPureMarketPlace", false)]
        [InlineData(EnumSourceTypeTargetType.Series, "FakeSeries", false)]
        public void ShouldValidateSource(EnumSourceTypeTargetType sourceType, string sourceValue, bool expected)
        {
            var model = (RedirectModel)RedirectFakes.DefaultRedirectModel.Clone();
            model.SourceType = sourceType;
            model.Source = sourceValue;

            var context = new ValidationContext(model);
            var results = new List<ValidationResult>();

            var res = Validator.TryValidateObject(model, context, results, true);

            Assert.Equal(expected, res);
        }

        [Theory]
        [InlineData(EnumSourceTypeTargetType.Artist, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Brand, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunityContributor, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunityPost, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunityTag, "1", true)]
        [InlineData(EnumSourceTypeTargetType.CommunitySecondaryHome, "1", false)]// is not defined as a target
        [InlineData(EnumSourceTypeTargetType.Node, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Format, "1", false)]// is not defined as a target
        [InlineData(EnumSourceTypeTargetType.Product, "1", true)]
        [InlineData(EnumSourceTypeTargetType.ProductPureMarketPlace, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Series, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Store, "1", true)]
        [InlineData(EnumSourceTypeTargetType.Path, "1", false)] // is not defined as a target
        [InlineData(EnumSourceTypeTargetType.Url, "http://google.fr", true)]
        [InlineData(EnumSourceTypeTargetType.Work, "1", false)]// is not defined as a target

        [InlineData(EnumSourceTypeTargetType.Artist, "FakeArtist", false)]
        [InlineData(EnumSourceTypeTargetType.Brand, "FakeBrand", false)]
        [InlineData(EnumSourceTypeTargetType.CommunityPost, "FakeCommunityPost", false)]
        [InlineData(EnumSourceTypeTargetType.CommunityContributor, "FakeCommunityContributor", false)]
        [InlineData(EnumSourceTypeTargetType.CommunityTag, "FakeCommunityTag", false)]
        [InlineData(EnumSourceTypeTargetType.Node, "fakenode", false)]
        [InlineData(EnumSourceTypeTargetType.Product, "FakeProduct", false)]
        [InlineData(EnumSourceTypeTargetType.ProductPureMarketPlace, "FakeProductPureMarketPlace", false)]
        [InlineData(EnumSourceTypeTargetType.Series, "FakeSeries", false)]
        [InlineData(EnumSourceTypeTargetType.Store, "FakeStore", false)]
        [InlineData(EnumSourceTypeTargetType.Url, "fakeurl", false)]
        public void ShouldValidateTarget(EnumSourceTypeTargetType targetType, string targetValue, bool expected)
        {
            var model = (RedirectModel)RedirectFakes.DefaultRedirectModel.Clone();
            model.TargetType = targetType;
            model.Target = targetValue;

            var context = new ValidationContext(model);
            var results = new List<ValidationResult>();

            var res = Validator.TryValidateObject(model, context, results, true);

            Assert.Equal(expected, res);
        }
    }
}

