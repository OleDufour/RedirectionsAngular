using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository;
using FnacDarty.Front.WebsiteAdmin.UnitTests.Fakes;
using NSubstitute;
using Xunit;

namespace FnacDarty.Front.WebsiteAdmin.UnitTests.Redirect
{
    public class RedirectModuleTests
    {
        
    
        public RedirectModuleTests()
        {
        }

        [Fact]
        public void ShouldAddARedirect()
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirect = (Module.Redirect.DataTransfer.Redirect)RedirectFakes.DefaultRedirect.Clone();
            // On s'assure que l'id n'est pas renseign�.
            Assert.False(redirect.RedirectId.HasValue);
            _redirectRepo.AddRedirect(Arg.Any<Module.Redirect.DataTransfer.Redirect>()).Returns(1);
            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);

            //Act
            var res = redirectModule.AddRedirect(redirect);

            //Assert
            Assert.Equal(1, res.RedirectId.Value);
            _redirectRepo.Received().AddRedirect(redirect);
            _redirectHistoryRepo.Received().AddRedirectHistory(Arg.Any<RedirectHistory>());
        }

        [Fact]
        public void ShouldReturnRedirect()
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            //Arrange

            _redirectRepo.GetRedirectById(1).Returns(RedirectFakes.DefaultRedirect);
            var redirectModule = new RedirectBusinessModule(_redirectRepo, null, null, null, null, null, null, null);
            var res = redirectModule.GetRedirect(1);

            //Assert
            Assert.Equal(RedirectFakes.DefaultRedirect, res);
            _redirectRepo.Received().GetRedirectById(1);


        }

        [Theory]
        [InlineData(true, 1, true)]
        [InlineData(true, 0, false)]
        [InlineData(false, 0, false)]
        [InlineData(false, 1, false)]
        public void ShouldUpdateRedirect(bool addRedirectResult, int historyResult, bool expected)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirect = (Module.Redirect.DataTransfer.Redirect)RedirectFakes.DefaultRedirect.Clone();
            redirect.ModificationDate = DateTime.Now;
            redirect.RedirectId = 2;
            _redirectRepo.GetRedirectById(Arg.Any<int>()).Returns(redirect);

            _redirectRepo.UpdateRedirect(Arg.Any<Module.Redirect.DataTransfer.Redirect>()).Returns(addRedirectResult);
            _redirectHistoryRepo.AddRedirectHistory(Arg.Any<RedirectHistory>()).Returns(historyResult);

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            var res = redirectModule.UpdateRedirect(redirect);

            Assert.Equal(expected, res);
            _redirectRepo.Received().UpdateRedirect(redirect);
            if (expected)
            {
                _redirectHistoryRepo.Received().AddRedirectHistory(Arg.Any<RedirectHistory>());
            }
        }

        [Theory]
        [InlineData(true, 1, true)]
        [InlineData(true, 0, false)]
        [InlineData(false, 0, false)]
        [InlineData(false, 1, false)]
        public void ShouldDeleteRedirect(bool redirectRepoResult, int historyResult, bool expected)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirect = (Module.Redirect.DataTransfer.Redirect)RedirectFakes.DefaultRedirect.Clone();
            redirect.RedirectId = 2;
            _redirectRepo.DeleteRedirect(Arg.Any<Module.Redirect.DataTransfer.Redirect>()).Returns(redirectRepoResult);
            _redirectHistoryRepo.AddRedirectHistory(Arg.Any<RedirectHistory>()).Returns(historyResult);

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            var res = redirectModule.DeleteRedirect(redirect);

            Assert.Equal(expected, res);
            _redirectRepo.Received().DeleteRedirect(redirect);
            if (expected)
            {
                _redirectHistoryRepo.Received().AddRedirectHistory(Arg.Any<RedirectHistory>());
            }
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.GetAddedAndDeleted), MemberType = typeof(RedirectFakes))]
        public void ShouldNotGetAddedAndDeletedDraft(List<RedirectHistory> details)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetDraftRedirect(Arg.Any<int>()).Returns(details);
            var res = redirectModule.GetDraftRedirect(EnumDomain.FR_FR);
            Assert.Empty(res);
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.GetAddedAndModified), MemberType = typeof(RedirectFakes))]
        public void ShouldGetLastModifiedWithActionAddedDraft(List<RedirectHistory> details)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetDraftRedirect(Arg.Any<int>()).Returns(details);
            var res = redirectModule.GetDraftRedirect(EnumDomain.FR_FR);
            Assert.Single(res);

            var latest = details.OrderByDescending(x => x.CreationDate).First().CreationDate;
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Add && i.CreationDate == latest);
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.GetAddedOnly), MemberType = typeof(RedirectFakes))]
        public void ShouldGetOnlyOneAddedDraft(List<RedirectHistory> details)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetDraftRedirect(Arg.Any<int>()).Returns(details);
            var res = redirectModule.GetDraftRedirect(EnumDomain.FR_FR);
            Assert.Single(res);
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Add);
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.GetModifiedOnly), MemberType = typeof(RedirectFakes))]
        public void ShouldGetOnlyOneModifiedDraft(List<RedirectHistory> details)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetDraftRedirect(Arg.Any<int>()).Returns(details);
            var res = redirectModule.GetDraftRedirect(EnumDomain.FR_FR);
            Assert.Single(res);
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Update && i.CreationUser == RedirectFakes.ModifiedHistory1_2.CreationUser);
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.GetDeleteAndNotAdded), MemberType = typeof(RedirectFakes))]
        public void ShouldGetOnlyOneDeletedDraft(List<RedirectHistory> details)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetDraftRedirect(Arg.Any<int>()).Returns(details);
            var res = redirectModule.GetDraftRedirect(EnumDomain.FR_FR);
            Assert.Single(res);
            Assert.Contains(res, i => i.ActionTypeId == (short)EnumActionType.Delete);
        }

        [Fact]
        public void ShouldNotUpdateNonExistingRedirect() 
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            // Arrange
            var redirect = (Module.Redirect.DataTransfer.Redirect)RedirectFakes.DefaultRedirect.Clone();
            redirect.RedirectId = 2; 
            _redirectRepo.GetRedirectById(redirect.RedirectId.Value).Returns((Module.Redirect.DataTransfer.Redirect)null); 
            
            // Act
            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            // Assert
            Assert.Throws<NonExistingElementException>(() => redirectModule.UpdateRedirect(redirect));
        }


        [Fact]
        public void ShouldNotUpdateADeletedRedirect() 
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            // Arrange
            var redirect = (Module.Redirect.DataTransfer.Redirect)RedirectFakes.DeletedRedirect.Clone(); // Redirect has a DeletionDate which is not null.
            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetRedirectById(redirect.RedirectId.Value).Returns(redirect); // redirect must exist to proceed.
            // Act
            var res = redirectModule.UpdateRedirect(redirect);
            // Assert
            Assert.False(res);
        }

        [Fact]
        public void ShouldThrowArgumentNullExceptionForDeletionOfNull()
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirect = RedirectFakes.NullRedirect; // NullRedirect is null. Autant passer null directement a redirectModule.DeleteRedirect.
            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            Assert.Throws<ArgumentNullException>(() => redirectModule.DeleteRedirect(redirect));
        }

        [Theory]
        [MemberData(nameof(RedirectFakes.GetPublishedHistory), MemberType = typeof(RedirectFakes))]
        public void ShouldGetRedirectHistory(List<RedirectHistory> redirectHistories)
        {
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirect = RedirectFakes.DefaultRedirect; // Redirect has a DeletionDate which is not null.
            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, null, null, null, null, null, null);
            _redirectRepo.GetRedirectById(Arg.Any<int>()).Returns(redirect);
            _redirectHistoryRepo.GetRedirectHistory(Arg.Any<int>()).Returns(redirectHistories);

            IEnumerable<RedirectHistory> histories = redirectModule.GetRedirectHistory(1);
            int totalHistories = histories.Count();
            // Il y a 2 histories. 

            int counter = 0;
            foreach (RedirectHistory rh in histories)
            {
                if (counter > 0) //Les publication du deuxi�me redirecthistory  est cens� �tre mis � null dans la m�thode KeepPublicationOnlyForLastItem
                {
                    Assert.Null(rh.PublicationRequestDate);
                    Assert.Null(rh.PublicationRequestId);
                    Assert.Null(rh.PublicationRequestUser);
                }
                counter++;
            }
            Assert.Equal(totalHistories, counter);
        }

        /// <summary>
        /// On prend que les �l�ments qui ont �t� supprim�s et pas ajout�s pour la m�me publication.
        /// Comme on simule un ajout et une suppression pour la m�me publication on n'attend pas de r�sultat.
        /// </summary>
        /// <param name="redirectHistories"></param>
        [Theory]
        [MemberData(nameof(RedirectFakes.GetAddedAndDeletedSimple), MemberType = typeof(RedirectFakes))]
        public void ShouldNotGetAddedAndDeletedPublications(IEnumerable<RedirectHistory> redirectHistories)
        {
            var _publicationRequestRepository = Substitute.For<IRedirectPublicationRequestRepository>();
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, _publicationRequestRepository, null, null, null, null, null);
            _publicationRequestRepository.GetPublicationRequestDetails(Arg.Any<int>(), Arg.Any<int>()).Returns(redirectHistories);

            IEnumerable<RedirectHistory> histories = redirectModule.GetPublicationRequestDetails(1, 1);
            Assert.Empty(histories);
        }

        /// <summary>
        /// Il n'y a pas de deletes dans la collection de RedirectHistory.   
        /// </summary>
        /// <param name="redirectHistories"></param>
        [Theory]
        [MemberData(nameof(RedirectFakes.GetAddedAndModified), MemberType = typeof(RedirectFakes))]
        public void ShouldGetLastModifiedWithActionAddedPublications(IEnumerable<RedirectHistory> redirectHistories)
        {
            var _publicationRequestRepository = Substitute.For<IRedirectPublicationRequestRepository>();
            var _redirectRepo = Substitute.For<IRedirectRepository>();
            var _redirectHistoryRepo = Substitute.For<IRedirectHistoryRepository>();

            var redirectModule = new RedirectBusinessModule(_redirectRepo, _redirectHistoryRepo, _publicationRequestRepository, null, null, null, null, null);
            _publicationRequestRepository.GetPublicationRequestDetails(Arg.Any<int>(), Arg.Any<int>()).Returns(redirectHistories);

            IEnumerable<RedirectHistory> histories = redirectModule.GetPublicationRequestDetails(1, 1);
            Assert.Single(histories);
            
            var latest = redirectHistories.OrderByDescending(x => x.CreationDate).First().CreationDate;
            Assert.Contains(histories, i => i.ActionTypeId == (short)EnumActionType.Add && i.CreationDate == latest);
        }
    }
}
