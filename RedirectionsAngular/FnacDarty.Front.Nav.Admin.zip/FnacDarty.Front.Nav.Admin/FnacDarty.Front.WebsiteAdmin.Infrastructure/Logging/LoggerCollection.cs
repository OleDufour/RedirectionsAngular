﻿using System;
using System.Collections.Generic;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    public class LoggerCollection : ILogger
    {
        public IEnumerable<ILogger> LoggerList { get; set; }

        public LoggerCollection(IEnumerable<ILogger> list)
        {            
            LoggerList = list ?? new List<ILogger>();
        }


        public void Error(string format, params object[] arg)
        {
            foreach (var logger in LoggerList)
                logger.Error(format, arg);
        }

        public void Error(Func<string> msgbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Error(msgbuilder);
        }

        public void Error(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Error(msgbuilder, contextbuilder);
        }

        public void Warn(string format, params object[] arg)
        {
            foreach (var logger in LoggerList)
                logger.Warn(format, arg);
        }

        public void Warn(Func<string> msgbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Warn(msgbuilder);
        }

        public void Warn(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Warn(msgbuilder, contextbuilder);
        }

        public void Info(string format, params object[] arg)
        {
            foreach (var logger in LoggerList)
                logger.Info(format, arg);
        }

        public void Info(Func<string> msgbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Info(msgbuilder);
        }

        public void Info(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Info(msgbuilder, contextbuilder);
        }

        public void Trace(string format, params object[] arg)
        {
            foreach (var logger in LoggerList)
                logger.Trace(format, arg);
        }

        public void Trace(Func<string> msgbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Trace(msgbuilder);
        }

        public void Trace(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            foreach (var logger in LoggerList)
                logger.Trace(msgbuilder, contextbuilder);
        }

        public void SetDefaultLogContextFactory(ILogContextFactory factory)
        {
            foreach (var logger in LoggerList)
                logger.SetDefaultLogContextFactory(factory);
        }
    }
}
