﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Provides a basic entity for logging purpose.
    /// </summary>
    /// <remarks>
    /// The logging classes do not require the use of this entity class, it provides commonly 
    /// seen information in logging situation.
    /// </remarks>
    public class LoggerEntity<T> where T : new()
    {

       

        /// <summary>
        /// Gets or sets the creation date of the log event.
        /// </summary>
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Gets or sets the level of the log event.
        /// </summary>
        [JsonConverter(typeof(StringEnumConverter))]
        public LoggerLevel Level { get; set; }

        /// <summary>
        /// Gets or sets the message of the log event.
        /// </summary>
        public string Message { get; set; }


        /// <summary>
        /// Gets or sets the name of the current application.
        /// </summary>
        public string AppName { get; set; }


        /// <summary>
        /// Gets or sets the data of the log context.
        /// </summary>
        public T Context { get; set; }


    }
}
