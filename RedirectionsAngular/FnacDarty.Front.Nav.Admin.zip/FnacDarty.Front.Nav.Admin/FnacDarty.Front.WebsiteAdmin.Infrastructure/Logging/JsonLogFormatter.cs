﻿using Newtonsoft.Json;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Implements an ILogFormatter that serializes a log entity in JSON format.
    /// </summary>
    /// <remarks>
    /// The underlying serialization class is provided by the popular Newtonsoft.JSON library.
    /// System.Runtime.Serialization.Json.DataContractJsonSerializer is not used because of
    /// its poor performance and compliance in regard to the JSON specifications.
    /// </remarks>
    public class JsonLogFormatter<T> : ILogFormatter<T> where T : new()
    {
        /// <inheritdoc cref="ILogFormatter{T}.Format(LoggerEntity{T})" />
        public string Format(LoggerEntity<T> entity)
        {
            return JsonConvert.SerializeObject(entity);
        }
    }
}
