using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using NLog;
using NLog.Config;
using NLog.Targets;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Provides a wrapping adapter between Nlog classes and ILogger interface.
    /// </summary>
    /// <remarks>
    /// NLog logging library has some very advanced logging features and is configurable
    /// via configuration files. This makes the library very suitable for production use.
    /// In short, NlogAdapter is the recommended logger 
    /// namespace, other loggers are only provided for convenience, since they have no 
    /// third-party library dependency.
    /// </remarks>
    public class NlogAdapter : BaseLogger
    {
        private string InternalLoggerName { get; set; }

        private NLog.Logger InternalLogger { get; set; }

        private Dictionary<LoggerLevel, LogLevel> LogLevelMapping = new Dictionary<LoggerLevel, LogLevel>()
        {
            { LoggerLevel.Error,LogLevel.Error },
            { LoggerLevel.Warn, LogLevel.Warn },
            { LoggerLevel.Info, LogLevel.Info },
            { LoggerLevel.Trace, LogLevel.Trace },
        };


        public NlogAdapter(string prefix = null)
        {
            if (string.IsNullOrWhiteSpace(prefix) == true)
                InternalLoggerName = GetType().FullName;
            else
                InternalLoggerName = string.Format("{0}.{1}", GetType().FullName, prefix);
        }

        

        public void ConfigureForFile(String filename, bool rolling = false)
        {
            if (string.IsNullOrWhiteSpace(filename) == true)
                throw new Exception("Unable to configure NlogAdapter for file logging, filename cannot be empty. Please check your configuration file.");

            var config = new LoggingConfiguration();

            var target = new FileTarget()
            {
                FileName = filename,
                Layout = "${message}",
                Encoding = Encoding.UTF8,
            };

            if (rolling == true)
            {
                var ext = Path.GetExtension(filename);
                var archive = filename.Replace(ext, ".{####}" + ext);

                target.ArchiveFileName = archive;
                target.ArchiveAboveSize = 1024 * 1024 * 10;
                target.ArchiveNumbering = ArchiveNumberingMode.Rolling;
            }

            config.AddTarget("file", target);
            config.LoggingRules.Add(new LoggingRule("*", LogLevelMapping[Level], target));

            Configure(config);
        }

        public void ConfigureForConsole()
        {
            var config = new LoggingConfiguration();
            var target = new ConsoleTarget()
            {
                Layout = "${message}",
            };

            config.AddTarget("console", target);
            config.LoggingRules.Add(new LoggingRule("*", LogLevelMapping[Level], target));

            Configure(config);
        }


        private void Configure(LoggingConfiguration config)
        {
            // use a new factory instance instead of the shared LogManager instance to prevent name conflict
            InternalLogger = new LogFactory(config).GetLogger(InternalLoggerName);
            
            // set configuration to NLog's log manager
            //LogManager.Configuration = config;

            // set inner logger
            //InternalLogger = LogManager.GetLogger(LOGGER_NAME);
        }



        protected override void Write(LoggerEntity<object> entity)
        {
            InternalLogger.Info(Formatter.Format(entity));
        }
    }
}
