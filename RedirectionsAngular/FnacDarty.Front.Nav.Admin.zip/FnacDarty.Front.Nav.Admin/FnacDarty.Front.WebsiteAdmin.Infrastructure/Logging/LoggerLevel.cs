﻿namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Specifies a level used to indicate the logging verbosity.
    /// </summary>
    public enum LoggerLevel
    {
        /// <summary>
        /// Indicates that a message should be logged when there is a critical application error.
        /// </summary>
        Error,

        /// <summary>
        /// Indicates that a message should be logged when there is a non-critical application error.
        /// </summary>
        Warn,

        /// <summary>
        /// Indicates that a message which provides application execution information should be logged.
        /// </summary>
        Info,

        /// <summary>
        /// Indicates that a message which provides detailed application execution steps should be logged.
        /// </summary>
        Trace,
    }
}
