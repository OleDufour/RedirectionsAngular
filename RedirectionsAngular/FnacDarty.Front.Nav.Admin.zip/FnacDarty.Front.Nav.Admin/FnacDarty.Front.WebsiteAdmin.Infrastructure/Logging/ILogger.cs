﻿using System;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Exposes methods used for logging.
    /// </summary>
    public interface ILogger
    {

        /// <summary>
        /// Sets the default factory which generates a context object for each line of log.
        /// </summary>
        /// <param name="factory">The default context factory.</param>
        void SetDefaultLogContextFactory(ILogContextFactory factory);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Error level.
        /// </summary>
        /// <remarks>
        /// Client class should use this method to log important messages related to 
        /// runtime or programming errors, especially the ones that may crash applications.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Error("Hello {0}!", "world");
        /// </code>
        /// </example>
        /// <param name="format">A composite format string.</param>
        /// <param name="arg">An array of objects to write using format. </param>
        void Error(string format, params object[] arg);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Error level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message takes considerable time
        /// and/or resources to build. The builder function will not be called if logging is
        /// disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as message builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Error(() => "Hello World!");
        /// log.Error(() => { return "Hello World!"; });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        void Error(Func<string> msgbuilder);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Error level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message and the log context take
        /// significant time and/or resources to build. The builder function will not be called
        /// if logging is disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Error(() => "Hello World!", () => new SampleLoggerContext());
        /// log.Error(() => { return "Hello World!"; }, () => { return new SampleLoggerContext(); });
        /// log.Error(() => { return "Hello World!"; }, () =>
        /// {
        ///     var context = new SampleLoggerContext();
        ///     
        ///     context.Message = "Hello World!";
        ///     context.Id = 42;
        ///     
        ///     return context;
        /// });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        /// <param name="contextbuilder">A function to build the log context.</param>
        void Error(Func<string> msgbuilder, Func<object> contextbuilder);





        /// <summary>
        /// Writes the specified log data at LoggerLevel.Warn level.
        /// </summary>
        /// <remarks>
        /// Client class should use this method to log messages when something unusual
        /// happens but applications can still continue without crashing.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Warn("Hello {0}!", "world");
        /// </code>
        /// </example>
        /// <param name="format">A composite format string.</param>
        /// <param name="arg">An array of objects to write using format. </param>
        void Warn(string format, params object[] arg);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Warn level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message takes considerable time
        /// and/or resources to build. The builder function will not be called if logging is
        /// disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as message builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Warn(() => "Hello World!");
        /// log.Warn(() => { return "Hello World!"; });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        void Warn(Func<string> msgbuilder);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Warn level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message and the log context take
        /// significant time and/or resources to build. The builder function will not be called
        /// if logging is disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Warn(() => "Hello World!", () => new SampleLoggerContext());
        /// log.Warn(() => { return "Hello World!"; }, () => { return new SampleLoggerContext(); });
        /// log.Warn(() => { return "Hello World!"; }, () =>
        /// {
        ///     var context = new SampleLoggerContext();
        ///     
        ///     context.Message = "Hello World!";
        ///     context.Id = 42;
        ///     
        ///     return context;
        /// });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        /// <param name="contextbuilder">A function to build the log context.</param>
        void Warn(Func<string> msgbuilder, Func<object> contextbuilder);






        /// <summary>
        /// Writes the specified log data at LoggerLevel.Info level.
        /// </summary>
        /// <remarks>
        /// Client class should use this method to log informative messages that may be
        /// useful for process analysis.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Info("Hello {0}!", "world");
        /// </code>
        /// </example>
        /// <param name="format">A composite format string.</param>
        /// <param name="arg">An array of objects to write using format. </param>
        void Info(string format, params object[] arg);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Info level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message takes considerable time
        /// and/or resources to build. The builder function will not be called if logging is
        /// disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as message builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Info(() => "Hello World!");
        /// log.Info(() => { return "Hello World!"; });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        void Info(Func<string> msgbuilder);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Info level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message and the log context take
        /// significant time and/or resources to build. The builder function will not be called
        /// if logging is disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Info(() => "Hello World!", () => new SampleLoggerContext());
        /// log.Info(() => { return "Hello World!"; }, () => { return new SampleLoggerContext(); });
        /// log.Info(() => { return "Hello World!"; }, () =>
        /// {
        ///     var context = new SampleLoggerContext();
        ///     
        ///     context.Message = "Hello World!";
        ///     context.Id = 42;
        ///     
        ///     return context;
        /// });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        /// <param name="contextbuilder">A function to build the log context.</param>
        void Info(Func<string> msgbuilder, Func<object> contextbuilder);





        /// <summary>
        /// Writes the specified log data at LoggerLevel.Trace level.
        /// </summary>
        /// <remarks>
        /// Client class should use this method to log verbose technical messages for 
        /// application debugging purpose.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Trace("Hello {0}!", "world");
        /// </code>
        /// </example>
        /// <param name="format">A composite format string.</param>
        /// <param name="arg">An array of objects to write using format. </param>
        void Trace(string format, params object[] arg);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Trace level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message takes significant time
        /// and/or resources to build. The builder function will not be called if logging is
        /// disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as message builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Trace(() => "Hello World!");
        /// log.Trace(() => { return "Hello World!"; });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        void Trace(Func<string> msgbuilder);

        /// <summary>
        /// Writes the specified log data at LoggerLevel.Trace level.
        /// </summary>
        /// <remarks>
        /// This overload is useful in scenarios where the log message and the log context take
        /// significant time and/or resources to build. The builder function will not be called
        /// if logging is disabled or prohibited for the corresponding level.
        /// It is preferrable to use inline lambda functions as builders.
        /// </remarks>
        /// <example>
        /// <code>
        /// log.Trace(() => "Hello World!", () => new SampleLoggerContext());
        /// log.Trace(() => { return "Hello World!"; }, () => { return new SampleLoggerContext(); });
        /// log.Trace(() => { return "Hello World!"; }, () =>
        /// {
        ///     var context = new SampleLoggerContext();
        ///     
        ///     context.Message = "Hello World!";
        ///     context.Id = 42;
        ///     
        ///     return context;
        /// });
        /// </code>
        /// </example>
        /// <param name="msgbuilder">A function to build the log message.</param>
        /// <param name="contextbuilder">A function to build the log context.</param>
        void Trace(Func<string> msgbuilder, Func<object> contextbuilder);



    }
}
