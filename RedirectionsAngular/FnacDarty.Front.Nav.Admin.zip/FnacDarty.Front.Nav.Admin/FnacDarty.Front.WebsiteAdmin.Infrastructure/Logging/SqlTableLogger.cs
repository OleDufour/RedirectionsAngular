﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Mapping;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{

    /// <summary>
    /// Provides a logging implementation using Sql Server storage as backend.
    /// </summary>
    /// <remarks>
    /// Due to its relatively slow backend and its synchronous nature, SqlTableLogger is not the 
    /// best choice for logging in a production environment. It is merely provided for development
    /// convenience.
    /// </remarks>
    public class SqlTableLogger : BaseLogger
    {

        /// <summary>
        /// Gets the connection string of Sql Server to be used as backend
        /// </summary>
        public string ConnectionString { get; private set; }

        /// <summary>
        /// Gets the stored procedure used to insert logs
        /// </summary>
        public string StoredProcedureInsert { get; private set; }

        /// <summary>
        /// Gets the name of the Sql Server table which is used to store log context
        /// </summary>
        /// <remarks>
        /// A table name should be provided instead of a stored procedure because SqlTableLogger
        /// uses bulk insert to add multiple context rows. 
        /// </remarks>
        public string ContextTableName { get; set; }


        /// <summary>
        /// Gets the value that indicates whether log context insertion should be enabled.
        /// </summary>
        public bool ContextInsertEnabled { get; private set; }

        /// <summary>
        /// Creates a new instance of SqlTableLogger
        /// </summary>
        /// <param name="cs">The specified connection string of Sql Server</param>
        /// <param name="sp_insert">The name of the specified stored procedure to insert logs</param>
        /// <param name="context_table">The name of the Sql Server table to insert log contexts</param>
        public SqlTableLogger(string cs, string sp_insert, string context_table)
        {
            ConnectionString = cs;

            StoredProcedureInsert = sp_insert;

            ContextTableName = context_table;

            ContextInsertEnabled = true;
        }



        protected override void Write(LoggerEntity<object> entity)
        {
            var id = 0;

            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var cmd = new SqlCommand(StoredProcedureInsert, connection) { CommandType = System.Data.CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@Level", entity.Level);
                cmd.Parameters.AddWithValue("@AppName", entity.AppName);
                cmd.Parameters.AddWithValue("@Message", entity.Message);

                id = Convert.ToInt32(cmd.ExecuteScalar());
            }

            if (id > 0)
                WriteContext(entity, id);

        }

        private void WriteContext(LoggerEntity<object> entity, int id)
        {
            if (ContextInsertEnabled == false)
                return;

            if (entity.Context == null)
                return;

            var rows = new List<SqlTableContextRow>();

            var prototype = entity.Context.GetType();

            // use reflection to all key-value pairs to insert
            var mis = new List<MemberInfo>();

            mis.AddRange(prototype.GetFields());
            mis.AddRange(prototype.GetProperties());

            foreach (var mi in mis)
            {
                var ignore = mi.GetCustomAttributes(true).FirstOrDefault(a => a is IgnoreDataMemberAttribute) as IgnoreDataMemberAttribute;
                if (ignore != null)
                    continue; // ignore this member

                var value = mi is FieldInfo ? (mi as FieldInfo).GetValue(entity.Context) : (mi as PropertyInfo).GetValue(entity.Context, null);

                if (value == null)
                    continue;

                var row = new SqlTableContextRow()
                {
                    LogId = id,
                    Key = mi.Name,
                    Value = value.ToString(),
                };

                rows.Add(row);
            }

            // write to server using bulk insert
            var writer = new SqlDataWriterMapping(ConnectionString)
            {
                TableName = ContextTableName,
            };
            
            writer.Write<SqlTableContextRow>(rows);
        }


        private class SqlTableContextRow
        {
            public int LogId { get; set; }
            public string Key { get; set; }
            public string Value { get; set; }
        }
    }
}
