﻿using System;
using System.Text;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Implements an ILogFormatter that formats a log entity as human readable text.
    /// </summary>
    /// <remarks>
    /// This class simply calls ToString() method on the log entity to build text.
    /// The log entity has to override its default ToString() in order to provide 
    /// a meaningful output.
    /// </remarks>
    public class TextLogFormatter<T> : ILogFormatter<T> where T : new()
    {
        /// <inheritdoc cref="ILogFormatter{T}.Format(LoggerEntity{T})" />
        public string Format(LoggerEntity<T> entity)
        {
            var sb = new StringBuilder();

            sb.AppendFormat("{0:yyyy-MM-dd HH:mm:ss} ", entity.CreationDate);
            sb.AppendFormat("{0,-8} | ", entity.Level);

            if (String.IsNullOrWhiteSpace(entity.AppName) == false)
            {
                sb.Append(entity.AppName);
                sb.Append(" | ");
            }

            sb.Append(entity.Message);

            if (entity.Context != null)
            {
                sb.Append(" | Context: ");
                sb.Append(entity.Context.ToString());
            }

            return sb.ToString();
        }
    }
}
