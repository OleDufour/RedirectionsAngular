﻿using System;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Provides common proprieties and methods for logging implementations.
    /// </summary>
    public abstract class BaseLogger : ILogger
    {

        public LoggerLevel Level { get; set; }

        public ILogFormatter<object> Formatter { get; set; }

        public string AppName { get; set; }

        protected abstract void Write(LoggerEntity<object> entity);

        protected ILogContextFactory DefaultLogContextFactory { get; set; }

        protected BaseLogger()
        {
            Level = LoggerLevel.Info;
            Formatter = new TextLogFormatter<object>();
        }

        protected bool IsEnabledForLevel(LoggerLevel level)
        {
            switch (Level)
            {
                case LoggerLevel.Error :
                    if (level == LoggerLevel.Error)
                        return true;
                    break;

                case LoggerLevel.Warn:
                    if (level == LoggerLevel.Error || level == LoggerLevel.Warn)
                        return true;
                    break;

                case LoggerLevel.Info:
                    if (level == LoggerLevel.Error || level == LoggerLevel.Warn || level == LoggerLevel.Info)
                        return true;
                    break;

                case LoggerLevel.Trace:
                    return true;

            }

            return false;
        }

        /// <inheritdoc cref="ILogger.SetDefaultLogContextFactory(ILogContextFactory)" />
        public void SetDefaultLogContextFactory(ILogContextFactory factory)
        {
            DefaultLogContextFactory = factory;
        }


        /// <inheritdoc cref="ILogger.Error(string, object[])" />
        public void Error(string format, params object[] arg)
        {
            if (IsEnabledForLevel(LoggerLevel.Error) == false)
                return;

            Write(LoggerLevel.Error, () => String.Format(format, arg));
        }

        /// <inheritdoc cref="ILogger.Error(Func{string})" />
        public void Error(Func<string> msgbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Error) == false)
                return;

            Write(LoggerLevel.Error, msgbuilder);
        }


        /// <inheritdoc cref="ILogger.Error(Func{string}, Func{object})" />
        public void Error(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Error) == false)
                return;

            Write(LoggerLevel.Error, msgbuilder, contextbuilder);
        }





        /// <inheritdoc cref="ILogger.Warn(string, object[])" />
        public void Warn(string format, params object[] arg)
        {
            if (IsEnabledForLevel(LoggerLevel.Warn) == false)
                return;

            Write(LoggerLevel.Warn, () => String.Format(format, arg));
        }

        /// <inheritdoc cref="ILogger.Warn(Func{string})" />
        public void Warn(Func<string> msgbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Warn) == false)
                return;

            Write(LoggerLevel.Warn, msgbuilder);
        }


        /// <inheritdoc cref="ILogger.Warn(Func{string}, Func{object})" />
        public void Warn(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Warn) == false)
                return;

            Write(LoggerLevel.Warn, msgbuilder, contextbuilder);
        }




        /// <inheritdoc cref="ILogger.Info(string, object[])" />
        public void Info(string format, params object[] arg)
        {
            if (IsEnabledForLevel(LoggerLevel.Info) == false)
                return;

            Write(LoggerLevel.Info, () => String.Format(format, arg));
        }

        /// <inheritdoc cref="ILogger.Info(Func{string})" />
        public void Info(Func<string> msgbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Info) == false)
                return;

            Write(LoggerLevel.Info, msgbuilder);
        }


        /// <inheritdoc cref="ILogger.Info(Func{string}, Func{object})" />
        public void Info(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Info) == false)
                return;

            Write(LoggerLevel.Info, msgbuilder, contextbuilder);
        }





        /// <inheritdoc cref="ILogger.Trace(string, object[])" />
        public void Trace(string format, params object[] arg)
        {
            if (IsEnabledForLevel(LoggerLevel.Trace) == false)
                return;

            Write(LoggerLevel.Trace, () => String.Format(format, arg));
        }

        /// <inheritdoc cref="ILogger.Trace(Func{string})" />
        public void Trace(Func<string> msgbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Trace) == false)
                return;

            Write(LoggerLevel.Trace, msgbuilder);
        }


        /// <inheritdoc cref="ILogger.Trace(Func{string}, Func{object})" />
        public void Trace(Func<string> msgbuilder, Func<object> contextbuilder)
        {
            if (IsEnabledForLevel(LoggerLevel.Trace) == false)
                return;

            Write(LoggerLevel.Trace, msgbuilder, contextbuilder);
        }




        protected void Write(LoggerLevel level, Func<string> msgbuilder)
        {
            Write(level, msgbuilder, null);
        }


        protected void Write(LoggerLevel level, Func<string> msgbuilder, Func<object> contextbuilder) 
        {
            var context = default(object);

            if (contextbuilder == null)
            {
                if (DefaultLogContextFactory != null)
                    context = DefaultLogContextFactory.GetLogContext();
            }
            else
                context = contextbuilder();


            var entity = new LoggerEntity<object>()
            {
                CreationDate = DateTime.Now,
                Level = level,
                AppName = AppName,
                Message = msgbuilder(),
                Context = context,
            };

            Write(entity);
        }

    }
}
