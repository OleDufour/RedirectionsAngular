using System;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    //public class EnyimCachingLogFactoryAdapter : Enyim.Caching.ILogFactory
    //{

    //    public EnyimCachingLogFactoryAdapter(EnyimCachingLogAdapter logger)
    //    {
    //        Logger = logger;
    //    }

    //    private EnyimCachingLogAdapter Logger { get; set; }

    //    public Enyim.Caching.ILog GetLogger(Type type)
    //    {
    //        return Logger;
    //    }

    //    public Enyim.Caching.ILog GetLogger(string name)
    //    {
    //        return Logger;
    //    }
    //}
}
