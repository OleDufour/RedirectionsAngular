﻿using System;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Provides neutral "null" logging behaviors for testing purpose.
    /// </summary>
    /// <remarks>
    /// See http://en.wikipedia.org/wiki/Null_Object_pattern for details. In short, this class does nothing.
    /// </remarks>
    public class NullLogger : ILogger
    {
        /// <inheritdoc cref="ILogger.Error(string, object[])" />
        public void Error(string format, params object[] arg)
        {
        }

        /// <inheritdoc cref="ILogger.Error(Func{string})" />
        public void Error(Func<string> msgbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Error(Func{string}, Func{object})" />
        public void Error(Func<string> msgbuilder, Func<object> contextbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Warn(string, object[])" />
        public void Warn(string format, params object[] arg)
        {
        }

        /// <inheritdoc cref="ILogger.Warn(Func{string})" />
        public void Warn(Func<string> msgbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Error(Func{string}, Func{object})" />
        public void Warn(Func<string> msgbuilder, Func<object> contextbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Info(string, object[])" />
        public void Info(string format, params object[] arg)
        {
        }

        /// <inheritdoc cref="ILogger.Info(Func{string})" />
        public void Info(Func<string> msgbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Error(Func{string}, Func{object})" />
        public void Info(Func<string> msgbuilder, Func<object> contextbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Trace(string, object[])" />
        public void Trace(string format, params object[] arg)
        {
        }

        /// <inheritdoc cref="ILogger.Trace(Func{string})" />
        public void Trace(Func<string> msgbuilder)
        {
        }

        /// <inheritdoc cref="ILogger.Error(Func{string}, Func{object})" />
        public void Trace(Func<string> msgbuilder, Func<object> contextbuilder)
        {
        }


        /// <inheritdoc cref="ILogger.SetDefaultLogContextFactory(ILogContextFactory)" />
        public void SetDefaultLogContextFactory(ILogContextFactory factory)
        {
            
        }
    }
}
