﻿namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Allows to format an object for logging use.
    /// </summary>
    public interface ILogFormatter<T> where T : new()
    {
        /// <summary>
        /// Transforms a structured data instance into its text representation.
        /// </summary>
        /// <param name="entity">The entity to be formatted.</param>
        /// <returns>The text representation of the entity</returns>
        string Format(LoggerEntity<T> entity);
    }
}
