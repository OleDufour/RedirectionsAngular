using System;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    //public class EnyimCachingLogAdapter : Enyim.Caching.ILog
    //{
    //    public EnyimCachingLogAdapter(ILogger logger)
    //    {
    //        Logger = logger;
    //    }

    //    private ILogger Logger { get; set; }

    //    public bool IsDebugEnabled 
    //    {
    //        get { return false; }
    //    }

    //    public bool IsInfoEnabled
    //    {
    //        get { return false; }
    //    }

    //    public bool IsWarnEnabled
    //    {
    //        get { return true; }
    //    }

    //    public bool IsErrorEnabled
    //    {
    //        get { return true; }
    //    }

    //    public bool IsFatalEnabled
    //    {
    //        get { return true; }
    //    }

    //    public void Debug(object message) { if (IsDebugEnabled) Logger.Trace(() => message.ToString()); }
    //    public void Debug(object message, Exception exception) { if (IsDebugEnabled) Logger.Trace(() => message.ToString()); }
    //    public void DebugFormat(string format, object arg0) { if (IsDebugEnabled) Logger.Trace(() => String.Format(format, arg0)); }
    //    public void DebugFormat(string format, object arg0, object arg1) { if (IsDebugEnabled) Logger.Trace(() => String.Format(format, arg0, arg1)); }
    //    public void DebugFormat(string format, object arg0, object arg1, object arg2) { if (IsDebugEnabled) Logger.Trace(() => String.Format(format, arg0, arg1, arg2)); }
    //    public void DebugFormat(string format, params object[] args) { if (IsDebugEnabled) Logger.Trace(() => String.Format(format, args)); }
    //    public void DebugFormat(IFormatProvider provider, string format, params object[] args) { if (IsDebugEnabled) Logger.Trace(() => String.Format(format, args)); }

    //    public void Info(object message) { if (IsInfoEnabled) Logger.Info(() => message.ToString()); }
    //    public void Info(object message, Exception exception) { if (IsInfoEnabled) Logger.Info(() => message.ToString()); }
    //    public void InfoFormat(string format, object arg0) { if (IsInfoEnabled) Logger.Info(() => String.Format(format, arg0)); }
    //    public void InfoFormat(string format, object arg0, object arg1) { if (IsInfoEnabled) Logger.Info(() => String.Format(format, arg0, arg1)); }
    //    public void InfoFormat(string format, object arg0, object arg1, object arg2) { if (IsInfoEnabled) Logger.Info(() => String.Format(format, arg0, arg1, arg2)); }
    //    public void InfoFormat(string format, params object[] args) { if (IsInfoEnabled) Logger.Info(() => String.Format(format, args)); }
    //    public void InfoFormat(IFormatProvider provider, string format, params object[] args) { if (IsInfoEnabled) Logger.Info(() => String.Format(format, args)); }

    //    public void Warn(object message) { if (IsWarnEnabled) Logger.Warn(() => message.ToString()); }
    //    public void Warn(object message, Exception exception) { if (IsWarnEnabled) Logger.Warn(() => message.ToString()); }
    //    public void WarnFormat(string format, object arg0) { if (IsWarnEnabled) Logger.Warn(() => String.Format(format, arg0)); }
    //    public void WarnFormat(string format, object arg0, object arg1) { if (IsWarnEnabled) Logger.Warn(() => String.Format(format, arg0, arg1)); }
    //    public void WarnFormat(string format, object arg0, object arg1, object arg2) { if (IsWarnEnabled) Logger.Warn(() => String.Format(format, arg0, arg1, arg2)); }
    //    public void WarnFormat(string format, params object[] args) { if (IsWarnEnabled) Logger.Warn(() => String.Format(format, args)); }
    //    public void WarnFormat(IFormatProvider provider, string format, params object[] args) { if (IsWarnEnabled) Logger.Warn(() => String.Format(format, args)); }

    //    public void Error(object message) { if (IsErrorEnabled) Logger.Error(() => message.ToString()); }
    //    public void Error(object message, Exception exception) { if (IsErrorEnabled) Logger.Error(() => message.ToString()); }
    //    public void ErrorFormat(string format, object arg0) { if (IsErrorEnabled) Logger.Error(() => String.Format(format, arg0)); }
    //    public void ErrorFormat(string format, object arg0, object arg1) { if (IsErrorEnabled) Logger.Error(() => String.Format(format, arg0, arg1)); }
    //    public void ErrorFormat(string format, object arg0, object arg1, object arg2) { if (IsErrorEnabled) Logger.Error(() => String.Format(format, arg0, arg1, arg2)); }
    //    public void ErrorFormat(string format, params object[] args) { if (IsErrorEnabled) Logger.Error(() => String.Format(format, args)); }
    //    public void ErrorFormat(IFormatProvider provider, string format, params object[] args) { if (IsErrorEnabled) Logger.Error(() => String.Format(format, args)); }

    //    public void Fatal(object message) { if (IsFatalEnabled) Logger.Error(() => message.ToString()); }
    //    public void Fatal(object message, Exception exception) { if (IsFatalEnabled) Logger.Error(() => message.ToString()); }
    //    public void FatalFormat(string format, object arg0) { if (IsFatalEnabled) Logger.Error(() => String.Format(format, arg0)); }
    //    public void FatalFormat(string format, object arg0, object arg1) { if (IsFatalEnabled) Logger.Error(() => String.Format(format, arg0, arg1)); }
    //    public void FatalFormat(string format, object arg0, object arg1, object arg2) { if (IsFatalEnabled) Logger.Error(() => String.Format(format, arg0, arg1, arg2)); }
    //    public void FatalFormat(string format, params object[] args) { if (IsFatalEnabled) Logger.Error(() => String.Format(format, args)); }
    //    public void FatalFormat(IFormatProvider provider, string format, params object[] args) { if (IsFatalEnabled) Logger.Error(() => String.Format(format, args)); }

    //}
}
