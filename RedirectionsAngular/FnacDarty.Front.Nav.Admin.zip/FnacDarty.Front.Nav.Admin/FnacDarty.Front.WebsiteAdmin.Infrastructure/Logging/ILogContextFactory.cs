﻿namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    public interface ILogContextFactory
    {
        object GetLogContext();
    }
}
