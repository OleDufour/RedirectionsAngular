﻿using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Configuration;

namespace FnacDarty.Front.Nav.Admin.Portal.Infrastructure.Logging
{
    /// <summary>
    /// Provides a convenient way to instantiate logger from configuration.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The LoggerFactory class relies on an implementation of IConfig to retrieve values from 
    /// configuration. See the following table for expected configuration values:
    /// </para>
    /// 
    /// <para>
    /// Required commons values for all loggers:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Logger</term>
    ///         <description>Console | File | Collection | Null</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// <para>
    /// Additional required values for Console Logger:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Logger.AppName</term>
    ///         <description>The name of the application</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.Level</term>
    ///         <description>Trace | Info | Warn | Error</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.Formatter</term>
    ///         <description>Text | Json</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// 
    /// <para>
    /// Additional required values for File Logger:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Logger.AppName</term>
    ///         <description>The name of the application</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.Level</term>
    ///         <description>Trace | Info | Warn | Error</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.Formatter</term>
    ///         <description>Text | Json</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.File.FileName</term>
    ///         <description>Absolute or relative file path</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// 
    /// <para>
    /// Additional required values for Sql Server Logger:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Logger.AppName</term>
    ///         <description>The name of the application</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.Level</term>
    ///         <description>Trace | Info | Warn | Error</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.Formatter</term>
    ///         <description>Text | Json</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.SqlServer.ConnectionString</term>
    ///         <description>A valid Sql Server connection string</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.SqlServer.InsertStoredProcedure</term>
    ///         <description>The stored procedure to insert log rows</description>
    ///     </item>
    ///     <item>
    ///         <term>Logger.SqlServer.ContextTableName</term>
    ///         <description>The name of Sql Server table to store context rows</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// 
    /// <para>
    /// Additional information for Collection Logger:
    /// 
    /// To combine several loggers, in addition of setting Logger to Collection a series
    /// of loggers must be defined in the following format: Logger.[Number].[...].
    /// For instance, the configuration for a combined Console and File logger looks like:
    /// 
    /// Logger.1 = Console
    /// Logger.1.Level = Trace
    /// Logger.1.Formatter = Text
    /// 
    /// Logger.2 = File
    /// Logger.2.Level = Info
    /// Logger.2.Formatter = Json
    /// Logger.2.FileName = %TEMP%\test.log
    /// Logger.2.File.Rolling = true
    /// </para>
    /// 
    /// </remarks>
    public class LoggerFactory
    {
        private const string LOGGER_TYPE_FILE = "File";
        private const string LOGGER_TYPE_CONSOLE = "Console";
        private const string LOGGER_TYPE_SQL_SERVER = "SqlServer";
        private const string LOGGER_TYPE_COLLECTION = "Collection";

        private const string LOGGER_LEVEL_ERROR = "Error";
        private const string LOGGER_LEVEL_WARN = "Warn";
        private const string LOGGER_LEVEL_INFO = "Info";
        private const string LOGGER_LEVEL_TRACE = "Trace";

        private const string LOGGER_FORMATTER_TEXT = "Text";
        private const string LOGGER_FORMATTER_JSON = "Json";

        private const int MAX_LOGGER_COUNT = 10;



        public IConfig Configuration { get; set; }


        public LoggerFactory(IConfig config)
        {
            Configuration = config;
        }



        public ILogger CreateLoggerFromConfiguration()
        {
            var prefix = "Logger";
            var cfg_logger = Configuration.GetSettingValue(prefix);

            switch (cfg_logger)
            {

                case LOGGER_TYPE_FILE :
                    return CreateFileLoggerFromConfiguration(prefix);

                case LOGGER_TYPE_CONSOLE:
                    return CreateConsoleLoggerFromConfiguration(prefix);

                case LOGGER_TYPE_SQL_SERVER:
                    return CreateSqlServerLoggerFromConfiguration(prefix);

                case LOGGER_TYPE_COLLECTION:
                    return CreateLoggerCollectionFromConfiguration();

                default :
                    return new NullLogger();

            }

        }

        private ILogger CreateLoggerCollectionFromConfiguration()
        {
            var collection = new List<ILogger>();

            for (var i = 1; i < MAX_LOGGER_COUNT; i++)
            {
                var prefix = String.Format("Logger.{0}", i);

                var cfg_logger = Configuration.GetSettingValueOptional(prefix);

                if (String.IsNullOrWhiteSpace(cfg_logger) == true)
                    break;

                switch (cfg_logger)
                {
                    case LOGGER_TYPE_FILE:
                        collection.Add(CreateFileLoggerFromConfiguration(prefix));
                        break;

                    case LOGGER_TYPE_CONSOLE:
                        collection.Add(CreateConsoleLoggerFromConfiguration(prefix));
                        break;

                    case LOGGER_TYPE_SQL_SERVER:
                        collection.Add(CreateSqlServerLoggerFromConfiguration(prefix));
                        break;

                    default:
                        break;
                }
            }



            return new LoggerCollection(collection);
        }


        private ILogger CreateSqlServerLoggerFromConfiguration(string prefix)
        {
            var cfg_cs = Configuration.GetSettingValue(String.Format("{0}.SqlServer.ConnectionString", prefix));
            var cfg_insert = Configuration.GetSettingValue(String.Format("{0}.SqlServer.InsertStoredProcedure", prefix));
            var cfg_tabcontext = Configuration.GetSettingValue(String.Format("{0}.SqlServer.ContextTableName", prefix));


            var formatter = GetFormatterFromConfiguration(prefix);
            var logger = new SqlTableLogger(cfg_cs, cfg_insert, cfg_tabcontext)
            {
                Level = GetLevelFromConfiguration(prefix),
                AppName = GetAppNameFromConfiguration(prefix),
            };

            if (formatter != null)
                logger.Formatter = formatter;

            return logger;
        }




        private ILogger CreateConsoleLoggerFromConfiguration(string prefix)
        {
            var formatter = GetFormatterFromConfiguration(prefix);
            var logger = new NlogAdapter()
            {
                Level = GetLevelFromConfiguration(prefix),
                AppName = GetAppNameFromConfiguration(prefix),
            };

            if (formatter != null)
                logger.Formatter = formatter;
            
            logger.ConfigureForConsole();

            return logger;
        }

        private ILogger CreateFileLoggerFromConfiguration(string prefix)
        {
            var cfg_file = Configuration.GetSettingValue(String.Format("{0}.File.FileName", prefix));
            var cfg_rolling = Configuration.GetSettingValueOptional<bool>(String.Format("{0}.File.Rolling", prefix));

            // expand environment variables if detected, since nlog can't handle this natively
            if (cfg_file.Contains('%') == true)
                cfg_file = Environment.ExpandEnvironmentVariables(cfg_file);

            var formatter = GetFormatterFromConfiguration(prefix);
            var logger = new NlogAdapter() 
            {
                Level = GetLevelFromConfiguration(prefix),
                AppName = GetAppNameFromConfiguration(prefix),
            };

            if (formatter != null)
                logger.Formatter = formatter;

            logger.ConfigureForFile(cfg_file, cfg_rolling);

            return logger;
        }

        private LoggerLevel GetLevelFromConfiguration(string prefix)
        {
            switch (Configuration.GetSettingValueOptional(String.Format("{0}.Level", prefix)))
            {
                case LOGGER_LEVEL_TRACE:
                    return LoggerLevel.Trace;


                case LOGGER_LEVEL_WARN:
                    return LoggerLevel.Warn;

                case LOGGER_LEVEL_ERROR:
                    return LoggerLevel.Error;

                default:
                case LOGGER_LEVEL_INFO:
                    return LoggerLevel.Info;
            }
        }

        private ILogFormatter<object> GetFormatterFromConfiguration(string prefix)
        {
            switch (Configuration.GetSettingValueOptional(String.Format("{0}.Formatter", prefix)))
            {
                case LOGGER_FORMATTER_TEXT:
                    return new TextLogFormatter<object>();

                case LOGGER_FORMATTER_JSON:
                    return new JsonLogFormatter<object>();

                default:
                    return null;
            }
        }

        private string GetAppNameFromConfiguration(string prefix)
        {
            return Configuration.GetSettingValueOptional(String.Format("{0}.AppName", prefix));
        }



    }
}
