﻿using System;
using System.Text;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Text
{
    /// <summary>
    /// Generates lorem ipsum placeholder text.
    /// </summary>
    public static class LoremIpsum
    {
        private static string[] WORDS = new string[] { "consetetur", "sadipscing", "elitr", "sed", "diam", "nonumy", "eirmod", 
                "tempor", "invidunt", "ut", "labore", "et", "dolore", "magna", "aliquyam", "erat", "sed", "diam", "voluptua", 
                "at", "vero", "eos", "et", "accusam", "et", "justo", "duo", "dolores", "et", "ea", "rebum", "stet", "clita", 
                "kasd", "gubergren", "no", "sea", "takimata", "sanctus", "est", "lorem", "ipsum", "dolor", "sit", "amet", 
                "lorem", "ipsum", "dolor", "sit", "amet", "consetetur", "sadipscing", "elitr", "sed", "diam", "nonumy", "eirmod",
                "tempor", "invidunt", "ut", "labore", "et", "dolore", "magna", "aliquyam", "erat", "sed", "diam", "voluptua", 
                "at", "vero", "eos", "et", "accusam", "et", "justo", "duo", "dolores", "et", "ea", "rebum", "stet", "clita", 
                "kasd", "gubergren", "no", "sea", "takimata", "sanctus", "est", "lorem", "ipsum", "dolor", "sit", "amet", 
                "lorem", "ipsum", "dolor", "sit", "amet", "consetetur", "sadipscing", "elitr", "sed", "diam", "nonumy", "eirmod", 
                "tempor", "invidunt", "ut", "labore", "et", "dolore", "magna", "aliquyam", "erat", "sed", "diam", "voluptua", 
                "at", "vero", "eos", "et", "accusam", "et", "justo", "duo", "dolores", "et", "ea", "rebum", "stet", "clita", 
                "kasd", "gubergren", "no", "sea", "takimata", "sanctus", "est", "lorem", "ipsum", "dolor", "sit", "amet", "duis",
                "autem", "vel", "eum", "iriure", "dolor", "in", "hendrerit", "in", "vulputate", "velit", "esse", "molestie", 
                "consequat", "vel", "illum", "dolore", "eu", "feugiat", "nulla", "facilisis", "at", "vero", "eros", "et", 
                "accumsan", "et", "iusto", "odio", "dignissim", "qui", "blandit", "praesent", "luptatum", "zzril", "delenit", 
                "augue", "duis", "dolore", "te", "feugait", "nulla", "facilisi", "lorem", "ipsum", "dolor", "sit", "amet", 
                "consectetuer", "adipiscing", "elit", "sed", "diam", "nonummy", "nibh", "euismod", "tincidunt", "ut", "laoreet", 
                "dolore", "magna", "aliquam", "erat", "volutpat", "ut", "wisi", "enim", "ad", "minim", "veniam", "quis", 
                "nostrud", "exerci", "tation", "ullamcorper", "suscipit", "lobortis", "nisl", "ut", "aliquip", "ex", "ea", 
                "commodo", "consequat", "duis", "autem", "vel", "eum", "iriure", "dolor", "in", "hendrerit", "in", "vulputate", 
                "velit", "esse", "molestie", "consequat", "vel", "illum", "dolore", "eu", "feugiat", "nulla", "facilisis", "at", 
                "vero", "eros", "et", "accumsan", "et", "iusto", "odio", "dignissim", "qui", "blandit", "praesent", "luptatum", 
                "zzril", "delenit", "augue", "duis", "dolore", "te", "feugait", "nulla", "facilisi", "nam", "liber", "tempor", 
                "cum", "soluta", "nobis", "eleifend", "option", "congue", "nihil", "imperdiet", "doming", "id", "quod", "mazim", 
                "placerat", "facer", "possim", "assum", "lorem", "ipsum", "dolor", "sit", "amet", "consectetuer", "adipiscing", 
                "elit", "sed", "diam", "nonummy", "nibh", "euismod", "tincidunt", "ut", "laoreet", "dolore", "magna", "aliquam", 
                "erat", "volutpat", "ut", "wisi", "enim", "ad", "minim", "veniam", "quis", "nostrud", "exerci", "tation", 
                "ullamcorper", "suscipit", "lobortis", "nisl", "ut", "aliquip", "ex", "ea", "commodo", "consequat", "duis", 
                "autem", "vel", "eum", "iriure", "dolor", "in", "hendrerit", "in", "vulputate", "velit", "esse", "molestie", 
                "consequat", "vel", "illum", "dolore", "eu", "feugiat", "nulla", "facilisis", "at", "vero", "eos", "et", "accusam", 
                "et", "justo", "duo", "dolores", "et", "ea", "rebum", "stet", "clita", "kasd", "gubergren", "no", "sea", 
                "takimata", "sanctus", "est", "lorem", "ipsum", "dolor", "sit", "amet", "lorem", "ipsum", "dolor", "sit", 
                "amet", "consetetur", "sadipscing", "elitr", "sed", "diam", "nonumy", "eirmod", "tempor", "invidunt", "ut", 
                "labore", "et", "dolore", "magna", "aliquyam", "erat", "sed", "diam", "voluptua", "at", "vero", "eos", "et", 
                "accusam", "et", "justo", "duo", "dolores", "et", "ea", "rebum", "stet", "clita", "kasd", "gubergren", "no", 
                "sea", "takimata", "sanctus", "est", "lorem", "ipsum", "dolor", "sit", "amet", "lorem", "ipsum", "dolor", "sit", 
                "amet", "consetetur", "sadipscing", "elitr", "at", "accusam", "aliquyam", "diam", "diam", "dolore", "dolores", 
                "duo", "eirmod", "eos", "erat", "et", "nonumy", "sed", "tempor", "et", "et", "invidunt", "justo", "labore", 
                "stet", "clita", "ea", "et", "gubergren", "kasd", "magna", "no", "rebum", "sanctus", "sea", "sed", "takimata", 
                "ut", "vero", "voluptua", "est", "lorem", "ipsum", "dolor", "sit", "amet", "lorem", "ipsum", "dolor", "sit", 
                "amet", "consetetur", "sadipscing", "elitr", "sed", "diam", "nonumy", "eirmod", "tempor", "invidunt", "ut", 
                "labore", "et", "dolore", "magna", "aliquyam", "erat", "consetetur", "sadipscing", "elitr", "sed", "diam", 
                "nonumy", "eirmod", "tempor", "invidunt", "ut", "labore", "et", "dolore", "magna", "aliquyam", "erat", "sed", 
                "diam", "voluptua", "at", "vero", "eos", "et", "accusam", "et", "justo", "duo", "dolores", "et", "ea", 
                "rebum", "stet", "clita", "kasd", "gubergren", "no", "sea", "takimata", "sanctus", "est", "lorem", "ipsum" };


        private const string HEADER = "lorem ipsum dolor sit amet";

        private static Random RandomGenerator = new Random();


        private static string GetBody(int wc)
        {
            var sb = new StringBuilder();

            for (var i = 0; i <= wc; i++)
            {
                sb.Append(" ");
                sb.Append(WORDS[RandomGenerator.Next(WORDS.Length - 1)]);
            }

            return sb.ToString();
        }


        /// <summary>
        /// Generates one lorem ipsum sentence with the specified word count.
        /// </summary>
        /// <param name="wc">The specified word count</param>
        /// <returns>One generated lorem ipsum sentence.</returns>
        public static string GetWords(int wc = 20)
        {
            var sb = new StringBuilder();

            sb.Append(HEADER);
            sb.Append(GetBody(wc));
            sb.Append(".");

            return sb.ToString();
        }

        /// <summary>
        /// Generates lorem ipsum sentences with the specified word and sentence count.
        /// </summary>
        /// <param name="sc">The specified word count</param>
        /// <param name="wc">The specified sentence count</param>
        /// <returns>Generated lorem ipsum sentences</returns>
        public static string GetSentences(int sc = 5, int wc = 20)
        {
            var sb = new StringBuilder();

            sb.Append(GetWords(wc));
            
            for (var i = 0; i <= sc; i++)
            {
                sb.Append(GetBody(wc));
                sb.Append(".");
            }

            return sb.ToString();
        }

        /// <summary>
        /// Generates lorem ipsum paragraphs with the specified word, sentence and paragraph count.
        /// </summary>
        /// <param name="pc">The specified paragraph count</param>
        /// <param name="sc">The specified sentence count</param>
        /// <param name="wc">The specified word count</param>
        /// <returns>Generated lorem ipsum paragraphs</returns>
        public static string GetParagraphs(int pc = 5, int sc = 5, int wc = 20)
        {
            var sb = new StringBuilder();

            for (var i = 0; i <= pc; i++)
                sb.AppendLine(GetSentences(sc));

            return sb.ToString();
        }
    }
}
