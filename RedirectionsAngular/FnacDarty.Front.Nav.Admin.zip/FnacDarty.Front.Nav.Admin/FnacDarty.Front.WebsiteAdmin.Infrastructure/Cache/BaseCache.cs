using System;
using System.Runtime.Caching;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    public abstract class BaseCache
    {
        public abstract T Get<T>(string key);

        public abstract void Set(string key, object value, CacheItemPolicy policy = null);

        public abstract void Remove(string key);


        /// <inheritdoc cref="ICache.Get(CacheNamespace, string)" />
        public virtual T Get<T>(CacheNamespace ns, string key)
        {
            var nskey = $"{ns}-{key}";
            return Get<T>(nskey);
        }

        /// <inheritdoc cref="ICache.Set(CacheNamespace, string, object, CacheItemPolicy)" />
        public virtual void Set(CacheNamespace ns, string key, object value, CacheItemPolicy policy = null)
        {
            var nskey = $"{ns}-{key}";
            Set(nskey, value, policy);
        }

        /// <inheritdoc cref="ICache.Remove(CacheNamespace, string)" />
        public virtual void Remove(CacheNamespace ns, string key)
        {
            var nskey = $"{ns}-{key}";
            Remove(nskey);
        }


        /// <inheritdoc cref="ICache.GetNamespace(string)" />
        public virtual CacheNamespace GetNamespace(string key)
        {
            var value = Get<string>(key);

            if (string.IsNullOrWhiteSpace(value) == true)
                return null;

            return new CacheNamespace() { Namespace = key, Value = value };
        }

        /// <inheritdoc cref="ICache.GetNamespaceOrCreateIfNotExists(string, CacheItemPolicy)" />
        public virtual CacheNamespace GetNamespaceOrCreateIfNotExists(string key, CacheItemPolicy policy = null)
        {
            var ns = GetNamespace(key);

            return ns ?? CreateNamespace(key, policy);
        }

        /// <inheritdoc cref="ICache.CreateNamespace(string, CacheItemPolicy)" />
        public virtual CacheNamespace CreateNamespace(string key, CacheItemPolicy policy = null)
        {
            if (policy == null)
                policy = CacheFactory.INFINITE_CACHE_POLICY; // namespace should reside as long as possible in the cache

            var guid = Guid.NewGuid();
            var value = Convert.ToBase64String(guid.ToByteArray()).TrimEnd('=');

            Set(key, value, policy);

            return new CacheNamespace() { Namespace = key, Value = value };
        }

        /// <inheritdoc cref="ICache.RemoveNamespace(string)" />
        public virtual void RemoveNamespace(string nskey)
        {
            if (string.IsNullOrWhiteSpace(nskey) == true)
                return;

            Remove(nskey);
        }
    }
}
