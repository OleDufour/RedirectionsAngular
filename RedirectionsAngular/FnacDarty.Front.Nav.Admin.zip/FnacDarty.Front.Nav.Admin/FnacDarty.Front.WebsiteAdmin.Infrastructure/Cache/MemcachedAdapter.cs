using System;
using System.Collections.Generic;
using System.Runtime.Caching;
using System.Text.RegularExpressions;
using Newtonsoft.Json;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides an implementation based on Enyim memcache client.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The adapter serializes objects in JSON format using Newtonsoft.Json serializer,
    /// then stores the data using the text communication protocole. Benchmarks show there 
    /// is no noticeable differences compared to the EnyimMemcached client's default behavior
    /// which is based on SerializableAttribute.
    /// </para>
    /// <para>
    /// Caching data in JSON format allows better compatibility across applications written
    /// in different languages.
    /// </para>
    /// <para>
    /// To use this class, the client needs to reference the NuGet packages EnyimMemcached and Newtonsoft.Json.
    /// </para>
    /// </remarks>
    public class MemcachedAdapter : BaseCache, IDistributedCache
    {

        private static Regex PATTERN_HOST_PORT = new Regex(@"^[a-zA-Z0-9._-]+:[0-9]+$");

        private static JsonSerializerSettings DefaultSerializerSettings = new JsonSerializerSettings()
        {
            NullValueHandling = NullValueHandling.Ignore,
        };

        //private MemcachedClient InnerClient { get; set; }

        /// <summary>
        /// Initializes a new instance of MemcachedAdapter
        /// </summary>
        /// <param name="servers">A list of servers in the format host:port, e.g. 127.0.0.1:11211, localhost:11211</param>
        public MemcachedAdapter(params string[] servers)
        {
        }


        /// <inheritdoc cref="IDisposable.Dispose()" />
        public void Dispose()
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc cref="ICache.Contains(string)" />
        public bool Contains(string key)
        {
            throw new NotImplementedException("MemcachedAdapter does not support Contains() operation. Use Get() and check if the return value is null instead.");
        }

        /// <inheritdoc cref="ICache.Get{T}(string)" />
        public override T Get<T>(string key)
        {
            throw new NotImplementedException();
        }


        /// <inheritdoc cref="IDistributedCache.Get{T}(IEnumerable{string})" />
        public IDictionary<string, T> Get<T>(IEnumerable<string> keys)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc cref="IDistributedCache.Get{T}(CacheNamespace, IEnumerable{string})" />
        public IDictionary<string, T> Get<T>(CacheNamespace ns, IEnumerable<string> keys)
        {
            throw new NotImplementedException();
        }



        /// <inheritdoc cref="ICache.Set(string, object, CacheItemPolicy)" />
        public override void Set(string key, object value, CacheItemPolicy policy = null)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc cref="ICache.Remove(string)" />
        public override void Remove(string key)
        {
            throw new NotImplementedException();
        }

        /// <inheritdoc cref="ICache.Clear()" />
        public void Clear()
        {
            throw new NotImplementedException();
        }


    }
}
