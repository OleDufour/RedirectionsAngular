﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides the base methods for accessing the object cache.
    /// </summary>
    /// <remarks>
    /// While the System.Runtime.Caching namespace introduced in .NET Framework 4 provides
    /// caching utilities that satisfy most of application scenarios, it stills lacks some
    /// basic features such as caching namespace handling and cache purging.
    /// 
    /// The interface ILocalCache is meant to hide away rarely used methods of ObjectCache
    /// and add crucial ones it does not provide.
    /// </remarks>
    public interface ILocalCache : ICache
    {
        
    }
}
