using System;
using System.Runtime.Caching;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides a convenient way to instantiate caching systems from configuration.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The CacheFactory class relies on an implementation of IConfig to retrieve values from 
    /// configuration. See the following table for expected configuration values:
    /// </para>
    /// 
    /// <para>
    /// Required values for local cache :
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Cache.Local</term>
    ///         <description>MemoryCache | Null</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// 
    /// <para>
    /// Required values for distributed cache:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Cache.Distributed</term>
    ///         <description>Memcached | Null</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// <para>
    /// Additional values for MemoryCache:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Cache.MemoryCache.SingleInstance</term>
    ///         <description>A boolean value that indicates whether the adapter runs in the single instance mode. (default to false)</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// <para>
    /// Additional values for Memcached:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Cache.Memcached.ServerList</term>
    ///         <description>List of memcached servers, in the format 'server:port,server:port'</description>
    ///     </item>
    /// </list>
    /// </para>
    /// </remarks>
    public class CacheFactory
    {
        /// <summary>
        /// The default infinite cache policy. Items cached with this policy are not removable and have a sufficiently long time-to-live.
        /// </summary>
        public static CacheItemPolicy INFINITE_CACHE_POLICY = new CacheItemPolicy()
        {
            Priority = CacheItemPriority.NotRemovable,
            AbsoluteExpiration = DateTimeOffset.Now.AddYears(10), // ten year cache is long enough to be infinite, too high value will cause memcached to fail
        };


        private const string CACHE_TYPE_MEMORYCACHE = "MemoryCache";

        private const string CACHE_TYPE_MEMCACHED = "Memcached";




        public IConfig Configuration { get; set; }

        public ILogger Logger { get; set; }


        public CacheFactory(IConfig config)
        {
            Configuration = config;
        }

        public CacheFactory(IConfig config, ILogger logger)
        {
            Configuration = config;
            Logger = logger;
        }



        public ILocalCache CreateLocalCacheFromConfiguration()
        {
            var cfg_cache = Configuration.GetSettingValue("Cache.Local");

            switch (cfg_cache)
            {

                case CACHE_TYPE_MEMORYCACHE:
                    return CreateMemoryCacheFromConfiguration();

                default :
                    return new NullLocalCache();

            }
        }


        private ILocalCache CreateMemoryCacheFromConfiguration()
        {
            var single = Configuration.GetSettingValueOptional<bool>("Cache.MemoryCache.SingleInstance");

            return new MemoryCacheAdapter(single);
        }


        public IDistributedCache CreateDistributedCacheFromConfiguration()
        {
            var cfg_cache = Configuration.GetSettingValue("Cache.Distributed");

            switch (cfg_cache)
            {

                case CACHE_TYPE_MEMCACHED:
                    return CreateMemcachedFromConfiguration();

                default:
                    return new NullDistributedCache();

            }
        }






        private IDistributedCache CreateMemcachedFromConfiguration()
        {
            throw new NotImplementedException();
            //var cfg_servers = Configuration.GetSettingValue("Cache.Memcached.ServerList");

            //// register memcached logger if not null
            //if (Logger != null)
            //{
            //    var adapter_log = new EnyimCachingLogAdapter(Logger);
            //    var adapter_factory = new EnyimCachingLogFactoryAdapter(adapter_log);

            //    Enyim.Caching.LogManager.AssignFactory(adapter_factory);
            //}

            //return new MemcachedAdapter(cfg_servers.Split(','));
        }


    }
}
