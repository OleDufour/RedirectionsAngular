namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    public class CacheNamespace
    {
        internal CacheNamespace()
        {
        }
        public string Namespace { get; internal set; }

        public string Value { get; internal set; }

        public override string ToString()
        {
            return $"{Namespace}-{Value}";
        }
    }
}
