using System.Runtime.Caching;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    public abstract class NullCache 
    {

        public bool Contains(string key)
        {
            return false;
        }

        public T Get<T>(string key)
        {
            return default(T);
        }

        public void Set(string key, object value, CacheItemPolicy policy = null)
        {
        }

        public void Remove(string key)
        {
        }

        public void Clear()
        {
        }

        public T Get<T>(CacheNamespace ns, string key)
        {
            return default(T);
        }

        public void Set(CacheNamespace ns, string key, object value, CacheItemPolicy policy = null)
        {
        }

        public void Remove(CacheNamespace ns, string key)
        {
        }

        public CacheNamespace GetNamespace(string nskey)
        {
            return null;
        }

        public CacheNamespace GetNamespaceOrCreateIfNotExists(string nskey, CacheItemPolicy policy = null)
        {
            return null;
        }

        public CacheNamespace CreateNamespace(string nskey, CacheItemPolicy policy = null)
        {
            return null;
        }

        public void RemoveNamespace(string nskey)
        {
        }

        public void Dispose()
        {
        }
    }
}
