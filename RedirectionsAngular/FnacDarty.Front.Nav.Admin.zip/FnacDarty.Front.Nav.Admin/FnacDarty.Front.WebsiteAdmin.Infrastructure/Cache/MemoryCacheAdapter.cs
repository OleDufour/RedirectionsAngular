using System;
using System.Runtime.Caching;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides an implementation based on .NET's MemoryCache class.
    /// </summary>
    /// <remarks>
    /// The MSDN describes that the MemoryCache class does support multiple instances but
    /// cautions about their use. The single instance mode is preferred, especially if the
    /// client application running on IIS 8.5 (Windows Server 2012 R2) randomly hangs during 
    /// application pool recycling. 
    /// 
    /// See the caution section in the MemoryCache constructor page :
    /// https://msdn.microsoft.com/en-us/library/system.runtime.caching.memorycache.memorycache(v=vs.110).aspx
    /// 
    /// For information, when the MemoryCacheAdapter runs in the single instance mode, it
    /// does not create new MemoryCache instances. It relies instead on MemoryCache.Default
    /// property and the Clear method is disabled because the proper implementation is missing
    /// from .NET Framework class.
    /// </remarks>
    public class MemoryCacheAdapter : BaseCache, ILocalCache
    {
        private MemoryCache InnerCache { get; set; }

        private bool SingleInstanceMode { get; set; }

        /// <summary>
        /// Initializes a new instance of MemoryCacheAdapter
        /// </summary>
        public MemoryCacheAdapter() : this(false)
        {
        }

        /// <summary>
        /// Initializes a new instance of MemoryCacheAdapter in single mode or not.
        /// </summary>
        /// <param name="single">A value that indicates whether the adapter should run in the single instance mode.</param>
        public MemoryCacheAdapter(bool single)
        {
            SingleInstanceMode = single;

            InnerCache = single == true ? MemoryCache.Default : CreateInnerCache();
        }

        /// <inheritdoc cref="IDisposable.Dispose()" />
        public void Dispose()
        {
            if (InnerCache != null)
                InnerCache.Dispose();
        }


        /// <inheritdoc cref="ICache.Contains(string)" />
        public bool Contains(string key)
        {
            return InnerCache.Contains(key);
        }

        /// <inheritdoc cref="ICache.Get{T}(string)" />
        public override T Get<T>(string key)
        {
            var value = InnerCache.Get(key);

            if (value == null)
                return default(T);

            if (value is T)
                return (T)value;

            throw new Exception(string.Format("Unable to retrieve value from cache with key '{0}', the request type is {1} but the stored item type is {2}. This is most likely caused by development error.", key, typeof(T), value.GetType()));
        }

        /// <inheritdoc cref="ICache.Set(string, object, CacheItemPolicy)" />
        public override void Set(string key, object value, System.Runtime.Caching.CacheItemPolicy policy = null)
        {
            InnerCache.Set(key, value, policy ?? CacheFactory.INFINITE_CACHE_POLICY);
        }

        /// <inheritdoc cref="ICache.Remove(string)" />
        public override void Remove(string key)
        {
            InnerCache.Remove(key);
        }

        /// <inheritdoc cref="ICache.Clear()" />
        public void Clear()
        {
            if (SingleInstanceMode == true)
                throw new Exception("Clear method is not supported in single instance mode.");
            else
            {
                // MemoryCache does not support clear method, so replace the inner cache by a new instance
                var expired = InnerCache;
                
                InnerCache = CreateInnerCache();

                expired.Dispose();
            }
        }

        private MemoryCache CreateInnerCache()
        {
            var name = string.Format("MemoryCache-{0:yyyyMMdd-hh:mm:ss}", DateTime.Now);

            return new MemoryCache(name);
        }


    }
}
