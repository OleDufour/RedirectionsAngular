﻿using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides the base methods for accessing the distributed object cache.
    /// </summary>
    /// <remarks>
    /// Distributed cache systems provide more scalability than local cache systems (usually in-memory)
    /// and eliminate the synchronization problem across multiple cache stores. In scenarios where
    /// network latency is acceptable, applications should prefer distributed cache to its local counterpart.
    /// </remarks>
    public interface IDistributedCache : ICache
    {
        /// <summary>
        /// Retrieves a list of items from cache using multiple keys.
        /// </summary>
        /// <param name="keys">The specified list of cache keys.</param>
        /// <returns>A dictionary holding all items indexed by their cache keys. ContainsKey(key) will return false if cache miss.</returns>
        IDictionary<string, T> Get<T>(IEnumerable<string> keys);

        /// <summary>
        /// Retrieves a list of items from cache using namespace and multiple keys.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ns"></param>
        /// <param name="keys"></param>
        /// <returns></returns>
        IDictionary<string, T> Get<T>(CacheNamespace ns, IEnumerable<string> keys);   

    }
}
