namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides neutral "null" cache behaviors for testing purpose.
    /// </summary>
    /// <remarks>
    /// It is not recommended to disable cache by using the NullCache class 
    /// because client applications may implement specific behaviors according to 
    /// cache existence or retrieved value. However, the Contains() method will 
    /// always return false and the Get() method will always return default value.
    /// </remarks>
    public class NullLocalCache : NullCache, ILocalCache
    {
    }
}
