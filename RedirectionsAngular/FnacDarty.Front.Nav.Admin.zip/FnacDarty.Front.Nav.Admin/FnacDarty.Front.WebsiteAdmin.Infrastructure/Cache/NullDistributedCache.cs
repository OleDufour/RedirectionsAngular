﻿using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides neutral "null" cache behaviors for testing purpose.
    /// </summary>
    /// <remarks>
    /// It is not recommended to disable cache by using the NullCache class 
    /// because client applications may implement specific behaviors according to 
    /// cache existence or retrieved value. However, the Contains() method will 
    /// always return false and the Get() method will always return default value.
    /// </remarks>
    public class NullDistributedCache : NullCache, IDistributedCache
    {
        public IDictionary<string, T> Get<T>(IEnumerable<string> keys)
        {
            return null;
        }

        public IDictionary<string, T> Get<T>(CacheNamespace ns, IEnumerable<string> keys)
        {
            return null;
        }
    }
}
