using System;
using System.Runtime.Caching;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache
{
    /// <summary>
    /// Provides the base methods for accessing a generic cache.
    /// </summary>
    /// <remarks>
    /// In most cases, local cache and distributed cache are not interchangeable without compromising
    /// the intended application behavior. It is recommended to always use the inherited interfaces
    /// ILocalCache and IDistributedCache for better distinction.
    /// </remarks>
    public interface ICache : IDisposable
    {
        /// <summary>
        /// Determines whether a cache entry exists in the cache.
        /// </summary>
        /// <param name="key">A unique identifier for the cache entry to search for.</param>
        /// <returns></returns>
        bool Contains(string key);

        /// <summary>
        /// Returns an entry from the cache. 
        /// </summary>
        /// <remarks>
        /// Cache implementors should return default value of the requested type if no value 
        /// is found for the specific key.
        /// </remarks>
        /// <typeparam name="T">The specified type of the cached object</typeparam>
        /// <param name="key">A unique identifier for the cache entry to search for.</param>
        /// <returns>A reference to the cache entry that is identified by key, if the entry exists; otherwise, null.</returns>
        T Get<T>(string key);

      

        /// <summary>
        /// Inserts an entry into the cache using a key, a value and eviction.
        /// </summary>
        /// <param name="key">A unique identifier for the cache entry to insert.</param>
        /// <param name="value">The data for the cache entry.</param>
        /// <param name="policy">An object that contains eviction details for the cache entry. Default to no cache expiration time.</param>
        void Set(string key, object value, CacheItemPolicy policy = null);


        /// <summary>
        /// Removes a cache entry from the cache. 
        /// </summary>
        /// <param name="key">A unique identifier for the cache entry to remove. </param>
        void Remove(string key);


        /// <summary>
        /// Removes all cache entries from the cache.
        /// </summary>
        void Clear();


        /// <summary>
        /// Returns an entry from the cache.
        /// </summary>
        /// <typeparam name="T">The specified type of the cached object.</typeparam>
        /// <param name="ns">The specified namespace the object resides in.</param>
        /// <param name="key">A unique identifier for the cache entry</param>
        /// <returns>A reference to the cache entry that is identified by namespace and key. Null if not exist.</returns>
        T Get<T>(CacheNamespace ns, string key);

        /// <summary>
        /// Inserts an entry into the cache using a namespace, a key, a value and eviction.
        /// </summary>
        /// <param name="ns">The specified namespace  the cached object.</param>
        /// <param name="key">A unique identifier for the cache entry to insert.</param>
        /// <param name="value">The data for the cache entry.</param>
        /// <param name="policy">An object that contains eviction details for the cache entry. Default to no cache expiration time.</param>
        void Set(CacheNamespace ns, string key, object value, CacheItemPolicy policy = null);

        /// <summary>
        /// Removes a cache entry from the cache using namespace and key.
        /// </summary>
        /// <param name="ns">The specified namespace of the object resides in.</param>
        /// <param name="key">A unique identifier for the cache entry.</param>
        void Remove(CacheNamespace ns, string key);

        /// <summary>
        /// Returns a namespace used to group cache entries.
        /// </summary>
        /// <param name="nskey">A unique identifier for the cache namespace</param>
        /// <returns>A reference to the cache namespace that is identified by key. Null if not exist.</returns>
        CacheNamespace GetNamespace(string nskey);

        /// <summary>
        /// Returns a namespace used to group cache entries, or creates a new namespace if not exist.
        /// </summary>
        /// <param name="nskey">A unique identifier for the cache namespace</param>
        /// <param name="policy">An object that contains eviction details for the cache namespace. Default to no cache expiration time.</param>
        /// <returns>A reference to the cache namespace that is identified by key or a newly created one.</returns>
        CacheNamespace GetNamespaceOrCreateIfNotExists(string nskey, CacheItemPolicy policy = null);

        /// <summary>
        /// Creates a new namespace used to group cache entries.
        /// </summary>
        /// <param name="nskey">A unique identifier for the cache namespace</param>
        /// <param name="policy">An object that contains eviction details for the cache namespace. Default to no cache expiration time.</param>
        /// <returns>A newly created namespace.</returns>
        CacheNamespace CreateNamespace(string nskey, CacheItemPolicy policy = null);

        /// <summary>
        /// Removes a namespace used to group cache entries. All entries that reside in this namespace will not be removed but will be no longer accessible due to the namespace removal.
        /// </summary>
        /// <param name="nskey">A unique identifier for the cache namespace.</param>
        void RemoveNamespace(string nskey);


    }
}
