﻿using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure
{
    public abstract class ModuleRegistrationBase
    {
        public virtual IServiceCollection RegisterServices(IServiceCollection services)
        {
            return services;
        }

        public virtual AuthorizationOptions RegisterAuthorizations(AuthorizationOptions authorizationOptions)
        {
            return authorizationOptions;
        }

        public virtual IRouteBuilder MapRoutes(IRouteBuilder routes)
        {
            return routes;
        }

        public virtual IDynamicMenuBuilder RegisterMenu(IDynamicMenuBuilder menuBuilder)
        {
            return menuBuilder;
        }
    }
}
