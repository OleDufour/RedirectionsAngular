using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl
{
    public class AccessControlDomainResolver : IAccessControlDomainResolver
    {
        public static IAccessControlDomainResolver Current { get; private set; }

        public static void SetResolver(IAccessControlDomainResolver resolver)
        {
            Current = resolver;
        }

        public static void SetResolver(Func<string> resolver)
        {
            Current = new AccessControlDomainResolver(resolver);
        }
        


        private Func<string> Resolver { get; set; }


        public AccessControlDomainResolver(string domain)
        {
            Resolver = () => domain;
        }

        public AccessControlDomainResolver(Func<string> resolver)
        {
            Resolver = resolver;
        }

        public string GetDefaultDomain()
        {
            return Resolver();
        }

    }
}
