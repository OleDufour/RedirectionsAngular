using FnacDarty.Front.WebsiteAdmin.Constant;
using Microsoft.AspNetCore.Authorization;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl
{
    public class AuthorizedUserRequirement : IAuthorizationRequirement
    {
        public EnumUserRole[] Roles;
        public bool AdminRequired;

        public AuthorizedUserRequirement(bool adminRequired, EnumUserRole[] roles)
        {
            Roles = roles;
            AdminRequired = adminRequired;
        }
    }
}
