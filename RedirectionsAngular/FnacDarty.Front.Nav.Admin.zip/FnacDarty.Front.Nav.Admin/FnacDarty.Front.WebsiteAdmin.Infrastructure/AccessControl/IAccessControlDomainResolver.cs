﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl
{
    public interface IAccessControlDomainResolver
    {
        string GetDefaultDomain();
    }
}
