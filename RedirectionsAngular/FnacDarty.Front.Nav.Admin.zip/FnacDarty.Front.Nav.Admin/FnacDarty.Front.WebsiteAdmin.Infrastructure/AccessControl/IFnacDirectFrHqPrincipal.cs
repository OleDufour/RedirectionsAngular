﻿using System;
using System.Collections.Generic;
using System.Security.Principal;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl
{
    public interface IFnacDirectFrHqPrincipal : IPrincipal
    {
        Guid UserId { get; set; }
        string Login { get; set; }
        bool IsAdmin { get; set; }
        bool HaveAccess { get; set; }
        string Language { get; }
        List<UserRole> Roles { get; set; }
        void SetLanguage(string lang);
    }

    public class UserRole
    {
        public int RoleId { get; set; }
        public string RoleName { get; set; }
    }
}
