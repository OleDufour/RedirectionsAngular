namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl
{
    public interface IAccessControl
    {
        IFnacDirectFrHqPrincipal GetCurrentUser();
    }
}
