
using Microsoft.AspNetCore.Mvc.Filters;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Provides an action filter that monitors MVC execution time.
    /// </summary>
    /// <example>
    /// <code>
    /// var factory = ServiceLocator.Current.GetInstance{IPerfmonFactory}();
    /// var attr = new PerfmonFilterAttribute(factory);
    /// 
    /// filters.Add(attr); // filters is of GlobalFilterCollection type, usually found in FilterConfig
    /// </code>
    /// </example>
    public class PerfmonFilterAttribute : ActionFilterAttribute
    {
        private const string PERFMON_CATEGORY_MVC = "MVC";

        private IPerfmonFactory Factory { get; set; }

        public PerfmonFilterAttribute(IPerfmonFactory factory)
        {
            Factory = factory;
        }


        /// <summary>
        /// Called when [action executing].
        /// </summary>
        /// <param name="context">The context.</param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            Factory.GetCurrentPerfmon().BeginTrack(PERFMON_CATEGORY_MVC);
            base.OnActionExecuting(context);
        }

        /// <summary>
        /// Called when [action executed].
        /// </summary>
        /// <param name="context">The context.</param>
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            Factory.GetCurrentPerfmon().EndTrack(PERFMON_CATEGORY_MVC);
            base.OnActionExecuted(context);
        }
    }
}
