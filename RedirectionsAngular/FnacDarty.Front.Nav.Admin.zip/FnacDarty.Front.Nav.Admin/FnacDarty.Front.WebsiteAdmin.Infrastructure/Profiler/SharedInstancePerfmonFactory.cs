﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    public class SharedInstancePerfmonFactory : BasePerfmonFactory
    {
        private IPerfmon PerfmonInstance { get; set; }


        public SharedInstancePerfmonFactory()
        {
        }

        /// <inheritdoc cref="IPerfmonFactory.GetCurrentPerfmon()" />
        public override IPerfmon GetCurrentPerfmon()
        {
            if (PerfmonInstance == null)
            {
                PerfmonInstance = new RuntimePerfmon()
                {
                    Verbosity = Verbosity,
                    SlowestCount = SlowestCount,
                };
            }

            return PerfmonInstance;
        }
    }
}
