﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Provides performance tracking functionality using HttpContext as back-end storage.
    /// </summary>
    public class RuntimePerfmon : IPerfmon
    {

        // <summary>
        // severity => duration in millisecond
        // </summary>
        //private static Dictionary<int, int> SeverityTable = new Dictionary<int, int>();

        /// <inheritdoc cref="IPerfmon.Verbosity" />
        /// <remarks>
        /// Verbosity value list :
        /// <list type="table">
        ///     <listheader>
        ///         <term>Level</term>
        ///         <description>Description</description>
        ///     </listheader>
        ///     <item>
        ///         <term>0</term>
        ///         <description>No output</description>
        ///     </item>
        ///     <item>
        ///         <term>1</term>
        ///         <description>Shows only total durations of each tracking category</description>
        ///     </item>
        ///     <item>
        ///         <term>2</term>
        ///         <description>Shows total durations of each tracking category and the slowest executions</description>
        ///     </item>
        ///     <item>
        ///         <term>3</term>
        ///         <description>Shows total durations of each tracking category and all execution details</description>
        ///     </item>
        /// </list>
        /// </remarks>
        public int Verbosity { get; set; }


        /// <summary>
        /// Gets or sets the number of the slowest tracked sessions.
        /// </summary>
        /// <remarks>
        /// 
        /// </remarks>
        public int SlowestCount { get; set; }


        private Dictionary<string, Stopwatch> CurrentExecutionList { get; set; }

        private Dictionary<string, List<PerfmonExecutionEntity>> SavedExecutionList { get; set; }



        public RuntimePerfmon()
        {
            CurrentExecutionList = new Dictionary<string, Stopwatch>();
            SavedExecutionList = new Dictionary<string, List<PerfmonExecutionEntity>>();
        }


        /// <inheritdoc cref="IPerfmon.GetResults()" />
        public IEnumerable<PerfmonResultEntity> GetResults()
        {
            var results = new List<PerfmonResultEntity>();

            foreach (var pair in SavedExecutionList)
            {
                var entries = new List<PerfmonExecutionEntity>();
                var total = TimeSpan.FromTicks(0);

                switch (Verbosity)
                {
                    case PerfmonVerbosity.VERBOSE:
                        entries.AddRange(pair.Value.OrderByDescending(e => e.Duration).Take(SlowestCount));
                        break;

                    case PerfmonVerbosity.VERY_VERBOSE:
                        entries.AddRange(pair.Value.OrderByDescending(e => e.Duration));
                        break;

                }

                foreach (var item in pair.Value)
                    total += item.Duration;


                var result = new PerfmonResultEntity()
                {
                    Key = pair.Key,
                    EntryList = entries,
                    TotalDuration = total,
                };

                results.Add(result);
            }

            return results;
        }


        /// <inheritdoc cref="IPerfmon.BeginTrack(PerfmonCategory)" />
        public void BeginTrack(PerfmonCategory category = PerfmonCategory.Uncategorized)
        {
            BeginTrack(category.ToString());
        }

        /// <inheritdoc cref="IPerfmon.BeginTrack(string)" />
        public void BeginTrack(string category)
        {
            BeginTrackExecution(category);
        }

        /// <inheritdoc cref="IPerfmon.EndTrack(PerfmonCategory, string)" />
        public void EndTrack(PerfmonCategory category = PerfmonCategory.Uncategorized, [CallerMemberName] string caller = null)
        {
            EndTrack(category.ToString(), caller);
        }

        /// <inheritdoc cref="IPerfmon.EndTrack(string, string)" />
        public void EndTrack(string category, [CallerMemberName] string caller = null)
        {
            var entry = new PerfmonExecutionEntity()
            {
                Category = category,
                Method = caller,
            };

            EndTrackExecution(entry);
        }

        /// <inheritdoc cref="IPerfmon.AddEntry(string, TimeSpan, string)" />
        public void AddEntry(string category, TimeSpan duration, [CallerMemberName] string caller = null)
        {
            var entry = new PerfmonExecutionEntity()
            {
                Category = category,
                Method = caller,
                Duration = duration
            };

            AddMonitorExecution(entry);
        }

        /// <inheritdoc cref="IPerfmon.Track(Action, PerfmonCategory, string)" />
        public void Track(Action action, PerfmonCategory category = PerfmonCategory.Uncategorized, [CallerMemberName] string caller = null)
        {
            Track(action, category.ToString(), caller);
        }

        /// <inheritdoc cref="IPerfmon.Track{T}(Func{T}, PerfmonCategory, string)" />
        public T Track<T>(Func<T> func, PerfmonCategory category = PerfmonCategory.Uncategorized, [CallerMemberName] string caller = null)
        {
            return Track<T>(func, category.ToString(), caller);
        }

        /// <inheritdoc cref="IPerfmon.Track(Action, string, string)" />
        public void Track(Action action, string category, [CallerMemberName] string caller = null)
        {
            BeginTrack(category);

            action();

            EndTrack(category, caller);
        }

        /// <inheritdoc cref="IPerfmon.Track{T}(Func{T}, string, string)" />
        public T Track<T>(Func<T> func, string category, [CallerMemberName] string caller = null)
        {
            BeginTrack(category);

            var rtn = func();

            EndTrack(category, caller);

            return rtn;
        }









        private void BeginTrackExecution(string type)
        {
            var sw = new Stopwatch();

            sw.Start();

            CurrentExecutionList[type] = sw;
        }

        private void EndTrackExecution(PerfmonExecutionEntity entry)
        {
            var sw = CurrentExecutionList[entry.Category] as Stopwatch;

            if (sw == null)
                throw new Exception(String.Format("Unable to end performance monitor execution, not started for {0}", entry.Category));

            sw.Stop();

            entry.Duration = sw.Elapsed;

            AddMonitorExecution(entry);

        }

        private void AddMonitorExecution(PerfmonExecutionEntity entry)
        {
            CurrentExecutionList.Remove(entry.Category);

            // save the entry
            if (SavedExecutionList.ContainsKey(entry.Category) == false)
                SavedExecutionList[entry.Category] = new List<PerfmonExecutionEntity>();

            SavedExecutionList[entry.Category].Add(entry);
        }

        private int GetSeverity(Dictionary<int, int> table, double duration)
        {
            foreach (var pair in table)
            {
                if (duration > pair.Value)
                    return pair.Key;
            }

            return 0;
        }
    }
}
