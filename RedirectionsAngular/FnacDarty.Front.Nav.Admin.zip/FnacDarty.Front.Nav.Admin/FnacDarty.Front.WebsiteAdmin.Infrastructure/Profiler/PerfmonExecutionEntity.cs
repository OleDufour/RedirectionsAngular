﻿using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Defines a data structure for storing performance detail of an execution.
    /// </summary>
    public class PerfmonExecutionEntity
    {
        public TimeSpan Duration { get; set; }
        public string Category { get; set; }
        public string Method { get; set; }
        public int Severity { get; set; }
    }
}
