﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    public abstract class BasePerfmonFactory : IPerfmonFactory
    {

        public int Verbosity { get; set; }

        public int SlowestCount { get; set; }

        protected BasePerfmonFactory()
        {
            Verbosity = PerfmonVerbosity.VERY_VERBOSE;
            SlowestCount = PerfmonFactory.DEFAULT_SLOWEST_COUNT;
        }

        /// <inheritdoc cref="IPerfmonFactory.GetCurrentPerfmon()" />
        public abstract IPerfmon GetCurrentPerfmon();
    }
}
