﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Provides a data structure to store current and saved execution details.
    /// </summary>
    public enum PerfmonCategory
    {
        Uncategorized,
        Sql,
        NoSql,
        WebService,
        Logic,
        LocalCache,
        DistributedCache,
        Rendering,
    }
}
