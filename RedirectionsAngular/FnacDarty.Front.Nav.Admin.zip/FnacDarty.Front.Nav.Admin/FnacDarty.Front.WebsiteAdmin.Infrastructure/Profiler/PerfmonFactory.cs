using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using Microsoft.AspNetCore.Http;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Provides a convenient way to instantiate performance monitor factory from configuration.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The PerfmonFactory class relies on an implementation of IConfig to retrieve values from 
    /// configuration. This is the recommended way to instantiate perfmon instances.
    /// </para>
    /// <para>
    /// The httpcontext-bound factory is intended to be used in websites where HttpContext.Current
    /// is not null. The shared instance is designed for tracking an application in a single execution
    /// (scheduled tasks or short-lived console applications for example).
    /// </para>
    /// <para>
    /// See the following table for expected configuration values:
    /// </para>
    /// 
    /// <para>
    /// Required commons values for all performance monitors:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Perfmon</term>
    ///         <description>HttpContext | SharedInstance | Null</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// <para>
    /// Additional required values for HtteContext-bound performance monitor:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Perfmon.Verbosity</term>
    ///         <description>An integer value indicating how verbose the result output is to be.</description>
    ///     </item>
    ///     <item>
    ///         <term>Perfmon.SlowestCount</term>
    ///         <description>An integer value indicating how many the slowest sessions to be shown in the result output.</description>
    ///     </item>
    ///     <item>
    ///         <term>Perfmon.Enabled</term>
    ///         <description>
    ///               A boolean value indicating whether the monitor is enabled by default. 
    ///               (this behavior can be overriden by the parameter perfmon=[true|false] in the query string).
    ///         </description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// <para>
    /// Additional required values for shared instance performance monitor:
    /// <list type="table">
    ///     <listheader>
    ///         <term>Key</term>
    ///         <description>Value</description>
    ///     </listheader>
    ///     <item>
    ///         <term>Perfmon.Verbosity</term>
    ///         <description>An integer value indicating how verbose the result output is to be.</description>
    ///     </item>
    ///     <item>
    ///         <term>Perfmon.SlowestCount</term>
    ///         <description>An integer value indicating how many the slowest sessions to be shown in the result output.</description>
    ///     </item>
    /// </list>
    /// </para>
    /// 
    /// </remarks>
    public class PerfmonFactory
    {
        private const string PERFMON_FACTORY_TYPE_HTTP_CONTEXT = "HttpContext";
        private const string PERFMON_FACTORY_TYPE_SHARED_INSTANCE = "SharedInstance";
        public const int DEFAULT_SLOWEST_COUNT = 5;

        public IHttpContextAccessor HttpContextAccessor { get; set; }
        public IConfig Configuration { get; set; }


        public PerfmonFactory(IConfig config, IHttpContextAccessor httpContextAccessor)
        {
            Configuration = config;
            HttpContextAccessor= httpContextAccessor;
        }



        public IPerfmonFactory CreatePerfmonFromConfiguration()
        {

            var perfmon = Configuration.GetSettingValueOptional("Perfmon");


            var verbosity = Configuration.GetSettingValueOptional<int>("Perfmon.Verbosity");
            var slowest = Configuration.GetSettingValueOptional<int>("Perfmon.SlowestCount");

            if (verbosity <= 0)
                verbosity = PerfmonVerbosity.VERY_VERBOSE;

            if (slowest <= 0)
                slowest = DEFAULT_SLOWEST_COUNT;

            switch (perfmon)
            {

                case PERFMON_FACTORY_TYPE_HTTP_CONTEXT:
                    return CreateHttpContextPerfmonFromConfiguration(verbosity, slowest);

                case PERFMON_FACTORY_TYPE_SHARED_INSTANCE:
                    return CreateSharedInstancePerfmonFromConfiguration(verbosity, slowest);

                default:
                    return new NullPerfmonFactory();

            }

        }

        private IPerfmonFactory CreateSharedInstancePerfmonFromConfiguration(int verbosity, int slowest)
        {

            var perfmon = new SharedInstancePerfmonFactory()
            {
                Verbosity = verbosity,
                SlowestCount = slowest,
            };

            return perfmon;
        }

        private IPerfmonFactory CreateHttpContextPerfmonFromConfiguration(int verbosity, int slowest)
        {
            var enabled = Configuration.GetSettingValueOptional<bool>("Perfmon.Enabled");

            var perfmon = new HttpContextBoundPerfmonFactory(HttpContextAccessor)
            {
                Verbosity = verbosity,
                SlowestCount = slowest,
                IsEnabled = enabled,
            };
            return perfmon;
        }




    }
}
