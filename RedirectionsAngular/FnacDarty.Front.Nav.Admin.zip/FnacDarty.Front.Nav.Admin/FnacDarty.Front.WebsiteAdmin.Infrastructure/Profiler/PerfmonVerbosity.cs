﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    public class PerfmonVerbosity
    {
        /// <summary>
        /// Shows only aggregated results without tracked session details
        /// </summary>
        public const int MINIMAL = 1;

        /// <summary>
        /// Shows aggregated results and the slowest session details
        /// </summary>
        public const int VERBOSE = 2;

        /// <summary>
        /// Shows aggregated results and all session details
        /// </summary>
        public const int VERY_VERBOSE = 3;
    }
}
