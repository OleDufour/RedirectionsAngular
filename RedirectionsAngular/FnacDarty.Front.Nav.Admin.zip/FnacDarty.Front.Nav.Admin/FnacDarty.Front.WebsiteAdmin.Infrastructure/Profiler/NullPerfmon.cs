﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Provides a "null" implementation of IPerformanceMonitor that can be used to disable completely performance tracking.
    /// </summary>
    public class NullPerfmon : IPerfmon
    {
        public static NullPerfmon SINGELTON_INSTANCE = new NullPerfmon();

        /// <inheritdoc cref="IPerfmon.Verbosity" />
        public int Verbosity
        {
            get { return 0; }
        }

        /// <inheritdoc cref="IPerfmon.GetResults()" />
        public IEnumerable<PerfmonResultEntity> GetResults()
        {
            return Enumerable.Empty<PerfmonResultEntity>();
        }



        public void BeginTrack(PerfmonCategory category = PerfmonCategory.Uncategorized)
        {
        }

        public void BeginTrack(string category)
        {
        }

        public void EndTrack(PerfmonCategory category = PerfmonCategory.Uncategorized, [CallerMemberName] string caller = null)
        {
        }

        public void EndTrack(string category, [CallerMemberName] string caller = null)
        {
        }

        public void AddEntry(string category, TimeSpan duration, string caller = null)
        {
        }

        public void Track(Action action, PerfmonCategory category = PerfmonCategory.Uncategorized, [CallerMemberName] string caller = null)
        {
            if (action != null)
                action();
        }

        public T Track<T>(Func<T> func, PerfmonCategory category = PerfmonCategory.Uncategorized, [CallerMemberName] string caller = null)
        {
            return func != null ? func() : default(T);
        }

        public void Track(Action action, string category, [CallerMemberName] string caller = null)
        {
            if (action != null)
                action();
        }

        public T Track<T>(Func<T> func, string category, [CallerMemberName] string caller = null)
        {
            return func != null ? func() : default(T);
        }
    }
}
