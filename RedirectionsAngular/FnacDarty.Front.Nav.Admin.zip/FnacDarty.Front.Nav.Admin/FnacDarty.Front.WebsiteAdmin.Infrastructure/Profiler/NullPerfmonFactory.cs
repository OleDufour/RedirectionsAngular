﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Provides a "null" implementation of IPerfmonFactory that can be used to disable completely performance tracking.
    /// </summary>
    public class NullPerfmonFactory : IPerfmonFactory
    {
        public IPerfmon GetCurrentPerfmon()
        {
            return NullPerfmon.SINGELTON_INSTANCE;
        }
    }
}
