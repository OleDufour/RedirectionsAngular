using Microsoft.AspNetCore.Http;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    public class HttpContextBoundPerfmonFactory : BasePerfmonFactory
    {
        public IHttpContextAccessor HttpContextAccessor { get; set; }

        public HttpContextBoundPerfmonFactory(IHttpContextAccessor httpContextAccessor)
        {
            HttpContextAccessor = httpContextAccessor;
            ParameterName = DEFAULT_PARAMETER_NAME;
            IsEnabled = false;
        }

        private const string DEFAULT_PARAMETER_NAME = "perfmon";


        public bool IsEnabled { get; set; }

        public string ParameterName { get; set; }

        public HttpContextBoundPerfmonFactory()
        {
            ParameterName = DEFAULT_PARAMETER_NAME;
            IsEnabled = false;
        }

        /// <inheritdoc cref="IPerfmonFactory.GetCurrentPerfmon()" />
        public override IPerfmon GetCurrentPerfmon()
        {
            if (HttpContextAccessor?.HttpContext?.Items == null)
                return NullPerfmon.SINGELTON_INSTANCE; // gracefully handle the case where the HttpContext might be null (during application boot)

            var type = GetType().FullName;

            if (!(HttpContextAccessor.HttpContext.Items[type] is IPerfmon perfmon))
            {
                if (IsEnabledWithOverride() == true)
                    perfmon = new RuntimePerfmon()
                    {
                        Verbosity = Verbosity,
                        SlowestCount = SlowestCount,
                    };
                else
                    perfmon = NullPerfmon.SINGELTON_INSTANCE;

                HttpContextAccessor.HttpContext.Items[type] = perfmon;
            }

            return perfmon;
        }

        private bool IsEnabledWithOverride()
        {
            if (HttpContextAccessor?.HttpContext?.Items == null)
                return false; // gracefully handle the case where the HttpContext might be null (during application boot)

            var request = HttpContextAccessor.HttpContext.Request;

            if (request?.Query == null)
                return false;

            var p = request.Query[ParameterName];

            if (string.IsNullOrWhiteSpace(p))
                return IsEnabled;

            if (!bool.TryParse(p, out var b))
                return IsEnabled;

            return b;
        }
    }
}
