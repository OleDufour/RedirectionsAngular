﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{

    /// <summary>
    /// Provides functionality to create IPerfmon instance.
    /// </summary>
    public interface IPerfmonFactory
    {
        IPerfmon GetCurrentPerfmon();
    }
}
