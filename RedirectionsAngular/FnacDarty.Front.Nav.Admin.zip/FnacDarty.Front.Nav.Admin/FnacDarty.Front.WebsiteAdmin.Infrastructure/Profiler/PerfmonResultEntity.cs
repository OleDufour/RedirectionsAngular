﻿using System;
using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler
{
    /// <summary>
    /// Defines a data structure of the performance tracking result.
    /// </summary>
    public class PerfmonResultEntity
    {
        public string Key { get; set; }

        public TimeSpan TotalDuration { get; set; }

        public IEnumerable<PerfmonExecutionEntity> EntryList { get; set; }
    }
}
