using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper
{
    public interface IDtoModelMapper<TD,TV>
    {
        TV DtoToModel(TD dto);
        TD ModelToDto(TV viewModel);
        IEnumerable<TV> DtosToModels(IEnumerable<TD> dtos);
    }
}
