using System.Collections.Generic;
using System.Linq;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper
{
    public abstract class DtoModelMapperBase<TD,TV> : IDtoModelMapper<TD,TV>
    {
        public abstract TV DtoToModel(TD dto);

        public abstract TD ModelToDto(TV model);

        public IEnumerable<TV> DtosToModels(IEnumerable<TD> dtos)
        {
            return dtos.Select(DtoToModel).ToList();
        }
    }
}
