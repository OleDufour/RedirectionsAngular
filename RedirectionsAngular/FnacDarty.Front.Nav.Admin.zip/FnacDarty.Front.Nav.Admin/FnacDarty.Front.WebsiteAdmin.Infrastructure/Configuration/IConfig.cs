using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    /// <summary>
    /// Provides a common abstraction for reading configuration in various environments.
    /// </summary>
    public interface IConfig
    {
        /// <summary>
        /// Check if key exists
        /// </summary>
        /// <param name="name">A Boolean that indicates if key exists</param>
        /// <returns></returns>
        bool IsKeyExists(string name);

        /// <summary>
        /// Retrieves the value of a required configuration setting.
        /// </summary>
        /// <exception cref="System.Configuration.ConfigurationErrorsException" />
        /// <param name="name">The name of the configuration setting.</param>
        /// <returns>A String that contains the value of the configuration setting.</returns>
        string GetSettingValue(string name);

        /// <summary>
        /// Retrieves the value of an optional configuration setting.
        /// </summary>
        /// <param name="name">The name of the configuration setting.</param>
        /// <returns>A String that contains the value of the configuration setting, null if the setting is missing.</returns>
        string GetSettingValueOptional(string name);

        /// <summary>
        /// Retrieves and converts the value of a required configuration setting to the desired type.
        /// </summary>
        /// <exception cref="System.Configuration.ConfigurationErrorsException" />
        /// <typeparam name="T">The desired type that the value should be converted to</typeparam>
        /// <param name="name">The name of the configuration setting.</param>
        /// <returns>A String that contains the value of the configuration setting.</returns>
        T GetSettingValue<T>(string name);

        /// <summary>
        /// Retrieves and converts the value of an optional configuration setting to the desired type.
        /// </summary>
        /// <typeparam name="T">The desired type that the value should be converted to</typeparam>
        /// <param name="name">The name of the configuration setting.</param>
        /// <returns>A String that contains the value of the configuration setting, default value of the type if the setting is missing.</returns>
        T GetSettingValueOptional<T>(string name);

        List<string> GetArrayValue(string name);

        /// <summary>
        /// Refreshes local cache that a logger implementation may have created.
        /// </summary>
        void Refresh();
    }
}
