﻿using System.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    /// <summary>
    /// Provides an adapter implementation for System.Configuration.ConfigurationManager class.
    /// </summary>
    public class ConfigurationManagerAdapter : BaseConfig
    {
        /// <inheritdoc cref="IConfig.Refresh()" />
        public override void Refresh()
        {
        }

        public override bool IsKeyExists(string name)
        {
            var s = ConfigurationManager.AppSettings[name];
            return !string.IsNullOrWhiteSpace(s);
        }

        protected override string GetSettingValueInternal(string name)
        {
            return ConfigurationManager.AppSettings[name];
        }
    }
}
