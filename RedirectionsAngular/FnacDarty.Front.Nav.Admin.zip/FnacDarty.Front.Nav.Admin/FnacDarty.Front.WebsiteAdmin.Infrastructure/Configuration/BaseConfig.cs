using System;
using System.Collections.Generic;
using System.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    public abstract class BaseConfig : IConfig
    {
        public abstract bool IsKeyExists(string name);

        /// <inheritdoc cref="IConfig.GetSettingValue(string)" />
        public string GetSettingValue(string name)
        {
            var value = GetSettingValueInternal(name);

            if (string.IsNullOrWhiteSpace(value) == true)
                throw new ConfigurationErrorsException(string.Format("The configuration key {0} was not found in {1}.", name, GetType().Name));

            return value;
        }

        /// <inheritdoc cref="IConfig.GetSettingValueOptional(string)" />
        public string GetSettingValueOptional(string name)
        {
            var value = GetSettingValueInternal(name);

            if (string.IsNullOrWhiteSpace(value) == true)
                return null;

            return value;
        }


        /// <inheritdoc cref="IConfig.GetSettingValue{T}(string)" />
        public T GetSettingValue<T>(string name)
        {
            var value = GetSettingValue(name);
            var type = typeof(T);

            return ChangeType<T>(value, name);
        }

        /// <inheritdoc cref="IConfig.GetSettingValueOptional{T}(string)" />
        public T GetSettingValueOptional<T>(string name)
        {
            var value = GetSettingValueOptional(name);
            var type = typeof(T);

            if (value == null)
                return default(T);

            return ChangeType<T>(value, name);
        }

        public abstract void Refresh();

        protected T ChangeType<T>(string value, string name)
        {
            var type = typeof(T);
            try
            {
                if (type.IsGenericType == true && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type); // value cannot be null here actually

                if (type.IsEnum == true)
                    return (T)Enum.Parse(type, value, true);

                return (T)Convert.ChangeType(value, type);
            }
            catch (FormatException)
            {
                throw new ConfigurationErrorsException(string.Format("The configuration value cannot be converted to the expected type {0} in {1}. key={2}, value={3}", type.Name, GetType().Name, name, value));
            }
        }


        protected abstract string GetSettingValueInternal(string name);

        public List<string> GetArrayValue(string name)
        {
            throw new NotImplementedException();
        }
    }
}
