﻿using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    /// <summary>
    /// Provides a dictionary based configuration storage, mainly for testing purpose.
    /// </summary>
    public class KeyValueConfig : BaseConfig
    {
        private Dictionary<string, string> BackEnd { get; set; }

        public KeyValueConfig()
        {
            BackEnd = new Dictionary<string, string>();
        }

        public override bool IsKeyExists(string name)
        {
            return BackEnd.ContainsKey(name);
        }

        public void SetSettingValue(string name, string value)
        {
            BackEnd[name] = value;
        }

        /// <inheritdoc cref="IConfig.Refresh()" />
        public override void Refresh()
        {
        }

        protected override string GetSettingValueInternal(string name)
        {
            if (BackEnd.ContainsKey(name) == false)
                return null;

            return BackEnd[name];
        }
    }
}
