﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    public class SqlTableConfigEntity
    {
        public string Key { get; set; }

        public string Value { get; set; }
    }
}
