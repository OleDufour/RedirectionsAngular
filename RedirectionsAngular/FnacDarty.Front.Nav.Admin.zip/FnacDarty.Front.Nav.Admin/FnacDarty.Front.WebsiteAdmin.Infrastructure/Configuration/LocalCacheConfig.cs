﻿using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    public abstract class LocalCacheConfig : BaseConfig
    {
        protected Dictionary<string, string> LocalCache { get; set; }

        protected override string GetSettingValueInternal(string name)
        {
            if (LocalCache.ContainsKey(name) == false)
                return null;

            return LocalCache[name];
        }

        protected LocalCacheConfig()
        {
            LocalCache = new Dictionary<string, string>();
        }
    }
}
