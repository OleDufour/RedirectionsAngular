using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Microsoft.Extensions.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    public class CoreConfig : IConfig
    {
        private readonly IConfiguration Configuration;

        public CoreConfig(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public bool IsKeyExists(string name) => Configuration.GetSection(name).Exists();

        public List<string> GetArrayValue(string name) => Configuration.GetSection(name).Get<string[]>().ToList();

        public string GetSettingValue(string name)
        {
            return Configuration[name];
        }

        public T GetSettingValue<T>(string name)
        {
            var value = GetSettingValue(name);
            var type = typeof(T);

            return ChangeType<T>(value, name);
        }

        public string GetSettingValueOptional(string name)
        {
            var value = GetSettingValue(name);

            if (string.IsNullOrWhiteSpace(value) == true)
                return null;

            return value;
        }

        public T GetSettingValueOptional<T>(string name)
        {
            var value = GetSettingValueOptional(name);
            var type = typeof(T);

            if (value == null)
                return default(T);

            return ChangeType<T>(value, name);
        }

        public void Refresh()
        {
            throw new NotImplementedException();
        }
        protected T ChangeType<T>(string value, string name)
        {
            var type = typeof(T);
            try
            {
                if (type.IsGenericType == true && type.GetGenericTypeDefinition() == typeof(Nullable<>))
                    type = Nullable.GetUnderlyingType(type); // value cannot be null here actually

                if (type.IsEnum == true)
                    return (T)Enum.Parse(type, value, true);

                return (T)Convert.ChangeType(value, type);
            }
            catch (FormatException)
            {
                throw new ConfigurationErrorsException(string.Format("The configuration value cannot be converted to the expected type {0} in {1}. key={2}, value={3}", type.Name, GetType().Name, name, value));
            }
        }
    }
}
