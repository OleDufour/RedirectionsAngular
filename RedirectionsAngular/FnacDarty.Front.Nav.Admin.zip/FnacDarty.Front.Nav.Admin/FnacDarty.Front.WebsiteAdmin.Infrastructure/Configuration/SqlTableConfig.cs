using System.Data;
using System.Data.SqlClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    /// <summary>
    /// Provides a IConfig implementation using SQL table as backend.
    /// </summary>
    public class SqlTableConfig : LocalCacheConfig
    {
        public override bool IsKeyExists(string name)
        {
            throw new System.NotImplementedException();
        }

        public override void Refresh()
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var cmd = new SqlCommand(StoredProcedure, connection) { CommandType = CommandType.StoredProcedure };

                foreach (var entity in cmd.ExecuteReader().Translate<SqlTableConfigEntity>())
                {
                    var key = entity.Key;
                    var value = entity.Value;

                    LocalCache[key] = value;
                }
            }
        }

        /// <summary>
        /// Initializes a new instance of the SqlTableConfig class.
        /// </summary>
        /// <param name="cs">The connection string of the SQL Server</param>
        /// <param name="sp">The stored procedure that retrieves values from the SQL tablebackend</param>
        /// <remarks>
        /// This constructor is designed to be used in applications that are not bound to a
        /// domain. SqlTableConfig then loads values only available to all domains, any 
        /// domain specific configuration value will be ignored.
        /// </remarks>
        public SqlTableConfig(string cs, string sp)
        {
            ConnectionString = cs;
            StoredProcedure = sp;

            Refresh();
        }

        /// <summary>
        /// Gets or sets the name of the SQL table to be used as configuration backend.
        /// </summary>
        /// <remarks>
        /// The stored procedure expects exactly one parameter :
        ///   @DomainId : the domain identifier
        ///   
        /// The stored procedure must return rows that conform to <see cref="SqlTableConfigEntity"/> structure.
        /// It is essential that it also returns rows that apply to all domains.
        /// </remarks>
        public string StoredProcedure { get; private set; }


        /// <summary>
        /// Gets or sets the connection string of the SQL server to be used as configuration backend.
        /// </summary>
        public string ConnectionString { get; private set; }
    }
}
