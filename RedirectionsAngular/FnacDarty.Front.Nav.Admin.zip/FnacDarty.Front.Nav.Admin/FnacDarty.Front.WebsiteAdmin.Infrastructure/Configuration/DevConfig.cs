using System;
using System.Collections.Generic;
using System.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration
{
    public class DevConfig : IConfig
    {
        private IConfig InnerConfig { get; set; }


        public DevConfig(IConfig inner)
        {
            InnerConfig = inner;
        }

        public bool IsKeyExists(string name)
        {
            var devname = string.Format("{0}.{1}", Environment.UserName, name);
            var value = ConfigurationManager.AppSettings[devname];
            return !string.IsNullOrWhiteSpace(value);
        }

        public string GetSettingValue(string name)
        {
            var devname = string.Format("{0}.{1}", Environment.UserName, name);

            var value = ConfigurationManager.AppSettings[devname];

            if (string.IsNullOrWhiteSpace(value) == false)
                return value;

            return InnerConfig.GetSettingValue(name);
        }

        public string GetSettingValueOptional(string name)
        {
            var devname = string.Format("{0}.{1}", Environment.UserName, name);

            var value = ConfigurationManager.AppSettings[devname];

            if (string.IsNullOrWhiteSpace(value) == false)
                return value;

            return InnerConfig.GetSettingValueOptional(name);
        }

        public T GetSettingValue<T>(string name)
        {
            var value = GetSettingValue(name);
            var type = typeof(T);

            return ChangeType<T>(value);
        }

        public T GetSettingValueOptional<T>(string name)
        {
            var value = GetSettingValueOptional(name);
            var type = typeof(T);

            if (value == null)
                return default(T);

            return ChangeType<T>(value);
        }

        public void Refresh()
        {
            
        }

        protected T ChangeType<T>(string value)
        {
            var type = typeof(T);
            try
            {
                return (T)Convert.ChangeType(value, type);
            }
            catch (FormatException)
            {
                throw new ConfigurationErrorsException(string.Format("The configuration value cannot be converted to the expected type {0} in {1}", type.Name, GetType().Name));
            }
        }

        public List<string> GetArrayValue(string name)
        {
            throw new NotImplementedException();
        }
    }
}
