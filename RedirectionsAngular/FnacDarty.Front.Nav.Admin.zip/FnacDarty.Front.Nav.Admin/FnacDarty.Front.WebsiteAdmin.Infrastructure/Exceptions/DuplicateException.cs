using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions
{
    /// <summary>
    /// Occurs when the user tries to update/insert a redirect whose combinations of DomainId, Source and SourceType already exist for a DIFFERENT non deleted redirection in the Redirect table.
    /// </summary>                                                                   
    public class DuplicateException : Exception { }                                   
}                                                                                    
