using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions
{
    /// <summary>
    /// Thrown when Source = Target and SourceType = TargetType in the SAME redirection
    /// </summary>
    public class IdenticalSourceTargetException : Exception { }
}
