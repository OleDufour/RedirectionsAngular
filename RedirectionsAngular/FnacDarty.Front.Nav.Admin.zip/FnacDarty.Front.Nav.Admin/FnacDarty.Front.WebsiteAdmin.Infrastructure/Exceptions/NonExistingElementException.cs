using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions
{
    /// <summary>
    /// Thrown when trying to update an element that doesn't exist at all in the database.
    /// </summary>
    public class NonExistingElementException : Exception { }
}
