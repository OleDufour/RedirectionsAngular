using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions
{
    /// <summary>
    /// Thrown when a circular reference occurs between sources and targets.
    /// </summary>
    public class CascadeException : Exception { }
}
