﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient
{
    public class RestClientConfiguration
    {
        public string BaseAddress { get; set; }

        public int? Timeout { get; set; }

        public byte? NumberOfAttempts { get; set; }

        public int? TimeToSleepBetweenAttempts { get; set; }
    }
}
