﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient
{
    public interface IRestClient
    {
        string BaseAddress { set; }
        int? Timeout { set; } // Timeout en millisecondes
        byte? NumberOfAttempts { set; }
        int? TimeToSleepBetweenAttempts { set; }
        T GetJsonResult<T>(string uri = null);
        bool Delete(string uri = null);
    }
}
