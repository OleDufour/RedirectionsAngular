﻿using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient
{
    public static class RestClientConfigurationManager
    {
        public static RestClientConfiguration Get(string configuration)
        {
            var parameter = configuration.Trim().Split(new[] { ';' });

            if (parameter == null || parameter.Length == 0)
            {
                return null;
            }

            var baseAddress = parameter[0].Trim();

            int? timeout = null;
            if (parameter.Length > 1 && int.TryParse(parameter[1].Trim(), out var tmpTimeout))
            {
                timeout = tmpTimeout;
            }

            byte? numberOfAttempts = null;
            if (parameter.Length > 2 && byte.TryParse(parameter[2].Trim(), out var tmpNumberOfAttempts))
            {
                numberOfAttempts = tmpNumberOfAttempts;
            }

            int? timeToSleepBetweenAttempts = null;
            if (parameter.Length > 3 && int.TryParse(parameter[3].Trim(), out var tmpTimeToSleepBetweenAttempts))
            {
                timeToSleepBetweenAttempts = tmpTimeToSleepBetweenAttempts;
            }

            var restClientConfiguration = new RestClientConfiguration
            {
                BaseAddress = baseAddress,
                Timeout = timeout,
                NumberOfAttempts = numberOfAttempts,
                TimeToSleepBetweenAttempts = timeToSleepBetweenAttempts
            };

            return restClientConfiguration;
        }

        public static List<RestClientConfiguration> GetList(string configuration)
        {
            var list = new List<RestClientConfiguration>();
            var configs = configuration.Trim().Split(new[] { '|' });

            foreach (var config in configs)
            {
                var restClientConfiguration = Get(config);

                if (restClientConfiguration == null)
                {
                    continue;
                }

                list.Add(restClientConfiguration);
            }

            return list;
        }
    }
}
