using System;
using System.IO;
using System.Net;
using System.Threading;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient
{
    public class RestClient : IRestClient
    {
        private readonly ILogger _logger;

        public RestClient(ILogger logger)
        {
            _logger = logger;
        }

        public string BaseAddress { private get; set; }

        public int? Timeout { private get; set; }

        public byte? NumberOfAttempts { private get; set; }

        public int? TimeToSleepBetweenAttempts { private get; set; }

        public T GetJsonResult<T>(string uri = null)
        {
            return CallApiMethod(uri, "GET", (response) =>
            {
                using (var stream = response.GetResponseStream())
                {
                    var jsonResult = string.Empty;
                    using (var sr = new StreamReader(stream))
                    {
                        jsonResult = sr.ReadToEnd();
                    }
                    return JsonConvert.DeserializeObject<T>(jsonResult);
                }
            });
        }

        public bool Delete(string uri = null)
        {
            HttpStatusCode? statusCode = null;

            var isDeleted = CallApiMethod(uri, "DELETE", (response) =>
            {
                statusCode = response.StatusCode;

                return statusCode == HttpStatusCode.Accepted
                    || statusCode == HttpStatusCode.NoContent
                    || statusCode == HttpStatusCode.OK;
            });

            if (!isDeleted)
            {
                _logger.LogError($"Erreur lors du DELETE sur : '{uri}' => Status code : {statusCode?.ToString() ?? string.Empty}");
            }

            return isDeleted;
        }

        private T CallApiMethod<T>(string uri, string method, Func<HttpWebResponse, T> responseCode)
        {
            var fullUri = ConcatBaseAddressWithUri(uri);
            var numberOfAttempts = NumberOfAttempts ?? 1;

            while (numberOfAttempts > 0)
            {
                var request = WebRequest.Create(fullUri);
                request.Method = method;

                if (Timeout.HasValue && Timeout.Value > 0)
                {
                    request.Timeout = Timeout.Value;
                }

                try
                {
                    using (var response = (HttpWebResponse)request.GetResponse())
                    {
                        return responseCode(response);
                    }
                }
                catch (WebException e) when (e.Status == WebExceptionStatus.Timeout)
                {
                    _logger.LogError($"Timeout lors de l'appel à: '{fullUri}'");

                    if (TimeToSleepBetweenAttempts.HasValue && TimeToSleepBetweenAttempts.Value > 0)
                    {
                        Thread.Sleep(TimeToSleepBetweenAttempts.Value);
                    }

                    numberOfAttempts--;
                }
                catch (Exception e)
                {
                    _logger.LogError(e, $"Erreur lors de l'appel à: '{fullUri}' => {e.Message}");
                    return default;
                }
            }

            return default;
        }

        private string ConcatBaseAddressWithUri(string uri)
        {
            if (string.IsNullOrWhiteSpace(BaseAddress))
            {
                return string.Empty;
            }

            if (string.IsNullOrWhiteSpace(uri))
            {
                return BaseAddress.TrimEnd('/') + "/";
            }

            return BaseAddress.TrimEnd('/') + "/" + uri.TrimStart('/');
        }
    }
}
