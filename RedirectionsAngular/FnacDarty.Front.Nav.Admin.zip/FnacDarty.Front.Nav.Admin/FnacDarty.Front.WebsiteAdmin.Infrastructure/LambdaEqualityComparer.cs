﻿using System;
using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure
{
    /// <summary>
    /// Represents a convenient wrapper of lambda expression which implements the IEqualityComparer{T} interface.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class LambdaEqualityComparer<T> : IEqualityComparer<T>
    {
        public Func<T, T, bool> Func { get; set; }

        public LambdaEqualityComparer(Func<T, T, bool> func)
        {
            Func = func;
        }

        public bool Equals(T x, T y)
        {
            return Func(x, y);
        }

        public int GetHashCode(T obj)
        {
            return obj.GetHashCode();
        }
    }
}
