using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository
{
    public class BaseRepository
    {
        private readonly string _connectionStringName;

        public ILogger Logger;
        public IConfig Config;
        public IPerfmonFactory PerfmonFactory;
        public IDbConnectionFactory DbConnectionFactory;


        private IPerfmon _perfmon => PerfmonFactory.GetCurrentPerfmon();

        public BaseRepository(ILogger logger,
                              IConfig config,
                              IPerfmonFactory perfmonFactory,
                              IDbConnectionFactory dbConnectionFactory)
            : this(logger, config, perfmonFactory, dbConnectionFactory, null)
        {
        }

        public BaseRepository(ILogger logger,
                              IConfig config,
                              IPerfmonFactory perfmonFactory,
                              IDbConnectionFactory dbConnectionFactory,
                              string connectionStringName)
        {
            Logger = logger;
            Config = config;
            PerfmonFactory = perfmonFactory;
            DbConnectionFactory = dbConnectionFactory;
            _connectionStringName = connectionStringName;
        }

        /// <summary>
        /// Executes the stored procedure and returns The number of rows affected
        /// </summary>
        /// <param name="psname">The specified name of the stored procedure</param>
        /// <param name="parameters">The list of the SQL parameters used by the stored procedure</param>
        /// <returns>The number of rows affected</returns>
        public int ExecuteNonQuery(string psname, Dictionary<string, object> parameters = null)
        {
            using (var connection = DbConnectionFactory.CreateConnection(_connectionStringName))
            {
                connection.Open();

                var cmd = CreateCommand(psname, connection, parameters);

                var rtn = _perfmon.Track<int>(cmd.ExecuteNonQuery, PerfmonCategory.Sql, psname);

                return rtn;
            }
        }

        /// <summary>
        /// Executes the stored procedure and returns The number of rows affected
        /// </summary>
        /// <param name="psname">The specified name of the stored procedure</param>
        /// <param name="command">Sql Command used by the stored procedure</param>
        /// <returns>The number of rows affected</returns>
        public int ExecuteNonQuery(string psname, IDbCommand command)
        {
            using (var connection = DbConnectionFactory.CreateConnection(_connectionStringName))
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = psname;
                command.CommandType = CommandType.StoredProcedure;
                var rtn = _perfmon.Track<int>(command.ExecuteNonQuery, PerfmonCategory.Sql, psname);

                return rtn;
            }
        }

        /// <summary>
        /// Executes the stored procedure and returns a list of primitive values or mapped entities.
        /// </summary>
        /// <typeparam name="T">primitive or entity</typeparam>
        /// <param name="psname">The specified name of the stored procedure</param>
        /// <param name="parameters">The list of the SQL parameters used by the stored procedure</param>
        /// <returns>A list of privimitives or entities</returns>
        public IEnumerable<T> ExecuteSelect<T>(string psname, Dictionary<string, object> parameters = null)
        {
            using (var connection = DbConnectionFactory.CreateConnection(_connectionStringName))
            {
                connection.Open();

                var cmd = CreateCommand(psname, connection, parameters);

                var reader = _perfmon.Track<IDataReader>(cmd.ExecuteReader, PerfmonCategory.Sql, psname);

                return reader.Translate<T>();
            }
        }

        /// <summary>
        /// Create the Connection and open it.
        /// </summary>
        /// <returns>The opened connection.</returns>
        protected IDbConnection CreateConnection()
        {
            var connection = DbConnectionFactory.CreateConnection();
            connection.Open();
            return connection;
        }

        /// <summary>
        /// Executes the command and returns a list of primitive values or mapped entities.
        /// </summary>
        /// <typeparam name="T">primitive or entity</typeparam>
        /// <param name="cmd">The specified Command to execute.</param>
        /// <returns>A list of privimitives or entities</returns>
        protected IEnumerable<T> ExecuteSelect<T>(IDbCommand cmd)
        {
            var reader = _perfmon.Track<IDataReader>(cmd.ExecuteReader, PerfmonCategory.Sql, cmd.CommandText);
            var res = reader.Translate<T>();
            if (!reader.IsClosed)
                reader.Close();
            return res;
        }

        public IEnumerable<T> ExecuteSelect<T>(string psname, IDbCommand command)
        {
            using (var connection = DbConnectionFactory.CreateConnection(_connectionStringName))
            {
                connection.Open();
                command.Connection = connection;
                command.CommandText = psname;
                command.CommandType = CommandType.StoredProcedure;
                var reader = _perfmon.Track<IDataReader>(command.ExecuteReader, PerfmonCategory.Sql, psname);

                return reader.Translate<T>();
            }
        }

        /// <summary>
        /// Executes the stored procedure and return a primitive value.
        /// </summary>
        /// <remarks>
        /// This methods only supports the basic primitive such as int, decimal, string etc. (The types
        /// that can be converted using Convert.ChangeType). Do not use for entity.
        /// </remarks>
        /// <typeparam name="T">primitive or entity</typeparam>
        /// <param name="psname">The specified name of the stored procedure</param>
        /// <param name="parameters">The list of the SQL parameters used by the stored procedure</param>
        /// <returns></returns>
        public T ExecuteScalar<T>(string psname, Dictionary<string, object> parameters = null)
        {
            using (var connection = DbConnectionFactory.CreateConnection(_connectionStringName))
            {
                connection.Open();

                var cmd = CreateCommand(psname, connection, parameters);

                var o = _perfmon.Track<object>(cmd.ExecuteScalar, PerfmonCategory.Sql, psname);

                if (o == null)
                    return default(T);

                return (T)Convert.ChangeType(o, typeof(T));
            }
        }

        /// <summary>
        /// Execute the stored procedure and returns the first element of the result set, or a default value if no such element is found.
        /// </summary>
        /// <typeparam name="T">primitive or entity</typeparam>
        /// <param name="psname">The specified name of the stored procedure</param>
        /// <param name="parameters">The list of the SQL parameters used by the stored procedure</param>
        /// <returns>The first element or a default value if empty result set</returns>
        public T ExecuteFirstOrDefault<T>(string psname, Dictionary<string, object> parameters = null)
        {
            return ExecuteSelect<T>(psname, parameters).FirstOrDefault();
        }

        /// <summary>
        /// Execute the stored procedure and returns the first element of the result set, or throw an exception if no such element is found.
        /// </summary>
        /// <typeparam name="T">primitive or entity</typeparam>
        /// <param name="psname">The specified name of the stored procedure</param>
        /// <param name="parameters">The list of the SQL parameters used by the stored procedure</param>
        /// <returns>The first element</returns>
        public T ExecuteFirst<T>(string psname, Dictionary<string, object> parameters = null)
        {
            return ExecuteSelect<T>(psname, parameters).First();
        }

        /// <summary>
        /// Creates a SqlCommand with optinal parameters. This is an utility method.
        /// </summary>
        /// <param name="psname"></param>
        /// <param name="connection"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        protected IDbCommand CreateCommand(string psname, IDbConnection connection, Dictionary<string, object> parameters = null)
        {
            IDbCommand cmd = CreateCommand(psname, connection);
            if (parameters != null)
            {
                foreach (var kvp in parameters)
                {
                    CreateParameter(cmd, kvp.Key, kvp.Value);
                }
            }
            return cmd;
        }

        protected IDbCommand CreateCommand(string psname, IDbConnection connection)
        {
            if (string.IsNullOrWhiteSpace(psname))
                throw new ArgumentNullException(nameof(psname), "Unable to create SQL command, the name of the stored procedure cannot be null or empty.");
            var cmd = connection.CreateCommand();
            cmd.CommandTimeout = 0;
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = psname;
            return cmd;
        }

        protected IDbDataParameter CreateParameter(IDbCommand cmd, string parameterName, object value)
        {
            var param = cmd.CreateParameter();
            param.ParameterName = parameterName;
            param.Value = value ?? DBNull.Value;
            cmd.Parameters.Add(param);
            return param;
        }

        protected IDbDataParameter CreateOutPutParameter(IDbCommand cmd, string parameterName, DbType type)
        {
            var param = cmd.CreateParameter();
            param.ParameterName = parameterName;
            param.Direction = ParameterDirection.Output;
            param.DbType = type;
            cmd.Parameters.Add(param);
            return param;
        }
    }
}
