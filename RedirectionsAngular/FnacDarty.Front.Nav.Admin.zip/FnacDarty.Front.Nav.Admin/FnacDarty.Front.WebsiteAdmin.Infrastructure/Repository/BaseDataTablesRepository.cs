using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository
{
    public abstract class BaseDataTablesRepository<T> : IDataTablesRepository<T>
    {
        public abstract string TableName { get; }
        public abstract string ConnectionString { get; }
        public abstract Dictionary<string, string> ColumnNameMapping { get; }

        private readonly IDbConnectionFactory dbConnectionFactory;

        public BaseDataTablesRepository(IDbConnectionFactory dbConnectionFactory)
        {
            this.dbConnectionFactory = dbConnectionFactory;
        }    
    }
}
