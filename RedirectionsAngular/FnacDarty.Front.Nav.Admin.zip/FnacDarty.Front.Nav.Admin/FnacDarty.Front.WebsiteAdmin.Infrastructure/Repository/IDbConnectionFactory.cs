using System.Data;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository
{
    public interface IDbConnectionFactory
    {
        IDbConnection CreateConnection(string connectionStringName = null);
    }
}
