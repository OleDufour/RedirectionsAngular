using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository
{
    public interface IDataTablesRepository<T>
    {
        Dictionary<string, string> ColumnNameMapping { get; }
        string ConnectionString { get; }
        string TableName { get; }

    }
}
