using System.Data;
using System.Data.SqlClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository
{
    public class SqlConnectionFactory : IDbConnectionFactory
    {
        private readonly IConfig _config;

        public SqlConnectionFactory(IConfig config)
        {
            _config = config;
        }

        public IDbConnection CreateConnection(string connectionStringName = null)
        {
            var connectionString = _config.GetSettingValue($"ConnectionStrings:{connectionStringName ?? "Default"}");
            return new SqlConnection(connectionString);
        }
    }
}
