﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension
{
    public static class SqlParameterCollectionExtensions
    {
        /// <summary>
        /// Performs a null value check and adds the value to the end of the <see cref="SqlParameterCollection"/>.
        /// </summary>
        /// <remarks>
        /// The SqlParameterCollection.AddWithValue() method provided by .NET Framework allows null values but 
        /// the query will fail during execution. The AddWithValueNullable extension method adds the DBNull.Value 
        /// when it encounters a runtime null value.
        /// </remarks>
        /// <param name="collection">The self instance</param>
        /// <param name="name">The name of the parameter.</param>
        /// <param name="value">The value to be added.</param>
        /// <returns>A SqlParameter object.</returns>
        public static SqlParameter AddWithValueNullable(this SqlParameterCollection collection, string name, object value)
        {
            return collection.AddWithValue(name, value ?? (object)DBNull.Value);
        }


        /// <summary>
        /// Transforms a value list into a predefined table-valued parameter with a single column.
        /// </summary>
        /// <remarks>
        /// To use this extension method, the type of the table-valued parameter must exist in the database.
        /// </remarks>
        /// <example>
        /// If a stored procedure expects @IdList as an input parameter, of type int_udtt:
        /// new SqlCommand().Parameters.AddWithValueList{int}("@IdList", "Id", new int[] { 1, 2, 3 })
        /// </example>
        /// <typeparam name="T">The specified type of the values in the list</typeparam>
        /// <param name="collection">The self instance</param>
        /// <param name="name">The name of the predefined table-valued parameter</param>
        /// <param name="column">The name of the column as declared in the predefined table-valued parameter</param>
        /// <param name="values">The list of the values to be passed as parameter</param>
        /// <returns>A SqlParameter object</returns>
        public static SqlParameter AddWithValueList<T>(this SqlParameterCollection collection, string name, string column, IEnumerable<T> values)
        {
            if (values == null)
                throw new InternalErrorException("Unable to add to SQL parameters using AddWithValueList, values cannot be null");


            var dt = new DataTable();

            dt.Columns.Add(column, typeof(T));

            foreach (var value in values)
                dt.Rows.Add(value);

            var p = collection.AddWithValue(name, dt);

            p.SqlDbType = SqlDbType.Structured;

            return p;
        }

        /// <summary>
        /// Transforms a value list into a predefined table-valued parameter with several columns.
        /// </summary>
        /// <remarks>
        /// To use this extension method, the type of the table-valued parameter must exist in the database.
        /// If the parameter has only one column, use AddWithValueList instead since it does not perform reflection.
        /// </remarks>
        /// <example>
        /// If a stored procedure expects @CountryList as an input parameter:
        /// 
        /// public class Country
        /// {
        ///     public int Id { get; set; }
        ///     public string Code { get; set; }
        /// }
        /// 
        /// new SqlCommand().Parameters.AddWithValueTable{Country}("@CountryList", new Country[] { new Country() { Id = 1, Code = "FR" } })
        /// </example>
        /// <typeparam name="T">The specified type of the values in the list</typeparam>
        /// <param name="collection">The self instance</param>
        /// <param name="name">The name of the predefined table-valued parameter</param>
        /// <param name="values">The list of the values to be passed as parameter</param>
        /// <param name="mode"></param>
        /// <param name="style"></param>
        /// <returns></returns>
        public static SqlParameter AddWithValueTable<T>(this SqlParameterCollection collection, 
                                                            string name, 
                                                            IEnumerable<T> values,
                                                            MappingMode mode = MappingMode.Name, 
                                                            MappingStyle style = MappingStyle.MapFieldAndProperty) where T : class
        {
            if (values == null)
                throw new InternalErrorException("Unable to add to SQL parameters using AddWithValueTable, values cannot be null");


            var dt = new DataTable();
            var mapping = new SqlDataReaderMapping(mode, style);
            var type = typeof(T);
            var members = mapping.GetMemberInfoList(type);

            // TODO refactor the code with SqlDataWriterMapping

            // add all columns 
            foreach (var mim in members)
            {
                var mi = mim.MemberInfo;
                var mt = mi is FieldInfo ? (mi as FieldInfo).FieldType : (mi as PropertyInfo).PropertyType;

                if (mt.IsGenericType == true && mt.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    // handle nullable types
                    var column = new DataColumn(mim.ColumnName, Nullable.GetUnderlyingType(mt));
                    column.AllowDBNull = true;
                    dt.Columns.Add(column);
                }
                else
                {
                    var column = new DataColumn(mim.ColumnName, mt);
                    dt.Columns.Add(column);
                }
            }

            // add rows
            foreach (var value in values)
            {
                var row = dt.NewRow();

                foreach (var mim in members)
                {
                    // get value for each column
                    var mi = mim.MemberInfo;
                    var v = mi is FieldInfo ? (mi as FieldInfo).GetValue(value) : (mi as PropertyInfo).GetValue(value, null);

                    row[mim.ColumnName] = v ?? DBNull.Value;
                }

                dt.Rows.Add(row);
            }

            var p = collection.AddWithValue(name, dt);

            p.SqlDbType = SqlDbType.Structured;

            return p;
        }
    }
}
