﻿using System.Collections.Generic;
using System.Data;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension
{
    public static class SqlDataReaderExtensions
    {
        /// <summary>
        /// Reads and translates a SqlDataReader that contains rows of entity data to objects of the desired type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr">The SqlDataReader that contains entity data to translate</param>
        /// <param name="mode"></param>
        /// <param name="style"></param>
        /// <returns></returns>
        public static IEnumerable<T> Translate<T>(this IDataReader dr, MappingMode mode = MappingMode.Name, MappingStyle style = MappingStyle.MapFieldAndProperty)
        {
            return new Mapping.SqlDataReaderMapping(mode, style).Translate<T>(dr);
        }

        /// <summary>
        /// Reads and translates a SqlDataReader that contains rows of entity data to objects of the desired type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dr">The SqlDataReader that contains entity data to translate</param>
        /// <param name="mode"></param>
        /// <param name="style"></param>
        /// <returns></returns>
        public static T TranslateOne<T>(this IDataReader dr, MappingMode mode = MappingMode.Name, MappingStyle style = MappingStyle.MapFieldAndProperty)
        {
            return new Mapping.SqlDataReaderMapping(mode, style).TranslateOne<T>(dr);
        }

    }
}
