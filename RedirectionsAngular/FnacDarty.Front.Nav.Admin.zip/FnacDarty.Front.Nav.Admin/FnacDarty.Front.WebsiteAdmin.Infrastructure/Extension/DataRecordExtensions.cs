﻿using System;
using System.Data;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension
{
    public static class DataRecordExtensions
    {
        /// <summary>
        /// Determines whether the IDataRecord contains the specified column.
        /// </summary>
        /// <param name="dr"></param>
        /// <param name="column">The specified column key.</param>
        /// <returns></returns>
        public static bool HasColumn(this IDataRecord dr, string column)
        {
            for (int i = 0; i < dr.FieldCount; i++)
            {
                if (dr.GetName(i).Equals(column, StringComparison.InvariantCultureIgnoreCase) == true)
                    return true;
            }

            return false;
        }
    }

}
