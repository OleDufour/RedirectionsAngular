﻿using System;
using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure
{
    /// <summary>
    /// Provides a convenient wrapper of lamdba expression which implements the IComparer{T} interface.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class LambdaComparer<T> : IComparer<T>
    {
        private Func<T, T, int> Func { get; set; }

        public LambdaComparer(Func<T, T, int> func)
        {
            Func = func;
        }

        public int Compare(T x, T y)
        {
            return Func(x, y);
        }
    }
}
