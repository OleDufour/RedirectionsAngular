using System;
using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mvc
{
    /// <summary>
    /// Encapsulates extended information for handling an error that was thrown by an action method.
    /// </summary>
    public class CustomHandleErrorInfo
    {
        public string UserName { get; set; }
        public string Url { get; set; }
        public string IpAddress { get; set; }
        public string ControllerName { get; set; }
        public string ActionName { get; set; }
        public Exception Exception { get; set; }
        

        public override string ToString()
        {
            var sb = new StringBuilder();

            sb.AppendLine();
            sb.AppendFormat("URL:        {0}", Url);
            sb.AppendLine();
            sb.AppendFormat("Controller: {0}", ControllerName);
            sb.AppendLine();
            sb.AppendFormat("Action:     {0}", ActionName);
            sb.AppendLine();
            sb.AppendFormat("User:       {0}", string.IsNullOrWhiteSpace(UserName) == true ? "(Unknown)" : UserName);
            sb.AppendLine();
            sb.AppendFormat("IP Address: {0}", string.IsNullOrWhiteSpace(IpAddress) == true ? "(Unknown)" : IpAddress);
            sb.AppendLine();
            sb.AppendFormat("Exception:  {0}", Exception);

            return sb.ToString();
        }


        public CustomHandleErrorInfo(HttpContext context, Exception exception)
        {

            Exception = exception;
            //ControllerName = context. RouteData.Values["controller"].ToString();
            //ActionName = context.RouteData.Values["action"].ToString();

            if (context == null)
                return;

            if (context.Request != null)
            {
                var request = context.Request;
                Url = request.GetDisplayUrl();
                IpAddress = context.Connection.RemoteIpAddress.ToString(); // no forwarded ip
            }

            if (context.User != null)
                UserName = context.User.Identity.Name;
        }
    }
}
