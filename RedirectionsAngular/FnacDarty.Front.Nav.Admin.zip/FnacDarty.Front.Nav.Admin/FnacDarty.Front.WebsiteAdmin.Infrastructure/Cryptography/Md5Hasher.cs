﻿using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Cryptography
{
    /// <summary>
    /// Provides a convenient way to compute MD5 hash from various input types.
    /// </summary>
    public class Md5Hasher
    {
        /// <summary>
        /// Computes the hash value for the specified string.
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public string Encrypt(string str)
        {
            var data = Encoding.ASCII.GetBytes(str);

            return Encrypt(data);
        }

        /// <summary>
        /// Computes the hash value for the specified input stream.
        /// </summary>
        /// <param name="stream"></param>
        /// <returns></returns>
        public string Encrypt(Stream stream)
        {
            using (var hasher = MD5.Create())
            {
                var data = hasher.ComputeHash(stream);

                return Convert(data);
            }
        }

        /// <summary>
        /// Computes the hash value for the specified byte array.
        /// </summary>
        /// <param name="buffer"></param>
        /// <returns></returns>
        public string Encrypt(byte[] buffer)
        {
            using (var hasher = MD5.Create())
            {
                var data = hasher.ComputeHash(buffer);

                return Convert(data);
            }
        }

        private string Convert(byte[] data)
        {
            var sb = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
                sb.Append(data[i].ToString("x2")); // md5 format

            return sb.ToString();
        }
    }
}
