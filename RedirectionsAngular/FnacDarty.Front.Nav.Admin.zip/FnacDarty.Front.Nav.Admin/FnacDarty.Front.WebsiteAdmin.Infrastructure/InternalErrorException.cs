﻿using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure
{
    /// <summary>
    /// The exception that should be thrown when there is an unexpected situation most likely due to programming error.
    /// </summary>
    public class InternalErrorException : Exception
    {
        public InternalErrorException()
        {
        }

        public InternalErrorException(string format, params object[] args) : base(String.Format(format, args))
        {
        }

    }
}
