﻿using System.Collections.Generic;
using System.Resources;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu
{
    public interface IDynamicMenuBuilder
    {
        IEnumerable<MenuSection> BuildMenu();

        IDynamicMenuBuilder AddSection(string sectionName, IEnumerable<MenuItem> menuItems, ResourceManager manager);
    }
}
