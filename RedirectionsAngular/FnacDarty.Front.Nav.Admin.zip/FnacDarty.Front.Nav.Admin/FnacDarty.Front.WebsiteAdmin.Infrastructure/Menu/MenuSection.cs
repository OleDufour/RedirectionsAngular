﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Resources;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu
{
    public class MenuSection
    {
        public ResourceManager Resource { get; set; }

        public string Label { get; set; }

        public IDictionary<string, MenuItem> Items { get; set; } = new Dictionary<string, MenuItem>(StringComparer.InvariantCultureIgnoreCase);

        public IEnumerable<string> AuthorizationsRequired
        {
            get
            {
                return Items.Values.SelectMany(x => x.AuthorizationsRequired).Distinct();
            }
        }
    }
}
