﻿using System;
using Microsoft.AspNetCore.Routing;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu
{
    public class SubMenuItem
    {
        public string Area { get; set; }
        public string Controller { get; set; }
        public string Action { get; set; }

        public string Label { get; set; }

        public string AuthorizationRequired { get; set; }

        public bool IsActive(RouteData routeData)
        {
            var areaName = (routeData.Values["area"] ?? string.Empty).ToString();
            var controllerName = (routeData.Values["controller"] ?? string.Empty).ToString();
            var actionName = (routeData.Values["action"] ?? string.Empty).ToString();

            if (((string.IsNullOrEmpty(areaName) && string.IsNullOrEmpty(Area)) || string.Equals(Area, areaName, StringComparison.InvariantCultureIgnoreCase))
                && string.Equals(Controller, controllerName, StringComparison.InvariantCultureIgnoreCase)
                && string.Equals(Action, actionName, StringComparison.InvariantCultureIgnoreCase))
            {
                return true;
            }

            return false;
        }
    }
}
