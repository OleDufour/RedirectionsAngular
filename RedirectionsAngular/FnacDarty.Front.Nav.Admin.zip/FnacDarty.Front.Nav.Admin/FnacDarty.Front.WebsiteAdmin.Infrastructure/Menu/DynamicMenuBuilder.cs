﻿using System;
using System.Collections.Generic;
using System.Resources;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu
{
    public class DynamicMenuBuilder : IDynamicMenuBuilder
    {
        private readonly IDictionary<string, MenuSection> _menuSections
            = new Dictionary<string, MenuSection>(StringComparer.InvariantCultureIgnoreCase);

        public IDynamicMenuBuilder AddSection(string sectionName, IEnumerable<MenuItem> menuItems, ResourceManager manager)
        {
            if(!_menuSections.ContainsKey(sectionName))
            {
                _menuSections.Add(sectionName, new MenuSection() { Label = sectionName, Resource = manager });
            }

            foreach(var menuItem in menuItems)
            {
                if(!_menuSections[sectionName].Items.ContainsKey(menuItem.Label))
                {
                    _menuSections[sectionName].Items.Add(menuItem.Label, menuItem);
                }
                else
                {
                    foreach (var subItem in menuItem.SubItems)
                    {
                        _menuSections[sectionName].Items[menuItem.Label].SubItems.Add(subItem);
                    }
                }
            }

            return this;
        }

        public IEnumerable<MenuSection> BuildMenu()
        {
            return _menuSections.Values;
        }
    }
}
