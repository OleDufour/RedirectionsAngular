﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Routing;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu
{
    public class MenuItem
    {
        public string Label { get; set; }

        public string Icon { get; set; }

        public List<SubMenuItem> SubItems { get; set; } = new List<SubMenuItem>();

        public IEnumerable<string> AuthorizationsRequired
        {
            get
            {
                return SubItems.Select(x => x.AuthorizationRequired).Distinct();
            }
        }

        public bool IsActive(RouteData routeData)
        {
            return SubItems.Any(i => i.IsActive(routeData));
        }
    }
}
