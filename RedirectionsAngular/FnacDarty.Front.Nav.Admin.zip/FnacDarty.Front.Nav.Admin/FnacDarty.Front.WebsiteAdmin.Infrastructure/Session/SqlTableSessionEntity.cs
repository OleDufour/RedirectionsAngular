﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    public class SqlTableSessionEntity
    {
        public string SessionId { get; set; }

        public string Value { get; set; }
    }
}
