﻿using System.Runtime.Serialization;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    [DataContract]
    public class SessionValueEntity
    {
        [DataMember(Name = "k")]
        public string Key { get; set; }


        [DataMember(Name = "v")]
        public string SerializedValue { get; set; }
    }
}
