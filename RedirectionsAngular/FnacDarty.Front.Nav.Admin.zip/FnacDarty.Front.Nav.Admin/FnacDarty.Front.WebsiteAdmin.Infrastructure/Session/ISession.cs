﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    /// <summary>
    /// Provides emulated session support for stateless websites using shared persisting storage as backend.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Stateless websites prevents the use of the default session support provided by most of web servers,
    /// as consecutive client requests may be dispatched to different servers, thus cannot retrieve previous
    /// session state. Popular web servers do have session synchronization mechanism, which is usually 
    /// implemented with broadcasting pattern, they suffer some performance issues.
    /// </para>
    /// <para>
    /// ISession is designed to provide highly proficient and reliable session support. Implementing classes
    /// are expected to use a fast persisting storage and keeps data read/write to a minimum. Clients should
    /// not rely heavily on ISession for the sake of performance and horizontal scaling, they should use 
    /// ISession tactically to reduce HTTP cookie size.
    /// </para>
    /// <para>
    /// Implementing classes are not expected to maintain expired sessions in the persisting storage themselves.
    /// In most cases, an external mechanism is required to clean up the storage.
    /// </para>
    /// </remarks>
    public interface ISession
    {
        /// <summary>
        /// Sets a value by key in the session.
        /// </summary>
        /// <param name="key">The specified key of the value</param>
        /// <param name="value">The specified value to set in the session</param>
        /// <remarks>
        /// Clients are expecting to call <see cref="ISession.Save">Save()</see> method
        /// to commit changes after setting new values.
        /// </remarks>
        void Set(string key, object value);


        /// <summary>
        /// Gets a session value as the requested type by key.
        /// </summary>
        /// <typeparam name="T">The type that the session value is expected to be.</typeparam>
        /// <param name="key">The key of the session value</param>
        /// <returns>The value converted to the requested type.</returns>
        /// <remarks>
        /// Implementors are free to choose the method to store data of various types, 
        /// however, JSON serialization is the most recommended for its light-weight and
        /// fast computing time.
        /// </remarks>
        T Get<T>(string key);

        /// <summary>
        /// Removes a value in the session by key.
        /// </summary>
        /// <param name="key">The specified key of the value to be removed</param>
        /// <remarks>
        /// Clients are expecting to call <see cref="ISession.Save">Save()</see> method
        /// to commit changes after removing any value.
        /// </remarks>
        void Remove(string key);

        /// <summary>
        /// Removes all values in the session.
        /// </summary>
        /// <remarks>
        /// Clients are expecting to call <see cref="ISession.Save">Save()</see> method
        /// to commit changes after removing all values.
        /// </remarks>
        void Clear();


        /// <summary>
        /// Abandons the current session.
        /// </summary>
        /// <remarks>
        /// The Abandon() method removes entirely the current session which is never to be
        /// used again. A new session will be allocated to clients in the following requests,
        /// whereas the <see cref="ISession.Clear"/> method keeps the current session.
        /// </remarks>
        void Abandon();

        /// <summary>
        /// Permanently saves the value changes in the session's persisting storage. 
        /// </summary>
        void Save();
    }
}
