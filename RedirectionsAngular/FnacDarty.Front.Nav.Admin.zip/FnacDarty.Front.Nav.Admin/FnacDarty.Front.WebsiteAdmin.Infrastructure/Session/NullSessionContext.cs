﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    /// <summary>
    /// Provides a empty mock-up implementation for testing purpose.
    /// </summary>
    public class NullSessionContext : ISessionContext
    {
        private string SessionId { get; set; }

        public NullSessionContext(string sid)
        {
            SessionId = sid;
        }


        /// <inheritdoc cref="ISessionContext.GetClientSessionId()" />
        public string GetClientSessionId()
        {
            return SessionId;
        }

        /// <inheritdoc cref="ISessionContext.CreateClientSessionId()" />
        public string CreateClientSessionId()
        {
            return SessionId;
        }

        /// <inheritdoc cref="ISessionContext.ClearClientSessionId()" />
        public void ClearClientSessionId()
        {
            
        }

        /// <inheritdoc cref="ISessionContext.DomainId" />
        public int DomainId 
        {
            get { return 0; }
        }
    }
}
