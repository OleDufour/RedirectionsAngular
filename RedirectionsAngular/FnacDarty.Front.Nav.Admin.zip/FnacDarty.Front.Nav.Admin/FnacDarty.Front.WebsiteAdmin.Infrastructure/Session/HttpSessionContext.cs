namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    /// <summary>
    /// Provides a session context implementation based on System.WebHttpContext.
    /// </summary>
    //public class HttpSessionContext : ISessionContext
    //{
    //    private static Regex SESSION_ID_PATTERN = new Regex("^[A-F0-9]{32}$");

    //    private string CookieName { get; set; }

    //    public int DomainId { get; private set; }

    //    public HttpSessionContext(string cookiename, int domain)
    //    {
    //        CookieName = cookiename;
    //        DomainId = domain;
    //    }

    //    /// <inheritdoc cref="ISessionContext.GetClientSessionId()" />
    //    public string GetClientSessionId()
    //    {
    //        var cookie = HttpContext.Current.Request.Cookies.Get(CookieName);

    //        if (cookie != null)
    //            return cookie.Value;

    //        return null;
    //    }

    //    /// <inheritdoc cref="ISessionContext.CreateClientSessionId()" />
    //    public string CreateClientSessionId()
    //    {
    //        // format N 00000000000000000000000000000000 (32 digits without hyphens)
    //        var guid = new Guid().ToString("N");

    //        var cookie = new HttpCookie(CookieName, guid);

    //        HttpContext.Current.Response.Cookies.Add(cookie);

    //        return guid;
    //    }

    //    /// <inheritdoc cref="ISessionContext.ClearClientSessionId()" />
    //    public void ClearClientSessionId()
    //    {
    //        var cookie = HttpContext.Current.Response.Cookies.Get(CookieName);

    //        // set expiration time is the only way to remove cookie from client browser
    //        cookie.Expires = DateTime.Now.AddDays(-1);
    //    }

       
    //}
}
