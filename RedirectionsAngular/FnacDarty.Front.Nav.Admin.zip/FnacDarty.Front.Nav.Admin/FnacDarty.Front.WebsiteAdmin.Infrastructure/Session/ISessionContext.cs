﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    /// <summary>
    /// Defines methods to manage client sessions.
    /// </summary>
    public interface ISessionContext
    {
        /// <summary>
        /// Gets the current session identifier of a client.
        /// </summary>
        /// <returns>The unique session identifier</returns>
        string GetClientSessionId();


        /// <summary>
        /// Creates a new session for a client.
        /// </summary>
        /// <returns>The newly created unique session identifier</returns>
        string CreateClientSessionId();

        /// <summary>
        /// Abandons the current session of a client.
        /// </summary>
        void ClearClientSessionId();


        /// <summary>
        /// Gets the identifier of the domain that the application is attached.
        /// </summary>
        int DomainId { get; }

    }
}
