﻿using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension;
using Newtonsoft.Json;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    /// <summary>
    /// Provides a share session support based on SQL Server.
    /// </summary>
    /// <example>
    /// <remarks>
    /// While SqlTableSession may participate in any transaction initiated by TransactionScope,
    /// the pratical use of transaction for session is actually very rare.
    /// </remarks>
    /// <code>
    /// var cs = "Test SQL Server Connection String";
    /// var cookie_name = "UNIQUE_COOKIE_NAME";
    /// var domain_id = 1;
    /// var sp_get = "dbo.PS_EXAMPLE_SESSION_GET";
    /// var sp_update = "dbo.PS_EXAMPLE_SESSION_UPDATe";
    /// 
    /// var context = new HttpSessionContext(cookie_name, domain_id);
    /// var session = new SqlTableSession(context, cs, sp_get, sp_update);
    /// 
    /// // retrieves a session value as integer
    /// session.Get&lt;int&gt;("INT_KEY");
    /// 
    /// // retrieves a session value as a list of string
    /// session.Get&lt;List&lt;string&gt;&gt;("STRING_LIST_KEY");
    /// 
    /// // writes a decimal value to the session and save changes
    /// session.Set("DECIMAL_KEY", 42.42);
    /// session.Save();
    /// 
    /// // removes a value and save changes
    /// session.Remove("NULL_KEY");
    /// session.Save();
    /// </code>
    /// </example>
    public class SqlTableSession : BaseSession
    {
        /// <summary>
        /// Gets the connection string of the SQL Server to be used as back-end storage.
        /// </summary>
        public string ConnectionString { get; private set; }


        /// <summary>
        /// Gets the name of the stored procedure to be used to retrieve session values.
        /// </summary>
        /// <remarks>
        /// The stored procedure expects exactly one parameter :
        ///   @SessionId : the session identifier
        ///   
        /// The stored procedure must return rows that conform to <see cref="SqlTableSessionEntity"/> structure.
        /// </remarks>
        public string StoredProcedureGet { get; private set; }


        /// <summary>
        /// Gets the name of the stored procedure to be used to commit session changes.
        /// </summary>
        /// <remarks>
        /// The stored procedure expects exactly two parameters :
        ///   @SessionId : the session identifier
        ///   @Value : the new value to commit
        /// </remarks>
        public string StoredProcedureUpdate { get; private set; }



        /// <summary>
        /// Initializes a new instance of SqlTableSession.
        /// </summary>
        /// <param name="context">The session context that SqlTableSession shoudl rely on.</param>
        /// <param name="cs">The connection string of SQL Server</param>
        /// <param name="sp_get">The name of the stored procedure to retrieve session values</param>
        /// <param name="sp_update">The name of the stored procedure to commit session changes</param>
        public SqlTableSession(ISessionContext context, string cs, string sp_get, string sp_update)
            : base(context)
        {
            ConnectionString = cs;

            StoredProcedureGet = sp_get;

            StoredProcedureUpdate = sp_update;
        }





        protected override void UpdateValueListToStorage(string sid, List<SessionValueEntity> valuelist)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var cmd = new SqlCommand(StoredProcedureUpdate, connection) { CommandType = CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@SessionId", sid);
                cmd.Parameters.AddWithValueNullable("@Value", JsonConvert.SerializeObject(valuelist));

                cmd.ExecuteNonQuery();
            }
        }

        protected override List<SessionValueEntity> GetValueListFromStorage(string sid)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var cmd = new SqlCommand(StoredProcedureGet, connection) { CommandType = CommandType.StoredProcedure };

                cmd.Parameters.AddWithValue("@SessionId", sid);

                foreach (var entity in cmd.ExecuteReader().Translate<SqlTableSessionEntity>())
                    return JsonConvert.DeserializeObject<List<SessionValueEntity>>(entity.Value);
            }

            return null;
        }
    }
}
