﻿using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    /// <summary>
    /// Provides base behaviors of shared sessions.
    /// </summary>
    public abstract class BaseSession : ISession
    {

        protected BaseSession(ISessionContext context)
        {
            Context = context;
        }

        protected ISessionContext Context { get; set; }

        protected List<SessionValueEntity> ValueList { get; set; }


        protected abstract void UpdateValueListToStorage(string sid, List<SessionValueEntity> valuelist);

        protected abstract List<SessionValueEntity> GetValueListFromStorage(string sid);


        protected void LazyLoadValueListFromStorage()
        {
            if (ValueList != null)
                return;

            var sid = Context.GetClientSessionId();

            if (String.IsNullOrWhiteSpace(sid) == false)
                ValueList = GetValueListFromStorage(sid);

            if (ValueList == null)
                ValueList = new List<SessionValueEntity>();

        }


        /// <inheritdoc cref="ISession.Save()" />
        public void Save()
        {
            var sid = Context.GetClientSessionId();

            // if no session id, create session id from context and retrieve it at the same time
            if (String.IsNullOrWhiteSpace(sid) == true)
                sid = Context.CreateClientSessionId();

            UpdateValueListToStorage(sid, ValueList);
        }


        /// <inheritdoc cref="ISession.Set(string, object)" />
        public void Set(string key, object value)
        {
            if (String.IsNullOrWhiteSpace(key) == true)
                throw new Exception("Unable to set session data, key must not be null or empty.");

            LazyLoadValueListFromStorage();

            // remove old values with the same key
            Remove(key);

            if (ValueList == null)
                ValueList = new List<SessionValueEntity>();

            ValueList.Add(new SessionValueEntity()
            {
                Key = key,
                SerializedValue = JsonConvert.SerializeObject(value),
            });

        }

        /// <inheritdoc cref="ISession.Get(string)" />
        public T Get<T>(string key)
        {
            if (String.IsNullOrWhiteSpace(key) == true)
                throw new Exception("Unable to retrieve session data, key must not be null or empty.");

            LazyLoadValueListFromStorage();

            var value = ValueList.FirstOrDefault(v => v.Key == key);

            return value == null ? default(T) : JsonConvert.DeserializeObject<T>(value.SerializedValue);
        }


        /// <inheritdoc cref="ISession.Get(string)" />
        public void Remove(string key)
        {
            if (String.IsNullOrWhiteSpace(key) == true)
                throw new Exception("Unable to remove session data, key must not be null or empty.");

            if (ValueList == null)
                return; // nothing to do here

            ValueList.RemoveAll((v) => v.Key == key);
        }


        /// <inheritdoc cref="ISession.Clear()" />
        public void Clear()
        {
            ValueList = null;
        }

        /// <inheritdoc cref="ISession.Abandon()" />
        public void Abandon()
        {
            // remove session id in response cookie 
            Context.ClearClientSessionId();
        }

    }
}
