﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Session
{
    public class SessionContext
    {
        //private const string COOKIE_KEY_SESSION_ID = "SRZ_SID";
        //private const string CACHE_KEY_SESSION = "SESSION_ID#";

        //private ISessionContext Backend { get; set; }

        //private ICache Cache { get; set; }


        //public SessionContext(ISessionContext backend, ICache cache = null)
        //{
        //    Backend = backend;
        //    Cache = cache;
        //}


        //public ISession GetCurrentSession()
        //{
        //    // get current session id from cookie
        //    var sid = GetCurrentSessionIdFromCookie();

        //    if (String.IsNullOrWhiteSpace(sid) == true)
        //        return Backend.CreateSession(); // new empty cookie

        //    // if cache is enabled, look value up from cache first
        //    if (Cache != null)
        //    {
        //        var key = GetSessionCacheKey(sid);
        //        var session_cached = Cache.Get<ISession>(key);

        //        if (session_cached != null)
        //            return session_cached;
        //    }

        //    var session = Backend.GetSessionById(sid);

        //    // if cache is enabled, cache session object for a short delay
        //    if (Cache != null)
        //    {
        //        var key = GetSessionCacheKey(sid);
        //        Cache.Set(key, session, new CacheItemPolicy() { AbsoluteExpiration = new DateTimeOffset(DateTime.Now, TimeSpan.FromHours(1)) })
        //    }

        //    return session;
        //}

        //private string GetSessionCacheKey(string sid)
        //{
        //    if (String.IsNullOrWhiteSpace(sid) == true)
        //        throw new InternalErrorException("Unable to get session cache key, provided session identifier is null or empty.");
                

        //    return String.Format("{0}{1}", CACHE_KEY_SESSION, sid); // sid is never null or empty
        //}


        //private string GetCurrentSessionIdFromCookie()
        //{
        //    var cookies = HttpContext.Current.Request.Cookies;

        //    var cookie = cookies.Get(COOKIE_KEY_SESSION_ID);

        //    if (cookie == null)
        //        return null;

        //    return cookie.Value;
        //}




    }
}
