﻿using System.Reflection;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    internal class MemberInfoMapping
    {
        public string ColumnName { get; set; }

        public MemberInfo MemberInfo { get; set; }
    }
}
