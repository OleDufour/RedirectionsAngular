﻿using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    /// <summary>
    /// When applied to the member of a type, specifies the class is mapped to the SQL table used by <see cref="SqlDataWriterMapping"/>.
    /// </summary>
    public class SqlTableMappingAttribute : Attribute
    {
        public string Name { get; set; }
    }
}
