﻿using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    /// <summary>
    /// When applied to the member of a type, specifies that the member should not be used by SqlDataWriterMapping
    /// </summary>
    public class IgnoreSqlDataWriterMappingAttribute : Attribute
    {
    }
}
