﻿using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    /// <summary>
    /// When applied to the member of a type, specifies that the member can be cloned by <see cref="ObjectMapping"/>.
    /// </summary>
    public class ObjectMemberMappingAttribute : Attribute
    {
        public int Index { get; set; }
    }
}
