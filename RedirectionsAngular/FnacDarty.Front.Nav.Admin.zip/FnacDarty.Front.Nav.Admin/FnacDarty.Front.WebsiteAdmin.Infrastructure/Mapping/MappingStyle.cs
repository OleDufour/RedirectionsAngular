﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    /// <summary>
    /// Specifies how the data mapping should be performed on the members of a type.
    /// </summary>
    public enum MappingStyle
    {
        /// <summary>
        /// Specifies that the data mapping should only be performed on the fields of a type.
        /// </summary>
        MapFieldOnly,

        /// <summary>
        /// Specifies that the data mapping should only be performed on the properties of a type.
        /// </summary>
        MapPropertyOnly,

        /// <summary>
        /// Specifies that the data mapping should be performed on the fields and properties of a type.
        /// </summary>
        MapFieldAndProperty,
    }
}
