﻿namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    /// <summary>
    /// Specifies how the data mapping should be performed on the members of a type.
    /// </summary>
    public enum MappingMode
    {
        /// <summary>
        /// Specifies that the data mapping should be performed based on member names.
        /// </summary>
        Name,

        /// <summary>
        /// Specifies that the data mapping should be performed based on custom attributes.
        /// </summary>
        CustomAttribute,
    }
}
