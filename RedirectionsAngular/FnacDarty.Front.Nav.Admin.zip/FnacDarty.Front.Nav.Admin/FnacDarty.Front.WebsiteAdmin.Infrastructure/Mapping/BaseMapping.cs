﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    public abstract class BaseMapping
    {

        public MappingStyle Style { get; set; }


        public MappingMode Mode { get; set; }


        protected static IEnumerable<Type> SimpleTypeList = new List<Type>()
        {
            //typeof(Enum),
            typeof(String),
            typeof(Decimal),
            typeof(DateTime),
            typeof(Guid)
        };

        protected static IEnumerable<Type> UnhandledTypeList = new List<Type>()
        {
            typeof(DateTimeOffset),
            typeof(TimeSpan),
        };


        public bool IsSimpleType(Type type)
        {
            if (type.IsPrimitive == true)
                return true; // this includes all C# primitives: int, long, byte...

            if (type.IsEnum == true)
                return true; // this includes all user defined enums

            if (SimpleTypeList.Contains(type) == true)
                return true; // this includes a few convertible types: enum, string, decimal...

            if (Convert.GetTypeCode(type) != TypeCode.Object)
                return true; // anything not an object, is a simple type

            if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>) && IsSimpleType(type.GetGenericArguments()[0]))
                return true; // handle nullable types

            return false;
        }



        //protected void SetValue(PropertyInfo pi, object target, object value)
        //{
        //    if (pi.PropertyType.IsGenericType == true)
        //    {
        //        if (value == DBNull.Value || value == null)
        //            pi.SetValue(target, null, null);
        //        else
        //        {
        //            var gt = pi.PropertyType.GetGenericArguments();
        //            pi.SetValue(target, Activator.CreateInstance(pi.PropertyType, ChangeValueType(value, gt[0])), null);
        //        }
        //    }
        //    else
        //        pi.SetValue(target, (value == DBNull.Value) ? null : ChangeValueType(value, pi.PropertyType), null);
        //}


        //protected void SetValue(FieldInfo fi, object target, object value)
        //{
        //    if (fi.FieldType.IsGenericType == true)
        //    {
        //        if (value == DBNull.Value || value == null)
        //            fi.SetValue(target, null);
        //        else
        //        {
        //            var gt = fi.FieldType.GetGenericArguments();
        //            fi.SetValue(target, Activator.CreateInstance(fi.FieldType, ChangeValueType(value, gt[0])));
        //        }
        //    }
        //    else
        //        fi.SetValue(target, (value == DBNull.Value) ? null : ChangeValueType(value, fi.FieldType));
        //}

        protected void SetValue(PropertyInfo pi, object target, object value)
        {
            pi.SetValue(target, CreateValueForType(value, pi.PropertyType));
        }

        protected void SetValue(FieldInfo pi, object target, object value)
        {
            pi.SetValue(target, CreateValueForType(value, pi.FieldType));
        }


        protected object CreateValueForType(object value, Type type)
        {
            if (type.IsGenericType == true)
            {
                if (value == DBNull.Value || value == null)
                    return null;
                else
                {
                    var gt = type.GetGenericArguments();

                    return Activator.CreateInstance(type, ChangeValueType(value, gt[0]));
                }
            }
            else
                return (value == DBNull.Value) ? null : ChangeValueType(value, type);
        }


        
        private object ChangeValueType(object value, Type type)
        {
            if (type.IsEnum == true)
                return Enum.ToObject(type, value);

            return Convert.ChangeType(value, type);
        }

    }
}
