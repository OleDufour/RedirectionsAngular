﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    public class SqlDataWriterMapping
    {
        public bool IsBulkInsert { get; set; }

        public bool TruncateBeforeInsert { get; set; }
                
        public MappingStyle Style { get; set; }
        public MappingMode Mode { get; set; }

        public string ConnectionString { get; set; }

        public string TableName { get; set; }

        public SqlDataWriterMapping(string cs, MappingMode mode = MappingMode.Name, MappingStyle style = MappingStyle.MapFieldAndProperty)
        {
            IsBulkInsert = true;
            TruncateBeforeInsert = false;

            ConnectionString = cs;

            Mode = mode;
            Style = style;
        }


        public void Write<T>(IEnumerable<T> records)
        {
            if (records.Count() <= 0)
                return; // nothing to do

            if (IsBulkInsert == true)
                WriteUsingBulk(records);
            else
                WriteUsingInsert(records);
        }



        private void WriteUsingBulk<T>(IEnumerable<T> records)
        {
            var prototype = typeof(T);

            // find table name
            var table = GetTableName(prototype);

            // truncate table if needed
            if (TruncateBeforeInsert == true)
                TruncateTable(prototype);

            using (var bulk = new SqlBulkCopy(ConnectionString, SqlBulkCopyOptions.Default))
            {

                var columns = new Dictionary<string, MemberInfo>();
                var dt = new DataTable(table);

                // find columns
                var mis = new List<MemberInfo>();

                if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapFieldOnly)
                    mis.AddRange(prototype.GetFields());

                if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapPropertyOnly)
                    mis.AddRange(prototype.GetProperties());

                foreach (var mi in mis)
                {
                    var ignore = mi.GetCustomAttributes(true).FirstOrDefault(a => a is IgnoreSqlDataWriterMappingAttribute) as IgnoreSqlDataWriterMappingAttribute;
                    if (ignore != null)
                        continue; // ignore this member

                    var name = GetColumnMappingName(mi);

                    if (name != null)
                    {
                        var mt = mi is FieldInfo ? (mi as FieldInfo).FieldType : (mi as PropertyInfo).PropertyType;

                        // add columns
                        if (mt.IsGenericType == true && mt.GetGenericTypeDefinition() == typeof(Nullable<>))
                        {
                            // handle nullable types
                            var column = new DataColumn(name, Nullable.GetUnderlyingType(mt));
                            column.AllowDBNull = true;
                            dt.Columns.Add(column);
                        }
                        else
                        {
                            var column = new DataColumn(name, mt);
                            dt.Columns.Add(column);
                        }

                        // add column mapping
                        bulk.ColumnMappings.Add(name, name);

                        // add column definition
                        columns[name] = mi;
                    }

                }

                // 
                var rows = new List<DataRow>();

                // now build sql parameters 
                foreach (var r in records)
                {
                    var row = dt.NewRow();

                    // find all properties to insert into database
                    foreach (var pair in columns)
                    {
                        var mi = pair.Value;

                        var value = mi is FieldInfo ? (mi as FieldInfo).GetValue(r) : (mi as PropertyInfo).GetValue(r, null);
                        row[pair.Key] = value ?? DBNull.Value;
                    }

                    rows.Add(row);
                }

                // assign table name
                bulk.DestinationTableName = table;

                // bulk dump
                bulk.WriteToServer(rows.ToArray());
            }


        }


        private void WriteUsingInsert<T>(IEnumerable<T> records)
        {
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var prototype = typeof(T);

                // find table name
                var table = GetTableName(prototype);


                // truncate table if needed
                if (TruncateBeforeInsert == true)
                    TruncateTable(prototype);


                // find columns
                var columns = new Dictionary<string, MemberInfo>();
                var pms = new List<string>();


                // search fields and properties
                var mis = new List<MemberInfo>();

                if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapFieldOnly)
                    mis.AddRange(prototype.GetFields());

                if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapPropertyOnly)
                    mis.AddRange(prototype.GetProperties());

                foreach (var mi in mis)
                {
                    var ignore = mi.GetCustomAttributes(true).FirstOrDefault(a => a is IgnoreSqlDataWriterMappingAttribute) as IgnoreSqlDataWriterMappingAttribute;
                    if (ignore != null)
                        continue; // ignore this member

                    var name = GetColumnMappingName(mi);

                    if (name != null)
                    {
                        columns[name] = mi;
                        pms.Add("@" + name);
                    }
                }

                // prepare query for multiple use
                var sql = String.Format("INSERT INTO {0} ({1}) VALUES ({2})",
                                        table,
                                        String.Join(",", columns.Keys.ToArray()),
                                        String.Join(",", pms.ToArray()));

                var cmd = new SqlCommand(sql, connection);

                // now build sql parameters 
                foreach (var r in records)
                {
                    // start new cmd
                    cmd.Parameters.Clear();

                    // find all properties to insert into database
                    foreach (var pair in columns)
                    {
                        var mi = pair.Value;

                        var value = mi is FieldInfo ? (mi as FieldInfo).GetValue(r) : (mi as PropertyInfo).GetValue(r, null);
                        cmd.Parameters.AddWithValueNullable("@" + pair.Key, value);
                    }

                    // ready to insert
                    cmd.ExecuteNonQuery();
                }
            }
        }



        private void TruncateTable(Type prototype)
        {
            // find table name
            var table = GetTableName(prototype);

            // truncate table
            using (var connection = new SqlConnection(ConnectionString))
            {
                connection.Open();

                var tcmd = new SqlCommand(String.Format("TRUNCATE TABLE {0}", table), connection);

                tcmd.ExecuteNonQuery();
            }
        }

        private string GetTableName(Type prototype)
        {
            if (String.IsNullOrWhiteSpace(TableName) == false)
                return TableName;

            var table = prototype.GetCustomAttributes(true).FirstOrDefault(a => a is SqlTableMappingAttribute) as SqlTableMappingAttribute;

            return table.Name;
        }

        private string GetColumnMappingName(MemberInfo mi)
        {
            switch (Mode)
            {
                case MappingMode.Name:
                    return mi.Name;

                case MappingMode.CustomAttribute:
                    // check if field has mapping attribute if it is in CustomAttribute mode
                    var attr = mi.GetCustomAttributes(true).FirstOrDefault(a => a is SqlColumnMappingAttribute) as SqlColumnMappingAttribute;
                    if (attr != null)
                        return attr.Name;
                    break;
            }

            return null;
        }



    }
}
