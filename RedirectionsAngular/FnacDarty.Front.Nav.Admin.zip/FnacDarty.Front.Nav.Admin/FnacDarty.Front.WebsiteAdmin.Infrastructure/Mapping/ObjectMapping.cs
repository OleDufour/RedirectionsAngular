﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{

    /// <summary>
    /// Provides a way of cloning members by name or by custom index.
    /// </summary>
    /// <remarks>
    /// ObjectMapping allows to assign property or field values from one object to another without doing 
    /// this manually one by one. This class can be instantiated in different modes and with differnt styles. 
    /// By default, it clones data by member names and searches for fields and properties.
    /// 
    /// In the mode MappingMode.Name, it looks up target class' member names and retrieves data from 
    /// source class with the same names for mapping.
    /// In the mode MappingMode.CustomAttribute, it searches for members with ObjectMemberMappingAttribute
    /// then uses the information provided by this attribute to map data between members with the same indexes.
    /// 
    /// MappingStyle allows to filter members by their type: field or property.
    /// 
    /// </remarks>
    /// <example>
    /// <code>
    /// class A 
    /// {
    ///     public int Id { get; set; }
    ///     public string Label { get; set; }
    ///          
    ///     [ObjectMemberMappingAttribute(Index = 1)]
    ///     public string SqlLabel { get; set; }
    /// }
    /// 
    /// class B
    /// {
    ///     public decimal Id { get; set; }
    ///     
    ///     [ObjectMemberMappingAttribute(Index = 1)]
    ///     public string Label;
    /// }
    /// 
    /// 
    /// var a = new A() { Id = 42, Label = "Alpha", SqlLabel = "Omega" };
    /// var b = new B();
    /// 
    /// var mapping = new ObjectMapping(); // Use default mode and style
    /// mapping.Translate&lt;A, B&gt;(a, b); // Only Id and Label will be copied into b
    /// 
    /// var mapping = new ObjectMapping(MappingMode.CustomAttribute); 
    /// mapping.Translate&lt;A, B&gt;(a, b); // a's SqlLabel will be copied into b's Label
    /// </code>
    /// </example>
    public class ObjectMapping : BaseMapping
    {

       
        public ObjectMapping(MappingMode mode = MappingMode.Name, MappingStyle style = MappingStyle.MapFieldAndProperty)
        {
            Mode = mode;
            Style = style;
        }



        public D Translate<T, D>(T source)
        {
            var destination = Activator.CreateInstance<D>();

            Translate<T, D>(source, destination);

            return destination;
        }


        /// <summary>
        /// use reflection to map all properties or fields tagged with clonable attributes from source to destination
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <typeparam name="D"></typeparam>
        /// <param name="source"></param>
        /// <param name="destination"></param>
        public void Translate<T, D>(T source, D destination)
        {
            var type_src = source.GetType();
            var type_dst = destination.GetType();

            foreach (var mi in GetMembers(type_src))
            {
                var key_src = GetMemberKey(mi);
                if (key_src == null)
                    continue; // skip this member if key not found for mapping

                // get source value 
                var value = mi is PropertyInfo ? (mi as PropertyInfo).GetValue(source, null) : (mi as FieldInfo).GetValue(source);

                foreach (var mi_dst in GetMembers(type_dst))
                {
                    var key_dst = GetMemberKey(mi_dst);
                    if (key_dst == null || key_src.Equals(key_dst) == false)
                        continue; // skip this target member if key not found for mapping

                    // assign value to destination value
                    if (mi_dst is PropertyInfo)
                        SetValue(mi_dst as PropertyInfo, destination, value);

                    if (mi_dst is FieldInfo)
                        SetValue(mi_dst as FieldInfo, destination, value);
                }
            }
        }

        private object GetMemberKey(MemberInfo mi)
        {
            switch (Mode)
            {
                case MappingMode.Name:
                    return mi.Name;

                case MappingMode.CustomAttribute:
                    var attr = mi.GetCustomAttribute<ObjectMemberMappingAttribute>(true);
                    if (attr != null)
                        return attr.Index;
                    break;
            }

            return null;
        }


        private IEnumerable<MemberInfo> GetMembers(Type type)
        {
            var list = new List<MemberInfo>();

            if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapFieldOnly)
                list.AddRange(type.GetFields());

            if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapPropertyOnly)
                list.AddRange(type.GetProperties());

            return list;
        }


    }
}
