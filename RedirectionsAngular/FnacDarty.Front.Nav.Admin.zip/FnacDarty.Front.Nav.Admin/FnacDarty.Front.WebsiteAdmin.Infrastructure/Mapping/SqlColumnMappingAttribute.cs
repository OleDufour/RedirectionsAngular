﻿using System;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{
    /// <summary>
    /// When applied to the member of a type, specifies the member can be mapped by <see cref="SqlDataReaderMapping"/>.
    /// </summary>
    public class SqlColumnMappingAttribute : Attribute
    {
        public string Name { get; set; }
    }
}
