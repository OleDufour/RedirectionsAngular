using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Extension;

namespace FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapping
{

    /// <summary>
    /// Provides a way of converting an IDataReader into a user-defined entity.
    /// </summary>
    /// <remarks>
    /// SqlDataReaderMapping can be instantiated in different modes and with different mapping styles.
    /// By default, it maps data by member names and searches for fields and properties.
    /// 
    /// In the mode MappingMode.Name, it looks up target class' member names and retrieves data from 
    /// IDataReader to map their values.
    /// In the mode MappingMode.CustomAttribute, it searches for members with SqlColumnMappingAttribute
    /// then uses the information provided by this attribute to map data. 
    /// 
    /// MappingStyle allows to filter members by their type: field or property.
    /// 
    /// The Translate&lt;T&gt;() method is also implemented as extension methods in the 
    /// </remarks>
    /// <example>
    /// <code>
    /// class Map
    /// {
    ///     public int Id { get; set; } 
    ///     
    ///     [SqlColumnMappingAttribute(Name = "SqlLabel")]
    ///     public string Label { get; set; }
    /// }
    /// 
    /// var data_reader = new SqlCommand(query, connection).ExecuteReader();
    /// var mapping = new Mapping.SqlDataReaderMapping(); // Use default mode and style
    /// mapping.Translate&lt;Map&gt;(data_reader); // Columns "Id" and "Label" from data_reader will be mapped.
    /// 
    /// var mapping = new Mapping.SqlDataReaderMapping(MappingMode.CustomAttribute, MappingStyle.MapFieldOnly);
    /// mapping.Translate&lt;Map&gt;(data_reader2); // Column "SqlLabel" from data_reader2 will be mapped. The property "Id" is ignored because of the mapping style.
    /// </code>
    /// </example>
    public class SqlDataReaderMapping : BaseMapping
    {

        public SqlDataReaderMapping(MappingMode mode = MappingMode.Name, MappingStyle style = MappingStyle.MapFieldAndProperty)
        {
            Mode = mode;
            Style = style;
        }


        /// <summary>
        /// Reads rows in an IDataReader and converts them to the desired type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="reader">The IDataReader to be converted</param>
        /// <returns></returns>
        public IEnumerable<T> Translate<T>(IDataReader reader)
        {
            var list = new List<T>();
            var t = default(T);

            while (TryGetValue<T>(reader, out t) == true)
            {
                list.Add(t);
            }

            return list;
        }


        /// <summary>
        /// Reads one row in an IDataReader and convert it to the desired type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="reader"></param>
        /// <returns></returns>
        public T TranslateOne<T>(IDataReader reader)
        {
            var output = default(T);

            if (TryGetValue<T>(reader, out output) == false)
                return default(T);

            return output;
        }

        private bool TryGetValue<T>(IDataReader reader, out T output)
        {
            if (reader.Read() == false)
            {
                // assign default value 
                output = default(T);

                return false;
            }

            var type = typeof(T);

            if (type.IsAbstract == true)
                throw new Exception("Unable to translate IDataReader, abstract class can't be instantiated and mapped");



            if (IsSimpleType(type) == true)
            {            
                output = (T)CreateValueForType(reader[0], type); // always take the first column
            }
            else
            {
                if (UnhandledTypeList.Contains(type) == true)
                    throw new Exception(String.Format("Unable to translate IDataReader, the type {0} is not handled.", type));

                // use reflection to instantiate a new object for complexe type
                var o = Activator.CreateInstance<T>();

                foreach (var mim in GetMemberInfoList(type))
                {
                    if (reader.HasColumn(mim.ColumnName) == false)
                        continue; // skip member data not retrieved from the database

                    switch (mim.MemberInfo.MemberType)
                    {
                        case MemberTypes.Property:

                            SetValue(mim.MemberInfo as PropertyInfo, o, reader[mim.ColumnName]);
                            break;

                        case MemberTypes.Field:

                            SetValue(mim.MemberInfo as FieldInfo, o, reader[mim.ColumnName]);
                            break;
                    }
                }

                output = o;
            }

            return true;
        }



        private string GetColumnMappingName(MemberInfo mi)
        {
            switch (Mode)
            {
                case MappingMode.Name:
                    return mi.Name;

                case MappingMode.CustomAttribute:
                    // check if field has mapping attribute if it is in CustomAttribute mode
                    var attr = mi.GetCustomAttributes(true).FirstOrDefault(a => a is SqlColumnMappingAttribute) as SqlColumnMappingAttribute;
                    if (attr != null)
                        return attr.Name;
                    break;
            }

            return null;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <remarks>
        ///  This method caches all entity members for faster access (by reflecting only once), but all members
        ///  must be cached and the filtering is to be performed by caller using the fields returned by stored procedures.
        ///  A previous version of this method cached only some members according the fields returned in IDataReader,
        ///  and it was bugged if translation was performed on several different sets of fields but on the same entity.
        ///  Translation on the sets other than the first would fail because they would use the members cached thanks
        ///  to the first set of fields.
        /// </remarks>
        /// <param name="prototype"></param>
        /// <returns></returns>
        internal IEnumerable<MemberInfoMapping> GetMemberInfoList(Type prototype)
        {
            if (CachedMemberInfoList.ContainsKey(prototype) == false)
            {
                // load member infos that can be used for assigning data to properties and fields
                var milist = new List<MemberInfoMapping>();

                // use reflection to examine properties
                if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapPropertyOnly)
                {
                    foreach (var pi in prototype.GetProperties())
                    {
                        var ignore = pi.GetCustomAttributes(true).FirstOrDefault(a => a is IgnoreSqlDataReaderMappingAttribute) as IgnoreSqlDataReaderMappingAttribute;
                        if (ignore != null)
                            continue;

                        var column = GetColumnMappingName(pi);

                        milist.Add(new MemberInfoMapping() { ColumnName = column, MemberInfo = pi });

                        // check if data reader has this column
                        //if (reader.HasColumn(column) == true)
                        //{
                        //    // the datareader contains a column with the same name as the current property
                        //    //var value = reader[column];

                        //    // check if data reader has this column, then set value if true
                        //    if (reader.HasColumn(column) == true)
                        //}
                    }
                }


                if (Style == MappingStyle.MapFieldAndProperty || Style == MappingStyle.MapFieldOnly)
                {
                    foreach (var fi in prototype.GetFields())
                    {
                        var ignore = fi.GetCustomAttributes(true).FirstOrDefault(a => a is IgnoreSqlDataReaderMappingAttribute) as IgnoreSqlDataReaderMappingAttribute;
                        if (ignore != null)
                            continue; // ignore this column 

                        var column = GetColumnMappingName(fi);

                        milist.Add(new MemberInfoMapping() { ColumnName = column, MemberInfo = fi });


                        // check if data reader has this column
                        //if (reader.HasColumn(column) == true)
                        //{
                        //    // the datareader contains a column with the same name as the current property
                        //    var value = reader[column];

                        //    // check if data reader has this column, then set value if true
                        //    if (reader.HasColumn(column) == true)
                        //}
                    }
                }

                CachedMemberInfoList[prototype] = milist;
            }

            return CachedMemberInfoList[prototype];
        }


        private static IDictionary<Type, List<MemberInfoMapping>> CachedMemberInfoList = new ConcurrentDictionary<Type, List<MemberInfoMapping>>();

    }
}
