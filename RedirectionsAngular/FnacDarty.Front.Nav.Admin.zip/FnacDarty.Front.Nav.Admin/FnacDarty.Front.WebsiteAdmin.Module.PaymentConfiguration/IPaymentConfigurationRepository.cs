using System.Collections.Generic;

namespace FnacDarty.Front.WebsiteAdmin.Module.PaymentConfiguration
{
    public interface IPaymentConfigurationRepository
    {
        int AddPaymentConfigurationRuleSet(int domainId, PaymentConfigurationRuleSet paymentConfigurationRuleSet);
        IEnumerable<PaymentConfigurationRuleSet> GetPaymentConfigurationRuleSets(int domainId);
        PaymentConfigurationRuleSet GetPaymentConfigurationRuleSetById(int domainId, int paymentConfigurationRuleId);
    }
}
