using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.PaymentConfiguration
{
    public class PaymentConfigurationRepository : IPaymentConfigurationRepository
    {
        private const string ConnectionStringName = "Commerce";

        private readonly ILogger _logger;
        private readonly IConfig _config;
        private readonly IPerfmonFactory _perfmonFactory;
        private readonly IDbConnectionFactory _dbConnectionFactory;
        private readonly IDomainConnectionStringProvider _domainConnectionStringProvider;

        public PaymentConfigurationRepository(ILogger logger,
                                              IConfig config,
                                              IPerfmonFactory perfmonFactory,
                                              IDbConnectionFactory dbConnectionFactory,
                                              IDomainConnectionStringProvider domainConnectionStringProvider)
        {
            _logger = logger;
            _config = config;
            _perfmonFactory = perfmonFactory;
            _dbConnectionFactory = dbConnectionFactory;
            _domainConnectionStringProvider = domainConnectionStringProvider;
        }

        private BaseRepository GetRepository(int domainId)
        {
            return new BaseRepository(_logger, _config, _perfmonFactory, _dbConnectionFactory, _domainConnectionStringProvider.Get(ConnectionStringName, domainId));
        }

        public int AddPaymentConfigurationRuleSet(int domainId, PaymentConfigurationRuleSet paymentConfigurationRuleSet)
        {
            return GetRepository(domainId).ExecuteScalar<int>(StoredProceduresNames.AddPaymentConfigurationRuleSet, new Dictionary<string, object>
            {
                {"Json", paymentConfigurationRuleSet.Json},
                {"Raw", paymentConfigurationRuleSet.Raw},
                {"CreationDate", paymentConfigurationRuleSet.CreationDate},
                {"CreationUser", paymentConfigurationRuleSet.CreationUser }
            });
        }

        public IEnumerable<PaymentConfigurationRuleSet> GetPaymentConfigurationRuleSets(int domainId)
        {
            return GetRepository(domainId).ExecuteSelect<PaymentConfigurationRuleSet>(StoredProceduresNames.GetPaymentConfigurationRuleSets);
        }

        public PaymentConfigurationRuleSet GetPaymentConfigurationRuleSetById(int domainId, int paymentConfigurationRuleId)
        {
            return GetRepository(domainId).ExecuteSelect<PaymentConfigurationRuleSet>(StoredProceduresNames.GetPaymentConfigurationRuleSetById, new Dictionary<string, object>
            {
                {"PaymentConfigurationRuleSetId", paymentConfigurationRuleId}
            }).FirstOrDefault();
        }
    }
}
