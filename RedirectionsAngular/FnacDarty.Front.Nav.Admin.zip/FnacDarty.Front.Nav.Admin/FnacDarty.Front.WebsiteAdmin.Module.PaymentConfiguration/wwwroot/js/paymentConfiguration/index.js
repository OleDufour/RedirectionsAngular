define(["jquery", "Vue", "core", "template", "datatables", "moment", "messenger"],
    function ($, Vue, core, template, datatables, moment, messenger) {
        return {
            ready: function () {
                moment.locale('fr');
                template.intiJsTemplate();
                template.displayLoader();
                function initTabDomainData(e) {
                    var domainDataUrl = $(e.target).attr("data-url");
                    var targetDomainTableId = $(e.target).attr("aria-controls") + "-Table";
                    template.displayLoader();
                    fnacdarty.Portal.Repository.Generic.Get(domainDataUrl, function (response) {
                        var $table = $("#" + targetDomainTableId);
                        $table.DataTable().clear().draw();
                        $table.dataTable({
                            "paging": false,
                            "ordering": false,
                            "info": false,
                            "searching": false,
                            responsive: true,
                            language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                            bDestroy: true,
                            "aaData": response.items,
                            columns: [
                                { "data": "Id" },
                                { "data": "CreationUser" },
                                { "data": "CreationDate" }
                            ],
                            aoColumnDefs: [
                                {
                                    width: "30px",
                                    "aTargets": [0],
                                },
                                {
                                    width: "30px",
                                    "aTargets": [3],
                                    "mData": "UiResourceId",
                                    "mRender": function (data, type, full) {
                                        var result =
                                            '<a href="' + full.ExportLink + '" class="btn btn-xs btn-info"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-original-title="' + fnacdarty.Portal.Repository.Generic.Wording.Export + '" data-placement="top"> <i class="fa fa-pencil"></i></a>';
                                        return result;
                                    }
                                }
                            ],
                            initComplete: function () {
                                template.hideLoader();
                                template.tooltipsPopovers();
                            },
                            drawCallback: function (settings) {
                                template.tooltipsPopovers();
                            }
                        });
                    });
                }
                $('a[data-toggle="tab"]').on('shown.bs.tab', initTabDomainData);
                $('.domainTabs a:first').tab('show');
                core.log("module ready");
            }
        };
    });