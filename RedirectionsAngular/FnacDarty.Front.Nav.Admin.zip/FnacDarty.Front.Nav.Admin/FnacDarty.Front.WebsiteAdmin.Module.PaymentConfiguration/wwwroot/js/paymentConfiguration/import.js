﻿define(["Vue", "vueUploadComponent", "flatErrorReport", "vueSpinnerComponent", "template", "dropdownComponent"],

    function (Vue, vueUploadComponent, flatErrorReport, vueSpinnerComponent, template, dropdownComponent) {

        Vue.component('file-upload', vueUploadComponent);
        var ScaleLoader = vueSpinnerComponent.ScaleLoader;

        // module definition
        return {
            ready: function () {
                var app = new Vue({
                    el: '#main-content',
                    components: {
                        vueUploadComponent,
                        flatErrorReport,
                        ScaleLoader,
                        dropdownComponent
                    },
                     mounted() {
                         template.intiJsTemplate();
                     },
                    data() {
                        return {
                          files: [],
                          errors : null,
                          success : false,
                          uploading : false
                        }
                      },
                    methods: {
                        inputFilter(newFile, oldFile, prevent) {
                            if (!/\.(xlsx)$/i.test(newFile.name)) {
                                return prevent()
                            }
                        },
                        inputFile(newFile, oldFile) {
                            if (newFile && !oldFile) {
                                this.errors = null;
                                this.success = false;
                            }
                            // one callback for everything, welcome to front end dev
                            if (newFile && newFile.error && !oldFile.error) {
                                // error
                                Vue.set(this, "errors", newFile.response.Errors);
                                this.files = [];
                                this.success = false;
                                this.uploading = false;
                              }
                              //success
                              if (newFile && newFile.success && !oldFile.success) {
                                this.files = [];
                                this.success = true;
                                  this.errors = null;
                                this.uploading = false;
                              }
                              // Start upload
                             else if (newFile && oldFile && newFile.active != oldFile.active) {
                                 this.uploading = true;
                             }
                        }
                    }
                });
            }
        };
    });
