using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Transactions;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDirect.OrderPipe.PaymentConfiguration.Serialization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FnacDarty.Front.WebsiteAdmin.Module.PaymentConfiguration
{
    [Authorize(Policy = "PaymentConfiguration_Read_Write")]
    [Area("PaymentConfiguration")]
    public class PaymentConfigurationController : Controller
    {
        private readonly IDomainBusinessModule _domainModule;
        private readonly IPaymentConfigurationExcelParser _paymentConfigurationExcelParser;
        private readonly IPaymentConfigurationJsonSerializer _paymentConfigurationJsonSerializer;
        private readonly IPaymentConfigurationRepository _paymentConfigurationRepository;

        public PaymentConfigurationController(IDomainBusinessModule domainModule,
                                             IPaymentConfigurationExcelParser paymentConfigurationExcelParser,
                                             IPaymentConfigurationJsonSerializer paymentConfigurationJsonSerializer,
                                             IPaymentConfigurationRepository paymentConfigurationRepository)
        {
            _domainModule = domainModule;
            _paymentConfigurationExcelParser = paymentConfigurationExcelParser;
            _paymentConfigurationJsonSerializer = paymentConfigurationJsonSerializer;
            _paymentConfigurationRepository = paymentConfigurationRepository;
        }

        [HttpGet]
        [Route("payment-configuration")]
        public IActionResult Index()
        {
            // hack because we only want a tab by "country"
            var domains = (from domain in (from domain in _domainModule.GetDomains()
                                           group domain by domain.CultureCode into g
                                           select g.First()) // group culture (ie FNAC.COM and FNACPRO.COM use both fr-FR)
                           group domain by domain.SiteCode into g
                           select g.First()).ToList(); // group site code (ie. FR.FNAC.BE and NL.FNAC.BE use both FNAC.BE)

            return View(new PaymentConfigurationIndexModel
            {
                Domains = domains
            });
        }

        [HttpGet]
        [Route("payment-configuration/{domainId:int}")]
        public JsonResult GetPaymentConfigurationRuleSetsByDomain(short domainId)
        {
            var rules = _paymentConfigurationRepository.GetPaymentConfigurationRuleSets(domainId).ToList();
            return new JsonResult(
                 new
                 {
                     items = rules.Select(x => new PaymentConfigurationListItemModel
                     {
                         Id = x.PaymentConfigurationRuleSetId,
                         CreationDate = $"{x.CreationDate.ToShortDateString()} {x.CreationDate.ToShortTimeString()}",
                         CreationUser = x.CreationUser,
                         ExportLink = Url.Action("ExportPaymentConfigurationRuleSetUrl", new { paymentConfigurationRuleSetId = x.PaymentConfigurationRuleSetId })
                     }).ToList()
                 });
        }

        [HttpGet]
        [Route("payment-configuration/{domainId:int}/export/{paymentConfigurationRuleSetId:int}")]
        public void ExportPaymentConfigurationRuleSetUrl(int domainId, int paymentConfigurationRuleSetId)
        {
            var paymentConfigurationRuleSet = _paymentConfigurationRepository.GetPaymentConfigurationRuleSetById(domainId, paymentConfigurationRuleSetId);

            if (paymentConfigurationRuleSet == null)
            {
                Response.StatusCode = (int)HttpStatusCode.NotFound;
                return;
            }

            var bytes = Convert.FromBase64String(paymentConfigurationRuleSet.Raw);

            Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            Response.Body.Write(bytes, 0, bytes.Length);
        }

        [HttpGet]
        [Route("payment-configuration/{domainId:int}/import")]
        public IActionResult ImportPaymentConfigurationRuleSet(int domainId)
        {
            var domains = _domainModule.GetDomains().ToList();

            return View(new PaymentConfigurationImportModel
            {
                Domain = domains.FirstOrDefault(domain => domain.DomainId == domainId)
            });
        }

        [HttpPost]
        [Route("payment-configuration/{domainId:int}/import")]
        public ActionResult ImportPaymentConfigurationRuleSet(IFormFile file, int domainId)
        {
            var report = new PaymentConfigurationImportErrorReport();

            ParsingOutput parsingOutput;

            using (var memoryStream = new MemoryStream())
            {
                file.CopyTo(memoryStream);

                var fileBytes = memoryStream.ToArray();
                var fileBase64 = Convert.ToBase64String(fileBytes);

                memoryStream.Seek(0, SeekOrigin.Begin);

                parsingOutput = _paymentConfigurationExcelParser.Parse(memoryStream);

                if (parsingOutput.HasErrors)
                {
                    foreach (var error in parsingOutput.Errors)
                    {
                        report.AddReport(error);
                    }

                    return BadRequest(report);
                }

                var json = _paymentConfigurationJsonSerializer.Serialize(parsingOutput.RuleSets);

                using (var transaction = new TransactionScope())
                {
                    var paymentConfigurationRuleSetId = _paymentConfigurationRepository.AddPaymentConfigurationRuleSet(domainId, new PaymentConfigurationRuleSet
                    {
                        Json = json,
                        Raw = fileBase64,
                        CreationDate = DateTime.Now,
                        CreationUser = User.Identity.Name
                    });

                    if (paymentConfigurationRuleSetId > 0)
                    {
                        transaction.Complete();
                    }
                }
            }

            return Ok();
        }

        public class PaymentConfigurationIndexModel
        {
            public IEnumerable<Domain> Domains { get; set; } = Enumerable.Empty<Domain>();
        }

        public class PaymentConfigurationImportModel
        {
            public Domain Domain { get; set; }
        }

        public class PaymentConfigurationListItemModel
        {
            public int Id { get; set; }
            public string CreationDate { get; set; }
            public string CreationUser { get; set; }
            public string ExportLink { get; set; }
        }

        public class PaymentConfigurationImportErrorReport
        {
            public List<string> Errors { get; } = new List<string>();

            public void AddReport(string error)
            {
                Errors.Add(error);
            }
        }
    }
}
