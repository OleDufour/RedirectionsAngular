﻿using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using FnacDirect.OrderPipe.PaymentConfiguration.Serialization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;

namespace FnacDarty.Front.WebsiteAdmin.Module.PaymentConfiguration
{
    public class ModuleRegistration : ModuleRegistrationBase
    {
        public override IServiceCollection RegisterServices(IServiceCollection services)
        {
            services.AddSingleton<IPaymentConfigurationRepository, PaymentConfigurationRepository>();
            services.AddSingleton<IPaymentConfigurationExcelParser, PaymentConfigurationExcelParser>();
            services.AddSingleton<IPaymentConfigurationJsonSerializer, PaymentConfigurationJsonSerializer>();

            return services;
        }

        public override AuthorizationOptions RegisterAuthorizations(AuthorizationOptions options)
        {
            options.AddPolicy("PaymentConfiguration_Read_Write", policy =>
            {
                policy.AddRequirements(new AuthorizedUserRequirement(false,
                    new[]
                    {
                        EnumUserRole.PAYMENTCONFIGURATION_WRITE,
                    }
                ));
                policy.RequireAuthenticatedUser();
                policy.AuthenticationSchemes.Add("Windows");
            });

            return options;
        }

        public override IDynamicMenuBuilder RegisterMenu(IDynamicMenuBuilder menuBuilder)
        {
            menuBuilder.AddSection(nameof(PaymentConfigurationResources.menu_section), new[]
            {
                new MenuItem()
                {
                    Label = nameof(PaymentConfigurationResources.menu_item),
                    Icon = "fa-database",
                    SubItems = new List<SubMenuItem>
                    {
                        new SubMenuItem
                        {
                            Area = "PaymentConfiguration",
                            Controller = "PaymentConfiguration",
                            Action = "Index",
                            Label = nameof(PaymentConfigurationResources.menu_item_index),
                            AuthorizationRequired = "PaymentConfiguration_Read_Write"
                        }
                    }
                }
            }, PaymentConfigurationResources.ResourceManager);

            return menuBuilder;
        }
    }
}
