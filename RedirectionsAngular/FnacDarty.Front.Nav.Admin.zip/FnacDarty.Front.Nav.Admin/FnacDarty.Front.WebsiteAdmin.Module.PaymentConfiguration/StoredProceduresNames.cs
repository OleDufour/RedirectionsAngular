﻿namespace FnacDarty.Front.WebsiteAdmin.Module.PaymentConfiguration
{
    internal static class StoredProceduresNames
    {
        internal static readonly string AddPaymentConfigurationRuleSet = "spWSA_AddPaymentConfigurationRuleSet";
        internal static readonly string GetPaymentConfigurationRuleSets = "spWSA_GetPaymentConfigurationRuleSets";
        internal static readonly string GetPaymentConfigurationRuleSetById = "spWSA_GetPaymentConfigurationRuleSetById";
    }
}
