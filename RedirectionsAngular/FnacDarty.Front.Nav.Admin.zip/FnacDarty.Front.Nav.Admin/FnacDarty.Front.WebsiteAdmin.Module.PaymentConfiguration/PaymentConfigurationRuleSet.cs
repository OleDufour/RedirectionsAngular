﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.PaymentConfiguration
{
    public class PaymentConfigurationRuleSet
    {
        public int PaymentConfigurationRuleSetId { get; set; }
        
        [Required]
        public string Json { get; set; }

        [Required]
        public string Raw { get; set; }

        [Required]
        public DateTime CreationDate { get; set; }

        [Required]
        [StringLength(200)]
        public string CreationUser { get; set; }

    }
}
