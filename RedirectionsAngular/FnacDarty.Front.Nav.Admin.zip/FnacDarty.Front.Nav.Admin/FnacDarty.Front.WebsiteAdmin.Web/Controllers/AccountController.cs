using System;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Web.Models.Account;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Controllers;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Web.Controllers
{
    public class AccountController : ApplicationController
    {

        public IUserBusinessModule UserBusinessModule;
        public IDtoModelMapper<User, UserViewModel> UserViewModelMapper;

        public AccountController(IUserBusinessModule userBusinessModule,
            IDtoModelMapper<User, UserViewModel> userViewModelMapper,
            ILogger logger, IAccessControl accessControl) : base( logger, accessControl)
        {
            UserViewModelMapper = userViewModelMapper;
            UserBusinessModule = userBusinessModule;
        }

        public new ActionResult Unauthorized()
        {
            return View();
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Admin)]
        public ActionResult Index()
        {
            var users = UserBusinessModule.GetUsers();

            var userViewModels = UserViewModelMapper.DtosToModels(users);

            return View(userViewModels);
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Admin)]
        public ActionResult Create()
        {
            var userViewModel = new UserViewModel()
            {
                Roles = Enum.GetValues(typeof(EnumUserRole)).Cast<EnumUserRole>().Select(r => new RefData() { Id = (int)r, Value = r.ToString() }).ToList()
            };

            return View("AddOrEdit", userViewModel);
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Admin)]
        public ActionResult Edit(Guid userId)
        {
            var user = UserBusinessModule.GetUserById(userId);

            var viewModel = UserViewModelMapper.DtoToModel(user);

            viewModel.Roles = Enum.GetValues(typeof(EnumUserRole)).Cast<EnumUserRole>().Select(r => new RefData() { Id = (int)r, Value = r.ToString() }).ToList();

            return View("AddOrEdit", viewModel);
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Admin)]
        public ResultModel Delete(Guid userId)
        {
            if (UserBusinessModule.DeleteUser(userId))
            {
                return new ResultModel()
                {
                    Success = true,
                    Message = Resources.Global.app_delete_success,
                    Data = Url.Action("Index")
                };
            }

            return new ResultModel()
            {
                Success = false,
                Message = Resources.Global.app_delete_error
            };
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Admin)]
        public JsonResult AddOrEdit(UserViewModel userViewModel)
        {
            if (ModelState.IsValid)
            {
                if (userViewModel.UserId == null || userViewModel.UserId.Value == Guid.Empty)
                {
                    //add
                    var user = UserViewModelMapper.ModelToDto(userViewModel);
                    if (UserBusinessModule.AddUser(user))
                    {
                        return Json(new ResultModel
                        {
                            Success = true,
                            Message = Resources.Global.app_add_success,
                            Data = Url.Action("Edit", "Account", new { userId = user.UserId })
                        });
                    }
                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = Resources.Global.app_add_error
                    });
                }
                else
                {
                    //update
                    var user = UserViewModelMapper.ModelToDto(userViewModel);
                    if (UserBusinessModule.UpdateUser(user))
                    {
                        return Json(new ResultModel
                        {
                            Success = true,
                            Message = Resources.Global.app_update_success,
                            // Special case when a user remove admin rights from itself
                            Data = user.UserId == ApplicationUser.UserId && !user.IsAdmin ? Url.Action("Index", "Home") : Url.Action("Edit", "Account", new { userId = user.UserId })
                        });
                    }
                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = Resources.Global.app_update_error
                    });
                }

            }
            return Json(new ResultModel
            {
                Success = false,
                Message = $"{Resources.Global.app_errors_list} :<ul>" + string.Join("", ModelStateErrors().Select(m => "<li>" + m + "</li>")) + "</ul>"
            });
        }
    }
}
