using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Repository;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Controllers;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Web.Controllers
{
    public class HomeController : ApplicationController
    {
        ILinkToOtherApplication LinkToOtherApplication;

        public HomeController(ILogger logger, IAccessControl accessControl, ILinkToOtherApplication linkToOtherApplication) : base(logger, accessControl)
        {
            LinkToOtherApplication = linkToOtherApplication;
        }

        public ActionResult Index()
        {
            return View(LinkToOtherApplication);
        }

        [HttpGet]
        public ResultModel ChangeLang(string lang)
        {
            ApplicationUser.SetLanguage(lang);
            return new ResultModel()
            {
                Success = true,
                Data = Url.Action("Index")
            };
        }

    }
}
