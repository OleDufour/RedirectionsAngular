using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mvc;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Controllers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Web.Controllers
{
    [AllowAnonymous]
    public class ErrorController : ApplicationController
    {

        public ErrorController(ILogger logger, IAccessControl accessControl) : base(logger, accessControl)
        {
        }


        public IActionResult Index(string statusCode)
        {
            ViewBag.StatusCode = statusCode ?? "500";

            var exceptionFeature = HttpContext.Features.Get<IExceptionHandlerPathFeature>();
            if (exceptionFeature != null)
            {
                var model = new CustomHandleErrorInfo(HttpContext, exceptionFeature.Error);
                Logger.LogError(exceptionFeature.Error, exceptionFeature.Error.Message, model);
                return View(model);
            }
            return View(null);
        }
    }
}
