using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace FnacDarty.Front.WebsiteAdmin.Web.Helpers
{
    public static class AppHelper
    {
        public static string GetFlagForDomain(EnumDomain domain)
        {
            switch (domain)
            {

                case EnumDomain.NL_BE:
                case EnumDomain.FR_BE:
                    return "flag-icon-be";
                case EnumDomain.ES_ES:
                    return "flag-icon-es";
                case EnumDomain.PT_PT:
                    return "flag-icon-pt";
                case EnumDomain.FR_CH:
                    return "flag-icon-ch";
                case EnumDomain.FR_FR_PRO:
                case EnumDomain.FR_FR:
                default:
                    return "flag-icon-fr";
            }
        }

        public static IEnumerable<SelectListItem> ToSelectList(this IEnumerable<DomainModel> domainViewModelList, IList<int> selectedValues)
        {
            var domainViewModels = domainViewModelList as IList<DomainModel> ?? domainViewModelList.ToList();
            if (domainViewModelList == null || !domainViewModels.Any())
            {
                throw new ArgumentNullException(nameof(domainViewModelList));
            }

            IList<SelectListItem> result = new List<SelectListItem>();

            foreach (var d in domainViewModels)
            {
                var item = new SelectListItem
                {
                    Text = $"{d.SiteCode} - {d.CultureCode}",
                    Value = d.DomainId.ToString(),
                    Selected = selectedValues != null && selectedValues.Contains(d.DomainId)
                };
                result.Add(item);
            }

            return result;
        }
    }


}
