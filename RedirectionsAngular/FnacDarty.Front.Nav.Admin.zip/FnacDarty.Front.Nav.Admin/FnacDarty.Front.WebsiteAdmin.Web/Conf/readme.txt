Environnement LOCAL :
	* le site back pointe sur l'API locale

Environnement DEV2 :
	* le site back pointe sur l'API du poste de merge SGEW0218 (pas d'applicatifs sur DEV2)
	* créer les entrées DNS suivantes dans le fichier c:\windows\system32\drivers\etc\hosts
		10.10.6.125     ws-websiteadmin.fd-dev.net
		10.10.6.125     ws-websiteadmin-pvw.fd-dev.net

Lancer le configmerge en remplaçant [$GIT] par le chemin du repo GIT sur votre poste :
	* LOCAL :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Web [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.LOCAL.FD.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.LOCAL.FD.functional.properties

	* DEV2 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Web [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.DEV2.FD.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.DEV2.FD.functional.properties

	* REC6 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Web [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.REC6.FD.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.REC6.FD.functional.properties

	* REC2 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Web [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.REC2.FD.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.REC2.FD.functional.properties

	* REC1 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Web [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.REC1.FD.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.REC1.FD.functional.properties

	* PVW :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Web [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.PVW.FD.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web\Conf\WebSiteAdmin.PVW.FD.functional.properties
