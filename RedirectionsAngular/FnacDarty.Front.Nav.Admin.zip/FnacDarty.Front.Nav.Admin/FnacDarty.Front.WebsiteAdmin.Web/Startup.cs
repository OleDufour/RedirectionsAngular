using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using FnacDarty.Front.WebsiteAdmin.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Repository;
using FnacDarty.Front.WebsiteAdmin.Web.Filters;
using FnacDarty.Front.WebsiteAdmin.Web.Mapper.Account;
using FnacDarty.Front.WebsiteAdmin.Web.Mapper.Common;
using FnacDarty.Front.WebsiteAdmin.Web.Models.Account;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Support.AccessControl;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json.Serialization;

namespace FnacDarty.Front.WebsiteAdmin.Web
{
    public class Startup
    {
        public IConfiguration Configuration { get; set; }

        public IEnumerable<ModuleRegistrationBase> Modules { get; set; } = Enumerable.Empty<ModuleRegistrationBase>();

        public Startup(IConfiguration configuration, IHostingEnvironment hostingEnvironment)
        {
            Configuration = configuration;

            var modules = new List<ModuleRegistrationBase>();

            var moduleDirectoryPath = hostingEnvironment.ContentRootPath;

            if (!string.IsNullOrEmpty(Configuration["ModulesDirectoryPath"]))
            {
                moduleDirectoryPath = Configuration["ModulesDirectoryPath"];
            }

            var moduleCandidates = System.IO.Directory.GetFiles(moduleDirectoryPath, "FnacDarty.Front.WebsiteAdmin.Module.*.dll", System.IO.SearchOption.AllDirectories);
            var loadedModuleTypeNames = new HashSet<string>();

            foreach (var moduleCandidate in moduleCandidates)
            {
                try
                {
                    var assembly = System.Runtime.Loader.AssemblyLoadContext.Default.LoadFromAssemblyPath(moduleCandidate);

                    var moduleRegistrationType = assembly.GetTypes().FirstOrDefault(x => x.BaseType == typeof(ModuleRegistrationBase));

                    if (moduleRegistrationType != null)
                    {
                        if (!loadedModuleTypeNames.Contains(moduleRegistrationType.FullName))
                        {
                            loadedModuleTypeNames.Add(moduleRegistrationType.FullName);
                            modules.Add(Activator.CreateInstance(moduleRegistrationType) as ModuleRegistrationBase);
                        }
                    }
                }
                catch
                {
                    // this might fail if assembly was auto discovered by runtime during website launch
                    // ie. when no ModulesDirectoryPath were specified and that we are usign the ContentRootPath as a default path
                }
            }

            Modules = modules;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddFnacLogging(builder =>
            {
                builder.AddConfiguration(Configuration.GetSection("Logging"));

                var rabbitConf = Configuration.GetSection("Logging").GetSection("Rabbitmq");
                var kafkaConf = Configuration.GetSection("Logging").GetSection("Kafka");
                var consoleConf = Configuration.GetSection("Logging").GetSection("Console");
                bool enabled;

                //Rabbit log activate
                if (bool.TryParse(rabbitConf["Enabled"], out enabled))
                {
                    builder.AddRabbitmq(rabbitConf);
                }

                //kafka log activate
                if (bool.TryParse(kafkaConf["Enabled"], out enabled))
                {
                    builder.AddKafka(kafkaConf);
                }

                //console log activate
                if (bool.TryParse(consoleConf["Enabled"], out enabled))
                {
                    builder.AddConsole().AddAspNetCoreLogEntryEnricher();
                }
            });

            services.AddSingleton(Modules);

            var dynamicMenuBuilder = new DynamicMenuBuilder();

            var mvcBuilder = services.AddMvc(options =>
            {
                options.Filters.Add(typeof(FrontNavAdminFilter));
            })
            // Set JSON output to Pascalcase instead of camelCase
            .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            services.ConfigureOptions(typeof(UIConfigureOptions));

            foreach (var module in Modules)
            {
                module.RegisterServices(services);
                module.RegisterMenu(dynamicMenuBuilder);
                mvcBuilder.AddApplicationPart(module.GetType().Assembly);
            }

            // Add HttpContextAccessor
            services.AddHttpContextAccessor();
            var serviceProviderp = services.BuildServiceProvider();
            var httpContextAccessor = serviceProviderp.GetService<IHttpContextAccessor>();

            var config = new CoreConfig(Configuration);
            services.AddSingleton<IConfig>(config);

            var loggerFactory = (ILoggerFactory)serviceProviderp.GetService(typeof(ILoggerFactory));
            var logger = loggerFactory.CreateLogger<Startup>();
            services.AddSingleton<ILogger>(logger);

            services.AddSingleton<IDynamicMenuBuilder>(dynamicMenuBuilder);

            services.AddSingleton<ILocalCache>(new CacheFactory(config).CreateLocalCacheFromConfiguration());
            services.AddSingleton<IPerfmonFactory>(new PerfmonFactory(config, httpContextAccessor).CreatePerfmonFromConfiguration());
            services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
            services.AddSingleton<ILinkToOtherApplication, LinkToOtherApplication>();
            services.AddScoped<IAccessControl, HttpContextBasedAccessControl>();
            services.AddScoped<IAuthorizationHandler, AuthorizedUserHandler>();
            
            services.AddSingleton<IRestClient, RestClient>();

            SetPolicies(services);

            services.AddLocalization(options => options.ResourcesPath = "Resources");

            services.Configure<RequestLocalizationOptions>(options =>
            {
                var supportedCultures = new[]
                {
                    new CultureInfo("fr-FR"),
                    new CultureInfo("en-GB")
                };

                options.DefaultRequestCulture = new RequestCulture("fr-FR", "fr-FR");
                options.SupportedCultures = supportedCultures;
                options.SupportedUICultures = supportedCultures;

                options.RequestCultureProviders.Insert(0, new CustomRequestCultureProvider(ctx =>
                {
                    var lang = "fr-FR";
                    var cookie = ctx.Request.Cookies.FirstOrDefault(x => x.Key == "lang");

                    if (!cookie.Equals(default(KeyValuePair<string, string>)))
                        lang = cookie.Value;

                    return Task.FromResult(new ProviderCultureResult(lang, lang));

                }));
            });

            //register Repo & Module
            RegisterRepositories(services);
            RegisterModules(services);
            RegisterMappers(services);

            // set domain resolver for global authorization check
            AccessControlDomainResolver.SetResolver(() => config.GetSettingValue("Acl.DefaultDomain"));

            // log startup application
            logger.LogInformation($"{Assembly.GetExecutingAssembly()} in server {Environment.MachineName} started");
        }

        private void SetPolicies(IServiceCollection services)
        {
            services.AddAuthorization(options =>
            {

                options.AddPolicy(AuthorizePolicyConsts.Admin, policy =>
                {
                    policy.AddRequirements(new AuthorizedUserRequirement(true, new EnumUserRole[0]));
                    policy.RequireAuthenticatedUser();
                    policy.AuthenticationSchemes.Add("Windows");
                });


               

                foreach (var module in Modules)
                {
                    module.RegisterAuthorizations(options);
                }
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();

                // global cors policy
                app.UseCors(x => x
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            }
            else
            {
                // Handle 500 and others
                app.UseExceptionHandler("/Error/Index/500");
                // Handle 404
                app.Use(async (ctx, next) =>
                {
                    await next();
                    if (ctx.Response.StatusCode == 404 && !ctx.Response.HasStarted)
                    {
                        //Re-execute the request so the user gets the error page
                        ctx.Items["originalPath"] = ctx.Request.Path.Value;
                        ctx.Request.Path = "/Error/Index/400";
                        await next();
                    }
                });
            }

            app.UseStaticFiles();

            var localizationOption = app.ApplicationServices.GetService<IOptions<RequestLocalizationOptions>>();
            app.UseRequestLocalization(localizationOption.Value);

            app.UseMvc(routes =>
            {
                foreach (var module in Modules)
                {
                    module.MapRoutes(routes);
                }

                routes.MapRoute(
                    name: "default",
                    template: "{controller=Home}/{action=Index}/{id?}");
            });
        }

        private static void RegisterMappers(IServiceCollection services)
        {
            services.AddSingleton<IDtoModelMapper<Domain, DomainModel>, DomainModelMapper>();
            services.AddSingleton<IDtoModelMapper<User, UserViewModel>, UserViewModelMapper>();
            services.AddSingleton<IDtoModelMapper<User, UserViewModel>, UserViewModelMapper>();
        }

        private static void RegisterRepositories(IServiceCollection services)
        {
            services.AddSingleton<IDomainConnectionStringProvider, DomainConnectionStringProvider>();
            services.AddSingleton<IDomainRepository, DomainRepository>();
            services.AddSingleton<IUserRepository, UserRepository>();

           
        }

        private static void RegisterModules(IServiceCollection services)
        {
            services.AddSingleton<IDomainBusinessModule, DomainBusinessModule>();
            services.AddSingleton<IUserBusinessModule, UserBusinessModule>();
        }
    }
}
