Profils de debug :
	* IIS Express : avant d'utiliser ce profil, veiller à avoir effectué les opérations suivantes au préalable :
		1. le fichier web.config doit contenir les informations suivantes :

		<security>
			<authentication>
				<anonymousAuthentication enabled="false" />
				<windowsAuthentication enabled="true" />
			</authentication>
		</security>

	* IIS : avant d'utiliser ce profil, veiller à avoir effectué les opérations suivantes au préalable :
		1. modifier l'installation de Micorsoft Visual Studio 2017 pour intégrer l'option "Prise en charge d'IIS pendant le développement"
			(dans la section "Développement web et ASP.NET" puis "Développement multiplateforme .NET Core")
		2. sous IIS :
			- créer un pool applicatif "FDDEVPOOL-WebStAdm"
			- créer un nouvelle site "WebSiteAdmin" en précisant le chemin suivant : [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Web ou [$GIT] est le chemin de votre repo GIT
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Documentation flux des données.

* UrlRewrites 
    Pour exporter les urlRewrites, cette solution remplit la table 'PublishedUrlRewrite'. 
    Les données dans cette table sont récuperées ici : 
    \10-Front\services\front\Dev\Dev-Front\src\FnacDirect.Nav\FnacDirect.Nav.DataAccess\SeoDecorationDao.cs 
 
* Redirections
    Pour exporter les redirections cette solution utilise une table 'PublishedRedirect'. 
    Les données dans cette table sont récuperées par une solution qui se trouve ici : 
    <code>\10-Front\services\front\Dev\Dev-Front\src\Redirection\Redirection.sln 
     
    Dans cette solution, ficher UrlRedirect.cs se trouve une méthode public :  
     public RedirectResultInfo GetRedirect(string source, RedirectTypeEnum type) 
    ... qui est appelée par :  
    \10-Front\webcontrols\frontwebbusiness\Dev\Dev-Front\Src\FrontWebBusiness\FnacDirect.Front.WebBusiness\UrlRedirection\UrlRedirectionInspector.cs (ligne 40) 

 