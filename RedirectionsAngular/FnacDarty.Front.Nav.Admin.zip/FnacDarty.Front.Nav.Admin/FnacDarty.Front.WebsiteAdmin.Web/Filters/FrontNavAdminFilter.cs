using System;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Http;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Web.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Newtonsoft.Json;

namespace FnacDarty.Front.WebsiteAdmin.Web.Filters
{

    public class FrontNavAdminFilter : IActionFilter
    {
        private readonly IConfig _config;
        private readonly IAccessControl _accessControl;
        private readonly IPerfmonFactory _perfmonFactory;
        private readonly IDynamicMenuBuilder _dynamicMenuBuilder;

        public FrontNavAdminFilter(IConfig config, 
                                   IAccessControl accessControl, 
                                   IPerfmonFactory perfmonFactory,
                                   IDynamicMenuBuilder dynamicMenuBuilder)
        {
            _config = config;
            _accessControl = accessControl;
            _perfmonFactory = perfmonFactory;
            _dynamicMenuBuilder = dynamicMenuBuilder;
        }

        public void OnActionExecuting(ActionExecutingContext context)
        {
            // build shared model
            var hostparts = context.HttpContext.Request.Host.Value.Split('.');
            var topLevelDomain = hostparts != null && hostparts.Length > 1
                ? $"{hostparts[hostparts.Length - 2]}.{hostparts[hostparts.Length - 1]}"
                : "frhq";

            var controllerName = context.RouteData.Values["controller"].ToString().ToLower();
            var actionName = context.RouteData.Values["action"].ToString().ToLower();
            var applicationUser = _accessControl.GetCurrentUser();

            var applicationContextViewModel = new ApplicationContextViewModel
            {
                Controller = controllerName,
                Action = actionName,
                CurrentUser = applicationUser,
                TopLevelDomain = topLevelDomain,
                MenuSections = _dynamicMenuBuilder.BuildMenu(),
                MenuItem = GetActiveMenuItem(controllerName, actionName)
            };

            if (context.Controller is Controller controller)
            {
                controller.ViewBag.UseCompiledContent = _config.GetSettingValueOptional<bool>("Build.UseCompiledContent");
                controller.ViewBag.Version = controller.ViewBag.UseCompiledContent ? typeof(Startup).Assembly.GetName().Version.ToString() : (DateTime.Now.Ticks / 100000).ToString();
                controller.ViewBag.applicationContextViewModel = applicationContextViewModel;
            }
        }

        private EnumMenuItem? GetActiveMenuItem(string controllerName, string actionName)
        {
            switch (controllerName.ToLower())
            {
                case "account":
                    switch (actionName)
                    {
                        case "index":
                        case "edit":
                            return EnumMenuItem.Account_List;
                        case "create":
                            return EnumMenuItem.Account_Add;
                        default: return null;
                    }
                default:
                    return null;
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
            if (context.Controller is Controller controller)
            {
                if (_config.GetSettingValueOptional("Perfmon") != null)
                {
                    var perfmon = _perfmonFactory.GetCurrentPerfmon();
                    var perfmonResult = perfmon.GetResults();

                    if (IsAjaxRequest(context.HttpContext))
                    {
                        context.HttpContext.Response.Headers.Add(HttpResponseHeaders.Perfmon, JsonConvert.SerializeObject(perfmonResult));
                    }
                    else
                    {
                        controller.ViewBag.PerfmonResult = perfmonResult;
                    }

                }
            }
        }

        private bool IsAjaxRequest(HttpContext httpContext)
        {
            return httpContext.Request.Headers["x-requested-with"] == "XMLHttpRequest";
        }
    }
}
