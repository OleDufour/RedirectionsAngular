using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;

namespace FnacDarty.Front.WebsiteAdmin.Web.Models
{
    public class ApplicationContextViewModel
    {
        public string Controller { get; set; }
        public string Action { get; set; }
        public string CurrentUserName { get; set; }
        public IFnacDirectFrHqPrincipal CurrentUser { get; set; }
        public string TopLevelDomain { get; set; }

        public EnumMenuItem? MenuItem { get; set; }
        public IEnumerable<MenuSection> MenuSections { get; set; } = new List<MenuSection>();
    }

   
    public enum EnumMenuItem
    {
        
        //Account
        Account_List,
        Account_Add,
    }
}
