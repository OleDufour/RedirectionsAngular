using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Web.Models.Account
{
    public class UserViewModel
    {
        public Guid? UserId { get; set; }

        [Required(ErrorMessageResourceName = "app_admin_user_mondatory",ErrorMessageResourceType = typeof(Resources.Global))]
        [Display(Name = "app_admin_user_account", ResourceType = typeof(Resources.Global))]
        public string Login { get; set; }

        [Display(Name = "app_admin_user_isadmin", ResourceType = typeof(Resources.Global))]
        public bool IsAdmin { get; set; }

        public List<int?> UserRoles { get; set; }

        public List<RefData> Roles { get; set; }
    }

    public class RefData
    {
        public int Id { get; set; }
        public string Value { get; set; }
    }
}
