using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Web.Models.Account;

namespace FnacDarty.Front.WebsiteAdmin.Web.Mapper.Account
{
    public class UserViewModelMapper : DtoModelMapperBase<User, UserViewModel>
    {
        public override UserViewModel DtoToModel(User dto)
        {
            return new UserViewModel()
            {
                UserId = dto.UserId,
                Login = dto.Login,
                IsAdmin = dto.IsAdmin,
                UserRoles = dto.Roles?.Select(r => (int?)r.RoleId).ToList() ?? new List<int?>()
            };

        }

        public override User ModelToDto(UserViewModel viewModel)
        {
            return new User()
            {
                UserId = viewModel.UserId ?? Guid.NewGuid(),
                Login = viewModel.Login,
                IsAdmin = viewModel.IsAdmin,
                Roles = viewModel.UserRoles?.Where(r=> r.HasValue).Select(r => new Role()
                {
                    RoleId = r.Value,
                    RoleName = ((EnumUserRole)r).ToString()
                }).ToList() ?? new List<Role>()
            };
        }
    }
}
