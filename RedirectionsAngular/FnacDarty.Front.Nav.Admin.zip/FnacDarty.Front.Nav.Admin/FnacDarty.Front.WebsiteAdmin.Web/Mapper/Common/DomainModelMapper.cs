using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;

namespace FnacDarty.Front.WebsiteAdmin.Web.Mapper.Common
{
    public class DomainModelMapper : DtoModelMapperBase<Domain, DomainModel>
    {
        public override DomainModel DtoToModel(Domain dto)
        {
            return new DomainModel()
            {
                DomainId = dto.DomainId,
                CultureCode = dto.CultureCode,
                SiteCode = dto.SiteCode,
                DomainCode = dto.DomainCode,
            };
        }

        public override Domain ModelToDto(DomainModel viewModel)
        {
            return new Domain()
            {
                DomainId = (short)viewModel.DomainId,
                CultureCode = viewModel.CultureCode,
                SiteCode = viewModel.SiteCode,
                DomainCode = viewModel.DomainCode,
            };
        }
    }
}
