define(["jquery", "core", "Vue"],
    function ($, core, Vue) {

        let inputCounterComponent = Vue.component('input-counter', {
            props: {
                limit: {
                    type: Number,
                    required: false,
                    default: 160
                },
                input: {
                    type: String,
                    required: true
                }
            },
            template:'<div class="input-group-addon" v-text="(limit - inputLength)"></div>',
            computed: {
                inputLength: function () {
                    return (this.input == undefined) ? 0 : this.input.length;
                },
                limiterClass: function () {
                    if (this.input === undefined || this.input === null) {
                        return 'text-muted';
                    }

                    if (this.input.length >= this.limit) {
                        return 'text-danger';
                    }                   

                    return 'text-success';
                }
            }
        });

        // module definition
        return inputCounterComponent;
    });