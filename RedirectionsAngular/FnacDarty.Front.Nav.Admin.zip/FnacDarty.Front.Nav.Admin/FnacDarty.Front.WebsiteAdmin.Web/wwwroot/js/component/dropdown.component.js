define(["jquery", "core", "template", "Vue"],
  function ($, core, template, Vue) {
    let dropdownComponent = Vue.component('dropdown', {
      template: `<div class="dropdown">
                  <button  v-on:click="toggleMenu()"  v-if="selectedOption != null" :disabled="inactive"
                          class="btn btn-secondary dropdown-toggle btn-block" type="button" data-toggle="dropdown">
                      {{ selectedOption.name }}
                      <span class="caret"></span>
                  </button>
                  <button v-on:click="toggleMenu()"  v-if="selectedOption == null" :disabled="inactive"
                          class="btn btn-secondary dropdown-toggle btn-block" type="button" data-toggle="dropdown">
                      {{ placeholderText }}
                      <span class="caret"></span>
                  </button>
                  <ul class="dropdown-menu">
                      <li v-for="option in options">
                          <a href="javascript:void(0)" v-on:click="updateOption(option)">
                                {{ option.name }}
                          </a>
                      </li>
                  </ul>
                </div>`,
      data() {
        return {
          selectedOption: {},
          showMenu: true,
          placeholderText: '',
        }
      },

      props: {
        options: {
          type: [Array, Object]
        },
        selected: {},
        placeholder: [String],
        inactive: {
            type: Boolean,
            default: false
        }
      },

      mounted() {
        this.selectedOption = this.selected;
        if (this.placeholder) {
            this.placeholderText = this.placeholder;
        }
      },

      methods: {
        updateOption(option) {
          this.selectedOption = option;
          this.showMenu = false;
            this.$emit('updateoption', this.selectedOption); // triggers the v-on:updateoption event in the dropdown element (which is in the .cshtml).
        },

        toggleMenu() {
          this.showMenu = !this.showMenu;
        }
      }
    });

    // module definition
    return dropdownComponent;
  });
