define(["jquery", "core", "template", "Vue"],
    function ($, core, template, Vue) {
        let multipleCheckbox = Vue.component('multiplecheckbox', {

            template: `<div id="multiplecheckbox">{{countSelected}} <span v-html='selected'>{{selected}}</span><div>
                            <br/><div class="btn-group">
                                <div  v-bind:class="getClass()" style="padding-top: 5px;min-width:350px;" 
                                        v-for="item in items">
                                    <input type="checkbox" hidden
				                                class="custom-control-input"
				                                v-model="selectedItems" 
				                                :value="item.value" 
				                                :key="item.value"
                                                :id="item.name"
				                                v-on:change="updateValues()">                                    
                                    <label class="btn btn-primary btn-block" :for="item.name">
	                                  {{ item.name }}
                                    </label>  
                                </div>
                            </div>
                           </div>
                        </div>`,

            data() {
                return {
                    selectedItems: [],
                    countSelected: 0,
                    selected: ''
                };
            },

            props: {
                items: {
                    type: [Array],
                    required: true
                },
                value: {
                    type: [Array]
                },
                inactive: {
                    type: Boolean,
                    default: false
                },
                selected: { type: String }
            },

            mounted() {
                this.selectedItems = this.value || [];
            },
            methods: {
                updateValues() {
                    this.countSelected = this.selectedItems.length;
                    this.$emit('input', this.selectedItems);
                },
                getClass() {                   
                    if (this.items.length === 1)
                        return "col-md-12 col-sm-6 col-lg mt-50";
                    if (this.items.length === 2)
                        return "col-md-6 col-sm-6 col-lg mt-50";
                    return "col-md-4 col-sm-6 col-lg mt-50";
                }
            }
        });

        // module definition
        return multipleCheckbox;
    });
