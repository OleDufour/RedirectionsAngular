define(["Vue"],
    function (Vue) {
      let reportComponent = Vue.component('flat-error-report', {
        template : `
            <table class="base-table">
                <tr class="header">
                    <th>Erreurs</th>
                </tr>
                <tr v-for="error in errors">
                    <td>
                        <ul>
                             {{ error }}
                        </ul>
                    </td>
                </tr>
            </table>
        `,
        props: {
            errors: {
              type: [Array, Object]
            }
        }
    })
    return reportComponent;
});