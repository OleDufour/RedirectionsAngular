
define(
  // module dependencies
  [
    "jquery",
    "bootstrap",
    "jqueryeasing",
    "pace",
    "jqueryperfectscrollbar",
    "jqueryviewportchecker",
    "icheck",
    "datatables",
    "messenger",
    "messengerthemefuture"
  ],

  // module definition
  function (
    $,
    bootstrap,
    jqueryeasing,
    pace,
    jqueryperfectscrollbar,
    jqueryviewportchecker,
    icheck,
    datatables,
    messenger,
    messengerthemefuture
  ) {

    return {

      /*--------------------------------
           Window Based Layout
       --------------------------------*/
      windowBasedLayout: function () {
        var width = window.innerWidth;
        //console.log(width);

        if ($("body").hasClass("chat-open") || $("body").hasClass("sidebar-collapse")) {

          this.mainmenuCollapsed();

        } else if (width < 767) {

          // small window
          $(".page-topbar").addClass("sidebar_shift").removeClass("chat_shift");
          $(".page-sidebar").addClass("collapseit").removeClass("expandit");
          $("#main-content").addClass("sidebar_shift").removeClass("chat_shift");
          $(".page-chatapi").removeClass("showit").addClass("hideit");
          $(".chatapi-windows").removeClass("showit").addClass("hideit");
          this.mainmenuCollapsed();

        } else {

          // large window
          $(".page-topbar").removeClass("sidebar_shift chat_shift");
          $(".page-sidebar").removeClass("collapseit chat_shift");
          $("#main-content").removeClass("sidebar_shift chat_shift");
          this.mainmenuScroll();
        }


      },


      /*--------------------------------
           Window Based Layout
       --------------------------------*/
      onLoadTopBar: function () {

        $(".page-topbar .message-toggle-wrapper").addClass("showopacity");
        $(".page-topbar .notify-toggle-wrapper").addClass("showopacity");
        $(".page-topbar .searchform").addClass("showopacity");
        $(".page-topbar li.profile").addClass("showopacity");
      },

      /*--------------------------------
           Main Menu Scroll
       --------------------------------*/
      mainmenuScroll: function () {

        //console.log("expand scroll menu");

        var topbar = $(".page-topbar").height();
        var projectinfo = $(".project-info").innerHeight();

        var height = window.innerHeight - topbar - projectinfo;

        $('.fixedscroll #main-menu-wrapper').height(height).perfectScrollbar({
          suppressScrollX: true
        });
        $("#main-menu-wrapper .wraplist").height('auto');


        /*show first sub menu of open menu item only - opened after closed*/
        // > in the selector is used to select only immediate elements and not the inner nested elements.
        $("li.open > .sub-menu").attr("style", "display:block;");


      },


      /*--------------------------------
           Collapsed Main Menu
       --------------------------------*/
      mainmenuCollapsed: function () {

        if ($(".page-sidebar.chat_shift #main-menu-wrapper").length > 0 || $(".page-sidebar.collapseit #main-menu-wrapper").length > 0) {
          //console.log("collapse menu");
          var topbar = $(".page-topbar").height();
          var windowheight = window.innerHeight;
          var minheight = windowheight - topbar;
          var fullheight = $(".page-container #main-content .wrapper").height();

          var height = fullheight;

          if (fullheight < minheight) {
            height = minheight;
          }

          $('.fixedscroll #main-menu-wrapper').perfectScrollbar('destroy');

          $('.page-sidebar.chat_shift #main-menu-wrapper .wraplist, .page-sidebar.collapseit #main-menu-wrapper .wraplist').height(height);

          /*hide sub menu of open menu item*/
          $("li.open .sub-menu").attr("style", "");

        }

      },




      /*--------------------------------
           Main Menu
       --------------------------------*/
      mainMenu: function () {
        $('#main-menu-wrapper li a').click(function (e) {

          if ($(this).next().hasClass('sub-menu') === false) {
            return;
          }

          var parent = $(this).parent().parent();
          var sub = $(this).next();

          parent.children('li.open').children('.sub-menu').slideUp(200);
          parent.children('li.open').children('a').children('.arrow').removeClass('open');
          parent.children('li').removeClass('open');

          if (sub.is(":visible")) {
            $(this).find(".arrow").removeClass("open");
            sub.slideUp(200);
          } else {
            $(this).parent().addClass("open");
            $(this).find(".arrow").addClass("open");
            sub.slideDown(200);
          }

        });

        $("body").click(function (e) {
          $(".page-sidebar.collapseit .wraplist li.open .sub-menu").attr("style", "");
          $(".page-sidebar.collapseit .wraplist li.open").removeClass("open");
          $(".page-sidebar.chat_shift .wraplist li.open .sub-menu").attr("style", "");
          $(".page-sidebar.chat_shift .wraplist li.open").removeClass("open");
        });

      },

      /*--------------------------------
           DataTables
       --------------------------------*/
      dataTablesInit: function () {

        if ($.isFunction($.fn.dataTable)) {

          /*--- start ---*/

          $(".dataTable").dataTable({
            responsive: true,
            language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
            aLengthMenu: [
              [10, 25, 50, 100, -1],
              [10, 25, 50, 100, "All"]
            ]
          });

          /*--- end ---*/





          /* Set the defaults for DataTables initialisation */
          $.extend(true, $.fn.dataTable.defaults, {
            "sDom": "<'row'<'col-md-6'l><'col-md-6'f>r>t<'row'<'col-md-12'p i>>",
            "sPaginationType": "bootstrap",
            "oLanguage": {
              "sLengthMenu": "_MENU_"
            }
          });


          /* Default class modification */
          $.extend($.fn.dataTableExt.oStdClasses, {
            "sWrapper": "dataTables_wrapper form-inline"
          });


          /* API method to get paging information */
          $.fn.dataTableExt.oApi.fnPagingInfo = function (oSettings) {
            return {
              "iStart": oSettings._iDisplayStart,
              "iEnd": oSettings.fnDisplayEnd(),
              "iLength": oSettings._iDisplayLength,
              "iTotal": oSettings.fnRecordsTotal(),
              "iFilteredTotal": oSettings.fnRecordsDisplay(),
              "iPage": oSettings._iDisplayLength === -1 ?
                0 : Math.ceil(oSettings._iDisplayStart / oSettings._iDisplayLength),
              "iTotalPages": oSettings._iDisplayLength === -1 ?
                0 : Math.ceil(oSettings.fnRecordsDisplay() / oSettings._iDisplayLength)
            };
          };


          /* Bootstrap style pagination control */
          $.extend($.fn.dataTableExt.oPagination, {
            "bootstrap": {
              "fnInit": function (oSettings, nPaging, fnDraw) {
                var oLang = oSettings.oLanguage.oPaginate;
                var fnClickHandler = function (e) {
                  e.preventDefault();
                  if (oSettings.oApi._fnPageChange(oSettings, e.data.action)) {
                    fnDraw(oSettings);
                  }
                };

                $(nPaging).addClass('').append(
                  '<ul class="pagination pull-right">' +
                  '<li class="prev disabled"><a href="#"><i class="fa fa-angle-double-left"></i></a></li>' +
                  '<li class="next disabled"><a href="#"><i class="fa fa-angle-double-right"></i></a></li>' +
                  '</ul>'
                );
                var els = $('a', nPaging);
                $(els[0]).bind('click.DT', {
                  action: "previous"
                }, fnClickHandler);
                $(els[1]).bind('click.DT', {
                  action: "next"
                }, fnClickHandler);
              },

              "fnUpdate": function (oSettings, fnDraw) {
                var iListLength = 5;
                var oPaging = oSettings.oInstance.fnPagingInfo();
                var an = oSettings.aanFeatures.p;
                var i, ien, j, sClass, iStart, iEnd, iHalf = Math.floor(iListLength / 2);

                if (oPaging.iTotalPages < iListLength) {
                  iStart = 1;
                  iEnd = oPaging.iTotalPages;
                } else if (oPaging.iPage <= iHalf) {
                  iStart = 1;
                  iEnd = iListLength;
                } else if (oPaging.iPage >= (oPaging.iTotalPages - iHalf)) {
                  iStart = oPaging.iTotalPages - iListLength + 1;
                  iEnd = oPaging.iTotalPages;
                } else {
                  iStart = oPaging.iPage - iHalf + 1;
                  iEnd = iStart + iListLength - 1;
                }

                for (i = 0, ien = an.length; i < ien; i++) {
                  // Remove the middle elements
                  $('li:gt(0)', an[i]).filter(':not(:last)').remove();

                  // Add the new list items and their event handlers
                  for (j = iStart; j <= iEnd; j++) {
                    sClass = (j == oPaging.iPage + 1) ? 'class="active"' : '';
                    $('<li ' + sClass + '><a href="#">' + j + '</a></li>')
                      .insertBefore($('li:last', an[i])[0])
                      .bind('click', function (e) {
                        e.preventDefault();
                        oSettings._iDisplayStart = (parseInt($('a', this).text(), 10) - 1) * oPaging.iLength;
                        fnDraw(oSettings);
                      });
                  }

                  // Add / remove disabled classes from the static elements
                  if (oPaging.iPage === 0) {
                    $('li:first', an[i]).addClass('disabled');
                  } else {
                    $('li:first', an[i]).removeClass('disabled');
                  }

                  if (oPaging.iPage === oPaging.iTotalPages - 1 || oPaging.iTotalPages === 0) {
                    $('li:last', an[i]).addClass('disabled');
                  } else {
                    $('li:last', an[i]).removeClass('disabled');
                  }
                }
              }
            }
          });


          /*
           * TableTools Bootstrap compatibility
           * Required TableTools 2.1+
           */
          if ($.fn.DataTable.TableTools) {
            // Set the classes that TableTools uses to something suitable for Bootstrap
            $.extend(true, $.fn.DataTable.TableTools.classes, {
              "container": "DTTT ",
              "buttons": {
                "normal": "btn btn-white",
                "disabled": "disabled"
              },
              "collection": {
                "container": "DTTT_dropdown dropdown-menu",
                "buttons": {
                  "normal": "",
                  "disabled": "disabled"
                }
              },
              "print": {
                "info": "DTTT_print_info modal"
              },
              "select": {
                "row": "active"
              }
            });

            // Have the collection use a bootstrap compatible dropdown
            $.extend(true, $.fn.DataTable.TableTools.DEFAULTS.oTags, {
              "collection": {
                "container": "ul",
                "button": "li",
                "liner": "a"
              }
            });
          }


          /* Table initialisation */
          $(document).ready(function () {
            var responsiveHelper = undefined;
            var breakpointDefinition = {
              tablet: 1024,
              phone: 480
            };
            var tableElement = $('#example');

            tableElement.dataTable({
              "sDom": "<'row'<'col-md-6'l T><'col-md-6'f>r>t<'row'<'col-md-12'p i>>",
              "oTableTools": {
                "aButtons": [{
                  "sExtends": "collection",
                  "sButtonText": "<i class='fa fa-cloud-download'></i>",
                  "aButtons": ["csv", "xls", "pdf", "copy"]
                }]
              },
              "sPaginationType": "bootstrap",
              "aoColumnDefs": [{
                'bSortable': false,
                'aTargets': [0]
              }],
              "aaSorting": [
                [1, "asc"]
              ],
              "oLanguage": {
                "sLengthMenu": "_MENU_ ",
                "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries"
              },
              bAutoWidth: false,
              fnPreDrawCallback: function () {
                // Initialize the responsive datatables helper once.
                if (!responsiveHelper) {
                  //responsiveHelper = new ResponsiveDatatablesHelper(tableElement, breakpointDefinition);
                }
              },
              fnRowCallback: function (nRow) {
                //responsiveHelper.createExpandIcon(nRow);
              },
              fnDrawCallback: function (oSettings) {
                //responsiveHelper.respond();
              }
            });

            $('#example_wrapper .dataTables_filter input').addClass("input-medium "); // modify table search input
            $('#example_wrapper .dataTables_length select').addClass("select2-wrapper"); // modify table per page dropdown



            $('#example input').click(function () {
              $(this).parent().parent().parent().toggleClass('row_selected');
            });


            /*
             * Insert a 'details' column to the table
             */
            var nCloneTh = document.createElement('th');
            var nCloneTd = document.createElement('td');
            nCloneTd.innerHTML = '<i class="fa fa-plus-circle"></i>';
            nCloneTd.className = "center";

            $('#example2 thead tr').each(function () {
              this.insertBefore(nCloneTh, this.childNodes[0]);
            });

            $('#example2 tbody tr').each(function () {
              this.insertBefore(nCloneTd.cloneNode(true), this.childNodes[0]);
            });

            /*
             * Initialse DataTables, with no sorting on the 'details' column
             */
            var oTable = $('#example2').dataTable({
              "sDom": "<'row'<'col-md-6'l><'col-md-6'f>r>t<'row'<'col-md-12'p i>>",
              "aaSorting": [],
              "oLanguage": {
                "sLengthMenu": "_MENU_ ",
                "sInfo": "Showing _START_ to _END_ of _TOTAL_ entries"
              },
            });


            $("div.toolbar").html('<div class="table-tools-actions"><button class="btn btn-primary" style="margin-left:12px" id="test2">Add</button></div>');


            $('#example2_wrapper .dataTables_filter input').addClass("input-medium ");
            $('#example2_wrapper .dataTables_length select').addClass("select2-wrapper");

            /* Add event listener for opening and closing details
             * Note that the indicator for showing which row is open is not controlled by DataTables,
             * rather it is done here
             */
            $('#example2 tbody td i').on('click', function () {
              var nTr = $(this).parents('tr')[0];
              if (oTable.fnIsOpen(nTr)) {
                /* This row is already open - close it */
                this.removeClass = "fa fa-plus-circle";
                this.addClass = "fa fa-minus-circle";
                oTable.fnClose(nTr);
              } else {
                /* Open this row */
                this.removeClass = "fa fa-minus-circle";
                this.addClass = "fa fa-plus-circle";
                oTable.fnOpen(nTr, fnFormatDetails(oTable, nTr), 'details');
              }


              /* Formating function for row details */
              function fnFormatDetails(oTable, nTr) {
                var aData = oTable.fnGetData(nTr);
                var sOut = '<table cellpadding="5" cellspacing="0" border="0" style="padding-left:50px;" class="inner-table">';
                sOut += '<tr><td>Rendering engine:</td><td>' + aData[1] + ' ' + aData[4] + '</td></tr>';
                sOut += '<tr><td>Link to source:</td><td>Could provide a link here</td></tr>';
                sOut += '<tr><td>Extra info:</td><td>And any further details here (images etc)</td></tr>';
                sOut += '</table>';

                return sOut;
              }

            });

          });





        }
      },

      /*--------------------------------
           Tooltips & Popovers
       --------------------------------*/
      tooltipsPopovers: function () {

        $('[rel="tooltip"]').each(function () {

          var animate = $(this).attr("data-animate");
          var colorclass = $(this).attr("data-color-class");
          $(this).tooltip({
            template: '<div class="tooltip ' + animate + ' ' + colorclass + '"><div class="tooltip-arrow"></div><div class="tooltip-inner"></div></div>'
          });
        });

        $('[rel="popover"]').each(function () {
          var animate = $(this).attr("data-animate");
          var colorclass = $(this).attr("data-color-class");
          $(this).popover({
            template: '<div class="popover ' + animate + ' ' + colorclass + '"><div class="arrow"></div><h3 class="popover-title"></h3><div class="popover-content"></div></div>'
          });
        });

      },

        /*--------------------------------
           Top Bar
       --------------------------------*/
       pageTopBar: function () {
        $('.page-topbar li.searchform .input-group-addon').click(function (e) {
          $(this).parent().parent().parent().toggleClass("focus");
          $(this).parent().parent().find("input").focus();
        });

        $('.page-topbar li .dropdown-menu .list').perfectScrollbar({
          suppressScrollX: true
        });

      },

            /*--------------------------------
          Viewport Checker
       --------------------------------*/
       viewportElement: function () {

        if ($.isFunction($.fn.viewportChecker)) {
          $('.number_counter').viewportChecker({
            classToAdd: 'start_timer',
            offset: 10,
            callbackFunction: function (elem) {
              $('.start_timer:not(.counted)').each(count);
              //$(elem).removeClass('number_counter');
            }
          });

        }

        // start count
        function count(options) {
          var $this = $(this);
          options = $.extend({}, options || {}, $this.data('countToOptions') || {});
          $this.countTo(options).addClass("counted");
        }
      },

      // Element Attribute Helper
      getValue: function ($el, data_var, default_val) {
        if (typeof $el.data(data_var) != 'undefined') {
          return $el.data(data_var);
        }

        return default_val;
      },

      displayLoader: function () {
        $('.loading').removeClass('hide');
      },

      hideLoader: function () {
        $('.loading').addClass('hide');
      },

      showMessage: function (msg, type) {
        Messenger.options = {
          extraClasses: 'messenger-fixed messenger-on-top messenger-on-right',
          theme: 'future'
        };
        Messenger().post({
          message: msg,
          type: type,
          showCloseButton: true
        });
      },

      AjaxModalContent: function (ele) {
        $('#cmpltadminModal').modal('show', { backdrop: 'static' });
        var url = $(ele).attr('data-href');
        $.ajax({
          url: url,
          success: function (response) {
            $('#cmpltadminModal .modal-body').html(response);
          }
        });
      },

        /*--------------------------------
           CHAT API
       --------------------------------*/
       chatAPI: function () {

        var current = this;
        $('.page-topbar .sidebar_toggle').on('click',
          function () {
            var chatarea = $(".page-chatapi");
            var chatwindow = $(".chatapi-windows");
            var topbar = $(".page-topbar");
            var mainarea = $("#main-content");
            var menuarea = $(".page-sidebar");

            if (menuarea.hasClass("collapseit") || menuarea.hasClass("chat_shift")) {
              menuarea.addClass("expandit").removeClass("collapseit").removeClass("chat_shift");
              topbar.removeClass("sidebar_shift").removeClass("chat_shift");
              mainarea.removeClass("sidebar_shift").removeClass("chat_shift");
              chatarea.addClass("hideit").removeClass("showit");
              chatwindow.addClass("hideit").removeClass("showit");
              current.mainmenuScroll();
            } else {
              menuarea.addClass("collapseit").removeClass("expandit").removeClass("chat_shift");
              topbar.addClass("sidebar_shift").removeClass("chat_shift");
              mainarea.addClass("sidebar_shift").removeClass("chat_shift");
              current.mainmenuCollapsed();
            }
          });
      },

      intiJsTemplate: function () {
        this.windowBasedLayout();
        this.mainmenuScroll();
        this.mainMenu();
        this.mainmenuCollapsed();
        this.pageTopBar();
        this.viewportElement();
        this.onLoadTopBar();
        this.tooltipsPopovers();
        this.chatAPI();
      }
    };
  }
);



