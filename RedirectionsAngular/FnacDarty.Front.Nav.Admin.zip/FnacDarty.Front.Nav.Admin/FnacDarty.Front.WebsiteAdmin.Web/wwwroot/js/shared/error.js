var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};

define(["jquery", "core", "template", "datatables", "moment", "messenger"],

  function ($, core, template, datatables, moment, messenger) {

    // module definition
    return {

      ready: function (editSuccess) {

        //common init template js
        template.intiJsTemplate();
      }
    };
  });
