define(
  // module dependencies        
  ["jquery", "core", "template"],

  // module definition
  function ($, core, template) {

    // private Perfmon object
    var Perfmon = function () { };

    Perfmon.LOG_COLOR = "#005e85";

    Perfmon.prototype.data_ = null;

    Perfmon.prototype.init = function () {

      var e_data = $(".perfmon-data");
      this.data_ = core.evalJsonData(e_data[0]);

      if (e_data.length <= 0) {
        core.colorlog(Perfmon.LOG_COLOR, "[perfmon] performance monitor is disabled (which can be enabled using the Perfmon entry in web.config).");
      } else {
        core.colorlog(Perfmon.LOG_COLOR, "[perfmon] performance monitor is enabled.");
      }

    };

    Perfmon.prototype.output = function () {

      if (core.isDefAndNotNull(this.data_) == false)
        return;

      $.each(this.data_, function (i, data) {

        var duration = data["TotalDuration"];

        core.colorlog(Perfmon.LOG_COLOR, "[perfmon] %s | Total %ss", data["Key"], duration);
      });

      $.each(this.data_, function (i, data) {

        $.each(data["EntryList"], function (j, entry) {

          var duration = entry["Duration"];

          core.colorlog(Perfmon.LOG_COLOR, "[perfmon] %s | %s() %ss", entry["Category"], entry["Method"], duration);
        });
      });

    };



    return {

      /**
       * Performs common actions when MVC pages are loaded.
       */
      ready: function () {

        core.colorlog("#006508", "[application] application ready. version = %s", fnacdarty.version);

        // initializes performance monitor for normal requests
        var perfmon = new Perfmon();
        perfmon.init();
        perfmon.output();

        //  initializes performance monitor for ajax requests
        $(document).ajaxComplete(function (event, request, settings) {
          var perfmonResult = request.getResponseHeader('Perfmon');
          if (perfmonResult != undefined) {
            perfmon.data_ = JSON.parse(perfmonResult);
            perfmon.output();
          }
        });

        /*
         * * Gestion des langues
         */
        $(".js-lang").on("click", function () {
          template.displayLoader();
          var langCode = $(this).attr('data-lang');
          $.ajax({
            type: "GET",
            url: fnacdarty.changelangurl + '?lang=' + langCode,
            dataType: "json",
            success: function (data) {
              if (data.Success) {
                setTimeout(() => { location.reload(); }, 500);
              }
            },
            error: function () {
            }
          });
        });

      }
    };
  }
);


