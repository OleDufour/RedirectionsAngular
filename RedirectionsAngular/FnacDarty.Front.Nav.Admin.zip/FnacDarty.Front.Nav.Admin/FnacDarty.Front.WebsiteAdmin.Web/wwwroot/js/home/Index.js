﻿define(["jquery", "core", "template", "datatables"],

    function ($, core, template, datatables) {

        // module definition
        return {

            ready: function () {

                //common init template js
              template.intiJsTemplate();

             
            }
        };
    });
