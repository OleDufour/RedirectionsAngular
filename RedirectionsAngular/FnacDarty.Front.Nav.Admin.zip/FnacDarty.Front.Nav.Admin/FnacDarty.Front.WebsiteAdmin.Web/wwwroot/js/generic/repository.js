var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Generic = fnacdarty.Portal.Repository.Generic || {};

fnacdarty.Portal.Repository.Generic.Get = function (url, callback) {
    $.ajax({
        type: "GET",
        url: url,
        dataType: "json",
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur" });
        }
    });
};
