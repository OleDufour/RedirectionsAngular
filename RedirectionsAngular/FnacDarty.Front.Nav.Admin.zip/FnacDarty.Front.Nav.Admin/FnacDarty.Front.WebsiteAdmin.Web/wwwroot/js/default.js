define(["jquery", "Vue", "core", "template", "datatables", "moment", "messenger"],
    function ($, Vue, core, template, datatables, moment, messenger) {
        return {
            ready: function () {
                moment.locale('fr');
                template.intiJsTemplate();
                template.hideLoader();
                core.log("module ready");
            }
        };
    });
