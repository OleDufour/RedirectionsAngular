define(["jquery", "core", "template"],

    function ($, core, template) {
        return {
            ready: function () {
                template.intiJsTemplate();
            }
        };
    });
