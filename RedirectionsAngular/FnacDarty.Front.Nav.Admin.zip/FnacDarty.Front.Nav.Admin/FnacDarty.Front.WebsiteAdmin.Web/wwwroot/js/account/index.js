define(["jquery", "core", "template"],

  function ($, core, template) {

    // module definition
    return {
      ready: function () {

        //common init template js
        template.intiJsTemplate();

        var $table = $("#accounts");
        
        $table.dataTable({
          order: [[0, "asc"]],
          responsive: true,
          language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
          lengthMenu: [
            [10, 25, 50, 100, -1],
            [10, 25, 50, 100, "Tous"]
          ],
          aoColumnDefs: [
            {
              "aTargets": [1],
              "mRender": function (data, type, full) {
                if (data.toLocaleLowerCase() == "true") {
                  return "<span class='label label-success center-bloc'><i class='fa fa-check'></i></span>";

                }
                return "<span class='label label-danger center-bloc'><i class='fa fa-times'></i></span>";
              }
            },
            {
              width: "50px",
              "aTargets": [3],
              "mRender": function (data, type, full) {
                var result =
                  '<a href="' +
                    fnacdarty.Portal.Repository.Account.EditUrl +
                    '?userId=' + data +
                    '" class="btn btn-xs btn-info"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-original-title="'+fnacdarty.Portal.Repository.Account.Wording.Modify+'" data-placement="top"> <i class="fa fa-pencil"></i></a>' +
                    '&nbsp;&nbsp;<a data-userid="' + data +
                  '" class="btn btn-xs btn-danger js-account-delete"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-original-title="' + fnacdarty.Portal.Repository.Account.Wording.Delete +'" data-placement="top"> <i class="fa fa-trash"></i></a>';

                return result;
              }
            }

          ],
          initComplete: function () {
            template.hideLoader();
            template.tooltipsPopovers();
            addDeleteEvent();

          },
          drawCallback: function (settings) {
            template.tooltipsPopovers();
            addDeleteEvent();
          }
        });

        function addDeleteEvent() {
          //Add click event for anchor
          $(".js-account-delete").unbind("click");
          $(".js-account-delete").click(function (e) {
            var userId = $(this).attr('data-userid');
            var msg = Messenger().post({
              message: fnacdarty.Portal.Repository.Account.Wording.DeleteQuestion,
              type: 'info',
              actions: {
                cancel: {
                  label: fnacdarty.Portal.Repository.Account.Wording.No,
                  action: function () {
                    return msg.update({
                      message: fnacdarty.Portal.Repository.Account.Wording.DeleteCanceled,
                      type: 'success',
                      actions: true,
                      showCloseButton: true
                    });
                  },

                },
                confirm: {
                  label: fnacdarty.Portal.Repository.Account.Wording.Yes,
                  action: function () {
                    fnacdarty.Portal.Repository.Account.Delete(userId,
                      function (response) {
                        if (response.Success) {
                          msg.update({
                            message: response.Message,
                            type: 'success',
                            actions: true,
                            showCloseButton: true
                          });
                          setTimeout(function () { window.top.location = response.Data }, 1000);
                        } else {
                          msg.update({
                            message: response.Message,
                            type: 'error',
                            actions: false,
                            showCloseButton: true
                          });
                        }

                      });
                  }
                }
              }
            });
            return false;
          });
        }

      }
    };
  });
