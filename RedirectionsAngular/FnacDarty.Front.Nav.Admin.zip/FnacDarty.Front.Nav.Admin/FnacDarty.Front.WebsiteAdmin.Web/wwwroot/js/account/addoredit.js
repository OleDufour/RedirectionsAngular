var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Account = fnacdarty.Portal.Repository.Account || {};


define(["jquery", "core", "template", "datatables", "moment", "messenger", "Vue"],

  function ($, core, template, datatables, moment, messenger, Vue) {

    // module definition
    return {
      ready: function (model) {

        model.SelectedRoleId = -1;
        var app = new Vue({
          el: '#main-content',
          data: model,
          mounted() {

            //init common js for template
            template.intiJsTemplate();

          },
          methods:
          {
            save: function () {
              template.displayLoader();
              var vm = this;
              var vmModel = vm._data;
              fnacdarty.Portal.Repository.Account.Save(vmModel,
                function (response) {
                  template.hideLoader();
                  template.showMessage(response.Message, response.Success ? "info" : "error");
                  if (response.Success) {
                    setTimeout(function () {
                      window.top.location = response.Data;
                    }, 1000);
                  }
                });
            },
            addrole: function () {
              var vm = this;
              var vmModel = vm._data;
              if (vmModel.SelectedRoleId == -1) {
                template.showMessage(fnacdarty.Portal.Repository.Account.Wording.ChooseRole, "error");
                return;
              }
              if (vmModel.UserRoles) {
                var found = vmModel.UserRoles.find(function(roleid) {
                  return roleid == vmModel.SelectedRoleId;
                });

                if (found) {
                  template.showMessage(fnacdarty.Portal.Repository.Account.Wording.RoleExist, "error");
                } else {
                  vmModel.UserRoles.push(vmModel.SelectedRoleId);
                  vmModel.SelectedRoleId = -1;
                }
              } else {
                
                vmModel.UserRoles = [vmModel.SelectedRoleId];
                vmModel.SelectedRoleId = -1;
              }

            },
            getroleName: function (roleId) {
              var vm = this;
              var vmModel = vm._data;
              var found = vmModel.Roles.find(function (role) {
                return role.Id == roleId;
              });
              return found.Value;
            },
            deleterole: function (role) {
              var vm = this;
              var vmModel = vm._data;
              vmModel.UserRoles = vmModel.UserRoles.filter(function (item) {
                return item !== role;
              });
            }
          }
        });

        window.app = app;

      }
    };
  });
