var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Account = fnacdarty.Portal.Repository.Account || {};

fnacdarty.Portal.Repository.Account.Save = function (model, callback) {

  $.ajax({
    type: "POST",
    url: fnacdarty.Portal.Repository.Account.SaveUrl,
    dataType: "json",
    data: model,
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : Account.Save" });
    }
  });
};


fnacdarty.Portal.Repository.Account.Delete = function (model, callback) {

  $.ajax({
    type: "GET",
    url: fnacdarty.Portal.Repository.Account.DeleteUrl + "?userId=" + model,
    dataType: "json",
    success: function (data) {
      callback(data);
    },
    error: function () {
      callback({ success: false, message: "Erreur Fatale Serveur : Account.Delete" });
    }
  });
};

