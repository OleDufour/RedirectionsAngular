/*!
 * Description: Provides basic functions used by the infrastructure. 
 *              The file name may conflict with the Core.JS Framework if the later is to be used.
 *              The suggested workaround is to use corejs path for Core.JS Framework in requirejs
 *              configuration.
 * 
 *              Some methods are shamelessly copied from Google Closure library, there is usually
 *              only one implementation possible anyway.
 * Notice     : DO NOT MODIFY UNLESS YOU ARE THE MAINTAINER OF THIS PACKAGE.
 */

define(
    // module dependencies
    ["jquery"],

    // module definition
    function ($) {

        return {

            /**
             * Returns true if the specified value is a string.
             * @param {?} val Variable to test.
             * @return {boolean} Whether variable is a string.
             */
            isString : function(val) {
                return typeof val == 'string';
            },

            /**
             * Returns true if the specified value is a boolean.
             * @param {?} val Variable to test.
             * @return {boolean} Whether variable is boolean.
             */
            isBoolean : function(val) {
                return typeof val == 'boolean';
            },


            /**
             * Returns true if the specified value is a number.
             * @param {?} val Variable to test.
             * @return {boolean} Whether variable is a number.
             */
            isNumber : function(val) {
                return typeof val == 'number';
            },

            /**
             * Returns true if the specified value is an array.
             * @param {?} val Variable to test.
             * @return {boolean} Whether variable is an array.
             */
            isArray : function(val) {
                return goog.typeOf(val) == 'array';
            },

            /**
             * Returns true if the specified value is defined and not null.
             * @param {?} val Variable to test.
             * @return {boolean} Whether variable is defined and not null.
             */
            isDefAndNotNull: function (val) {
                // Note that undefined == null.
                return val != null;
            },


            /**
             * Evaluates a DOM element's content to JSON object.
             * Upon OWASP's recommendation, dynamic JSON data in HTML pages must be escaped and wrapped in a <script> tag to prevent XSS attacks.
             * This method has the correct implementation and should be used.
             * See https://www.owasp.org/index.php/XSS_%28Cross_Site_Scripting%29_Prevention_Cheat_Sheet#JSON_entity_encoding for more information
             * 
             * @param {Element} A Dom Element that provides the JSON data.
             * @return {Object} An object evaluated from the JSON data. null if any error.
             */
            evalJsonData : function(element) {

                try
                {
                    var content = element.textContent || element.innerText;
                    var html = $("<div/>").html(content).text();
                    var data = JSON.parse(html);

                    return data;
                }
                catch (ex)
                {
                    this.log("unable to evaluate json data from element %s", element);

                    return null;
                }
            },


            /**
             * Safe wrapper for browsers' console.log function with css formatting support (Firefox and Chrome).
             * This function will fail silently on browsers that do not have console object or display unstylized text
             * on browser without css formatting support.
             * 
             * @param {String} the color code (for example, "#333", "red", "rgb(12, 12, 12)")
             * @param {...} the variable parameters to be passed to console.log.
             */
            colorlog : function () {

                if (arguments.length < 2)
                    return;

                var color = arguments[0];
                var format = arguments[1];
                var args = [];

                // detect console css support (Modernizr doesn't support this so we have to do it manually)
                var color_support = false;
                
                if (this.isDefAndNotNull(navigator) && this.isDefAndNotNull(navigator.userAgent)) {

                    if (navigator.userAgent.indexOf("Firefox") >= 0 || navigator.userAgent.indexOf("Chrome") >= 0)
                        color_support = true;
                }


                if (color_support == false || this.isString(format) == false) {

                    // the first argument is not a string, cannot format it with style, so try unformatted
                    for (var i = 1; i < arguments.length; i++)
                        args.push(arguments[i]);

                } else {

                    // concatenate the message with style
                    args.push("%c" + format);
                    args.push("color:" + color);

                    for (var i = 2; i < arguments.length; i++)
                        args.push(arguments[i]);
                }

                this.log.apply(this, args);
            },

            /**
             * Safe wrapper for browsers' console.log function.
             * This function will fail silently on browsers that do not have console object.
             */
            log : function () {

                if (this.isDefAndNotNull(console) == false)
                    return;

                if (this.isDefAndNotNull(console.log) == false)
                    return;

                if (this.isDefAndNotNull(console.log.apply) == false) {

                    var log = Function.prototype.bind.call(console.log, console);

                    log.apply(console, arguments);

                } else {

                    console.log.apply(console, arguments);
                }
            }
        };
    }
);

