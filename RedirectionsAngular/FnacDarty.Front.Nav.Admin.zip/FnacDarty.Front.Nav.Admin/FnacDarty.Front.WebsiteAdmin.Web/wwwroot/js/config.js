requirejs.config({
    baseUrl: "/js",
    shim: {
        "bootstrap" : {
            deps: ["jquery"],
            exports: "$.fn.popover"
        },
        "boostrapdatetimepicker" : {
            deps: ['jquery', 'moment']
        },
        "Vue" : {
            exports: "Vue"
        },
        "select2" : {
            deps: ["jquery"],
            exports: "$.fn.select2"
        },
        "messenger" : {
            deps: ["jquery"],
            exports: "Messenger"
        },
        "messengerthemefuture" : {
            deps: ["jquery", "messenger"]
        },
        "jqueryeasing" : {
            deps: ["jquery"]
        },
        "jqueryviewportchecker" : {
            deps: ["jquery"]
        },
        "jqueryperfectscrollbar" : {
            deps: ["jquery"]
        },
        "icheck" : {
            deps: ["jquery"]
        },
        "tinymce" : {
            deps: ["jquery"],
            exports: "tinymce"
        },
        "tinymcevue" : {
            deps: ["tinymce", "Vue"],
            exports: "Editor"
        },
        "vuelidate" : {
            deps: ["Vue"]
        },
        "validators" : {
            deps: ["Vue"]
        },
        "vueUploadComponent" : {
            deps: ["Vue"]
        },
        "vueDataTable" : {
            deps: ["Vue"]
        },
        "datatables" : {
            deps: ['jquery', 'bootstrap']
        },
    },
    paths: {
        "bootstrap" : "../lib/twitter-bootstrap/js/bootstrap.min",
        "boostrapdatetimepicker" : "../lib/bootstrap-datetimepicker/js/bootstrap-datetimepicker.min",
        "moment" : "../lib/moment.js/moment-with-locales.min",
        "jquery" : "../lib/jquery/jquery.min",
        "jqueryeasing" : "../lib/jquery-easing/jquery.easing.min",
        "jqueryperfectscrollbar" : "../lib/jquery.perfect-scrollbar/js/perfect-scrollbar.jquery.min",
        "jqueryviewportchecker" : "../lib/jQuery-viewport-checker/jquery.viewportchecker.min",
        "pace" : "../lib/pace/pace.min",
        "icheck" : "../lib/iCheck/icheck.min",
        "datatables.net" : "../lib/datatables/js/jquery.datatables.min",
        "datatables": "../lib/datatables/js/datatables.bootstrap.min",
        "tinymce" : "../lib/tinymce/tinymce.min",
        "tinymcevue" : "../lib/tinymce-vue/lib/browser/tinymce-vue.min",
        "Vue" : "../lib/vue/vue.min",
        "vuelidate" : "../lib/vuelidate/dist/vuelidate.min",
        "validators" : "../lib/vuelidate/dist/validators.min",
        "select2" : "../lib/select2/js/select2.min",
        "messenger" : "../lib/messenger/js/messenger.min",
        "messengerthemefuture" : "../lib/messenger/js/messenger-theme-future.min",
        "dropdownComponent" : "component/dropdown.component",
        "urlRewriteHistoryComponent": "component/urlrewrite.history.component",
        "urlRewritePublicationDetailsComponent": "component/urlrewrite.publicationdetails.component",
        "redirectHistoryComponent": "component/redirect.history.component",
        "redirectPublicationDetailsComponent": "component/redirect.publicationdetails.component",
        "core" : "core",
        "template" : "template",
        "inputCounterComponent" : "component/input.counter.component",
        "multipleCheckboxComponent" : "component/multiple.checkbox.component",
        "redirectImportReport" : "component/redirect.import.report.component",
        "flatErrorReport": "component/flat.error.report.component",
        "vueUploadComponent" : "../lib/vue-upload-component/dist/vue-upload-component",
        "vueTabsComponent" : "../lib/vue-tabs-component/dist/index",
        "vueSpinnerComponent" : "../lib/vue-spinner/dist/vue-spinner"
    }
});