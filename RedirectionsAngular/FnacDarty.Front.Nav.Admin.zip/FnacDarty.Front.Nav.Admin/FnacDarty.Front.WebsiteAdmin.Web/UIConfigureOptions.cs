﻿using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Options;

namespace FnacDarty.Front.WebsiteAdmin.Web
{
    public class UIConfigureOptions : IPostConfigureOptions<StaticFileOptions>
    {
        private readonly IHostingEnvironment _hostingEnvironment;
        private readonly IEnumerable<ModuleRegistrationBase> _modules;

        public UIConfigureOptions(IHostingEnvironment hostingEnvironment,
                                  IEnumerable<ModuleRegistrationBase> modules)
        {
            _hostingEnvironment = hostingEnvironment;
            _modules = modules;
        }

        public void PostConfigure(string name, StaticFileOptions options)
        {
            name = name ?? throw new ArgumentNullException(nameof(name));
            options = options ?? throw new ArgumentNullException(nameof(options));

            // Basic initialization in case the options weren't initialized by any other component
            options.ContentTypeProvider = options.ContentTypeProvider ?? new FileExtensionContentTypeProvider();
            if (options.FileProvider == null && _hostingEnvironment.WebRootFileProvider == null)
            {
                throw new InvalidOperationException("Missing FileProvider.");
            }

            options.FileProvider = options.FileProvider ?? _hostingEnvironment.WebRootFileProvider;

            var basePath = "wwwroot";

            var fileProviders = new List<Microsoft.Extensions.FileProviders.IFileProvider>
            {
                options.FileProvider
            };

            foreach(var module in _modules)
            {
                try
                {
                    fileProviders.Add(new Microsoft.Extensions.FileProviders.ManifestEmbeddedFileProvider(module.GetType().Assembly, basePath));
                }
                catch
                {
                    // If module doesn't expose any static embedded content, an exception might be thrown here
                }
            }

            options.FileProvider = new Microsoft.Extensions.FileProviders.CompositeFileProvider(fileProviders);
        }
    }
}
