using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Helper
{
    public interface IRedirectHelper
    {
        DataTransfer.Redirect GetValidDto(RedirectModel record, List<DataTransfer.Redirect> redirects);
    }
}
