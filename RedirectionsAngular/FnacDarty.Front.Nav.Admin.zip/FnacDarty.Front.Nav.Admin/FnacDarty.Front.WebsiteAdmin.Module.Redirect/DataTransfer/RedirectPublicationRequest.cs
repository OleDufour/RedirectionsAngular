using System;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer
{
    public class RedirectPublicationRequest
    {
        public int PublicationRequestId { get; set; }
        public DateTime PublicationRequestDate { get; set; }
        public string PublicationRequestUser { get; set; }

        public int DomainId { get; set; }
    }
}
