using System;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer
{
    public class RedirectHistory : ICloneable
    {
        public int RedirectId { get; set; }

        [Required]
        public short TargetType { get; set; }

        [Required]
        [StringLength(2048)]
        public string Target { get; set; }

        [Required]
        public short SourceType { get; set; }

        [Required]
        [StringLength(2048)]
        public string Source { get; set; }

        [Required]
        public DateTime CreationDate { get; set; }

        [Required]
        [StringLength(200)]
        public string CreationUser { get; set; }


        public short RedirectType { get; set; }

        public int? PublicationRequestId { get; set; }

        public DateTime? PublicationRequestDate { get; set; }

        public string PublicationRequestUser { get; set; }

        public short ActionTypeId { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
