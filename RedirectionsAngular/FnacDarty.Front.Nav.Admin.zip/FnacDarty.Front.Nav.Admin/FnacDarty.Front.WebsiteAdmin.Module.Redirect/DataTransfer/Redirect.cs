using System;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer
{
    public class Redirect : ICloneable
    {
        public int? RedirectId { get; set; }

        [Required]
        public short DomainId { get; set; }

        [Required]
        public short TargetType { get; set; }

        public string TargetTypeString { get; set; }

        [Required]
        [StringLength(2048)]
        public string Target { get; set; }

        [Required]
        public short SourceType { get; set; }

        public string SourceTypeString { get; set; }

        [Required]
        [StringLength(2048)]
        public string Source { get; set; }

        [Required]
        public DateTime CreationDate { get; set; }

        [Required]
        [StringLength(200)]
        public string CreationUser { get; set; }

        [Required]
        public DateTime? DeletionDate { get; set; }

        [Required]
        [StringLength(200)]
        public string DeletionUser { get; set; }

        public DateTime? ModificationDate { get; set; }

        [StringLength(200)]
        public string ModificationUser { get; set; }

        public short RedirectType { get; set; }

        public string RedirectTypeString { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }


    public class RedirectPaging : Redirect
    {
        /// <summary>
        /// Number of redirects to display when paging
        /// </summary>
        public int PageSize { get; set; }
        public int PageNo { get; set; }

        public string OrderByColumn { get; set; }
        public string AscOrDesc { get; set; }

        public bool IncludeDeletions { get; set; }
    }
}
