using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Serialization;
using FnacDarty.Front.WebsiteAdmin.Constant;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer
{
    /// <summary>
    /// Used for xml serialization
    /// </summary>

    [XmlType("urlRedirect")]
    public class RedirectXmlModelList
    {
        [XmlArray(ElementName = "rules")]
        public List<RedirectXmlModel> Redirects { get; set; }
        public RedirectXmlModelList(IEnumerable<Redirect> redirects)
        {
            Redirects = new List<RedirectXmlModel>();
            Redirects.AddRange(
                redirects.Select(x => new RedirectXmlModel
                {
                    Source = x.Source,
                    Target = x.Target,
                    SourceType = (EnumSourceTypeTargetType)x.SourceType,
                    TargetType = (EnumSourceTypeTargetType)x.TargetType,
                    RedirectType = (EnumRedirectType)x.RedirectType
                })
            );
        }

        /// <summary>
        ///  Pour sérializer en .NET on a besoin d'un constructeur vide. Demande pas pourquoi.
        /// </summary>
        public RedirectXmlModelList() { }
    }

    [XmlType("redirect")]
    public class RedirectXmlModel
    {
        [XmlAttribute(AttributeName = "source")]
        public string Source { get; set; }

        [XmlAttribute(AttributeName = "target")]
        public string Target { get; set; }

        [XmlIgnore]
        public EnumSourceTypeTargetType? SourceType { get; set; }

        [XmlAttribute(AttributeName = "sourcetype")]
        public string SourceTypeString
        {
            get => ((EnumSourceTypeTargetType)SourceType).ToString();
            // On a besoin d'un setter pour sérializer. Demande pas pourquoi. Il n'est jamais appelé. 
            set => throw new NotImplementedException();
        }

        [XmlIgnore]
        public EnumSourceTypeTargetType? TargetType { get; set; }


        [XmlAttribute(AttributeName = "targettype")]
        public string TargetTypeString
        {
            get => ((EnumSourceTypeTargetType)TargetType).ToString();
            // On a besoin d'un setter pour sérializer. Demande pas pourquoi. Il n'est jamais appelé. 
            set => throw new NotImplementedException();
        }

        [XmlIgnore]
        public EnumRedirectType? RedirectType { get; set; }

        [XmlAttribute(AttributeName = "httpcode")]
        public string RedirectTypeString
        {
            get => ((EnumRedirectType)RedirectType).ToString();
            // On a besoin d'un setter pour sérializer. Demande pas pourquoi. Il n'est jamais appelé. 
            set => throw new NotImplementedException();
        }
    }
}
