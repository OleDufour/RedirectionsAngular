namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer
{
    public class PublicationRequestCriteria
    {
        public int DomainId { get; set; }

        public int? EnvId { get; set; }
    }
}
