using System.Collections.Generic;
using System.Data.SqlClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public class RedirectHistoryRepository : BaseRepository, IRedirectHistoryRepository
    {

        private readonly IDbConnectionFactory dbConnectionFactory;

        internal static readonly string GetRedirectHistorySp = "seo.sp_GetRedirectHistoryItems";
        internal static readonly string AddRedirectHistorySp = "seo.sp_AddRedirectHistory";
        internal static readonly string AddPublicationInfosToRedirectHistorySp = "seo.sp_UpdateRedirectPublicationHistory";

        public RedirectHistoryRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger,config, perfmonFactory, dbConnectionFactory)
        {
            this.dbConnectionFactory = dbConnectionFactory;
        }

        public int AddRedirectHistory(RedirectHistory redirect)
        {
            return ExecuteScalar<int>(AddRedirectHistorySp, new Dictionary<string, object>
            {
                {"RedirectId", redirect.RedirectId},
                {"TargetType", redirect.TargetType},
                {"Target", redirect.Target},
                {"SourceType", redirect.SourceType},
                {"Source", redirect.Source},
                {"RedirectType", redirect.RedirectType },
                {"CreationDate", redirect.CreationDate},
                {"CreationUser", redirect.CreationUser},
                {"ActionTypeId", redirect.ActionTypeId},
            });
        }

        public bool AddPublicationInfosToHistory(int domainId, int publicationRequestId)
        {

            using (var connection = dbConnectionFactory.CreateConnection())
            {
                // using specific type from Sql Server, is not testable at the moment
                var cmd = (SqlCommand)CreateCommand(AddPublicationInfosToRedirectHistorySp, connection, new Dictionary<string, object>
                {
                    {"DomainId", domainId},
                    {"PublicationRequestId", publicationRequestId}
                });

                return ExecuteNonQuery(AddPublicationInfosToRedirectHistorySp, cmd) > 0;
            }
        }


        public IEnumerable<RedirectHistory> GetRedirectHistory(int redirectId)
        {
            return ExecuteSelect<RedirectHistory>(GetRedirectHistorySp, new Dictionary<string, object>
            {
                {"RedirectId", redirectId}
            });
        }
    }
}
