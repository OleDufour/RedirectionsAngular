using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public class RedirectPublicationRequestRepository : BaseRepository, IRedirectPublicationRequestRepository
    {
        internal static readonly string AddRedirectPublicationRequestSp = "seo.sp_AddRedirectPublicationRequest";
        internal static readonly string AddPreviewRedirectPublicationRequestSp = "seo.sp_AddPreviewRedirectPublicationRequest";
        internal static readonly string GetRedirectPublicationRequestSp = "seo.sp_GetRedirectPublicationRequest";
        internal static readonly string GetRedirectPublicationRequestDetailsSp = "seo.sp_GetRedirectPublicationRequestDetails";
        


        public RedirectPublicationRequestRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
        }

        public int AddPublicationRequest(int domainId, DateTime publicationDate, string publicationUser, bool isProduction)
        {
            var procedureName = isProduction
                ? AddRedirectPublicationRequestSp
                : AddPreviewRedirectPublicationRequestSp;

            return ExecuteScalar<int>(procedureName, new Dictionary<string, object>
            {
                {"DomainId", domainId},
                {"PublicationDate", publicationDate},
                {"PublicationUser", publicationUser}
            });
        }

        public IEnumerable<RedirectPublicationRequest> GetPublicationRequest(PublicationRequestCriteria criteria)
        {
            if (criteria == null)
            {
                throw new ArgumentNullException(nameof(criteria));
            }

            return ExecuteSelect<RedirectPublicationRequest>(GetRedirectPublicationRequestSp, new Dictionary<string, object>()
            {
                {"DomainId", criteria.DomainId}
            });
        }

        public IEnumerable<RedirectHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId)
        {
            return ExecuteSelect<RedirectHistory>(GetRedirectPublicationRequestDetailsSp, new Dictionary<string, object>()
            {
                {"PublicationRequestId", publicationRequestId},
                {"DomainId", domainId},

            });
        }
    }
}
