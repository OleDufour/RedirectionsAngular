using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public class RedirectRepository : BaseRepository, IRedirectRepository
    {
      
        internal static readonly string AddRedirectSp = "seo.sp_AddRedirect";
        internal static readonly string GetRedirectsSp = "seo.sp_GetRedirects";
        internal static readonly string GetRedirectByIdSp = "seo.sp_GetRedirectById";
        internal static readonly string UpdateRedirectSp = "seo.sp_UpdateRedirect";
        internal static readonly string DeleteRedirectSp = "seo.sp_UpdateToDeleteRedirect";
        internal static readonly string GetDuplicatesSp = "seo.sp_GetRedirectDuplicate";
        internal static readonly string GetCascadesSp = "seo.sp_GetCascadeRedirects";
        internal static readonly string GetPublishedRedirectsSp = "seo.sp_GetPublishedRedirects";
        internal static readonly string GetDraftRedirectsSp = "seo.sp_GetDraftRedirects";
        internal static readonly string GetRedirectsForPagingSp = "seo.sp_GetRedirectsForPaging";


        public RedirectRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger, config, perfmonFactory, dbConnectionFactory)
        {
        }

 

        /// <summary>
        /// Inserts a new redirect in the Redirect table
        /// </summary>
        /// <param name="redirect"></param>
        /// <returns></returns>
        public int AddRedirect(DataTransfer.Redirect redirect)
        {
            CheckForValidity(redirect);

            return ExecuteScalar<int>(AddRedirectSp, new Dictionary<string, object>
            {
                {"DomainId", redirect.DomainId},
                {"SourceType", redirect.SourceType},
                {"Source", redirect.Source},
                {"TargetType", redirect.TargetType},
                {"Target", redirect.Target},
                {"CreationDate", redirect.CreationDate},
                {"CreationUser", redirect.CreationUser},
                {"RedirectType", redirect.RedirectType}
            });
        }

        public IEnumerable<DataTransfer.Redirect> GetRedirects(int domainId)
        {
            return ExecuteSelect<DataTransfer.Redirect>(GetRedirectsSp, new Dictionary<string, object>
            {
                {"DomainId", domainId}
            });
        }

        public IEnumerable<DataTransfer.Redirect> GetRedirectsForPaging(RedirectPaging r, out int filteredCount, out int totalCount)
        {
            using (var cnx = CreateConnection())
            {
                var cmd = CreateCommand(GetRedirectsForPagingSp, cnx);
                CreateParameter(cmd, "DomainId", r.DomainId);
                CreateParameter(cmd, "SourceType", r.SourceType);
                CreateParameter(cmd, "Source", r.Source);
                CreateParameter(cmd, "TargetType", r.TargetType);
                CreateParameter(cmd, "Target", r.Target);
                CreateParameter(cmd, "RedirectType", r.RedirectType);
                CreateParameter(cmd, "PageSize", r.PageSize);
                CreateParameter(cmd, "PageNo", r.PageNo);
                CreateParameter(cmd, "OrderByColumn", r.OrderByColumn);
                CreateParameter(cmd, "AscOrDesc", r.AscOrDesc);
                CreateParameter(cmd, "IncludeDeletions", r.IncludeDeletions);
                var filteredCountParam = CreateOutPutParameter(cmd, "RecordCount", DbType.Int32);
                var totalCountParam = CreateOutPutParameter(cmd, "TotalRecordCount", DbType.Int32);
                var res = ExecuteSelect<DataTransfer.Redirect>(cmd);
                filteredCount = GetOutPutIntParameter(filteredCountParam);
                totalCount = GetOutPutIntParameter(totalCountParam);
                return res;
            }
        }

        private static int GetOutPutIntParameter(IDbDataParameter intParam)
        {
            int res = 0;
            if (intParam.Value != DBNull.Value)
                res = Convert.ToInt32(intParam.Value);
            return res;
        }

        public DataTransfer.Redirect GetRedirectById (int redirectId)
        {
            // ExecuteFirstOrDefault pour gérer les redirections qui n'existent plus. 
            return ExecuteFirstOrDefault<DataTransfer.Redirect>(GetRedirectByIdSp, new Dictionary<string, object>
            {
                {"RedirectId",redirectId }
            });
        }

        public bool UpdateRedirect(DataTransfer.Redirect redirect)
        {
            CheckForValidity(redirect);
            return ExecuteNonQuery(UpdateRedirectSp, new Dictionary<string, object>
            {
                {"RedirectId", redirect.RedirectId},
                {"DomainId", redirect.DomainId},
                {"SourceType", redirect.SourceType},
                {"Source", redirect.Source},
                {"TargetType", redirect.TargetType},
                {"Target", redirect.Target},
                {"ModificationDate", redirect.ModificationDate},
                {"ModificationUser", redirect.ModificationUser},
                {"RedirectType", redirect.RedirectType}
            }) > 0;
        }

        /// <summary>
        /// Updates the deletion date to current date time rather than deleting the record.
        /// </summary>
        /// <param name="redirect"></param>
        /// <returns></returns>
        public bool DeleteRedirect(DataTransfer.Redirect redirect) => ExecuteNonQuery(DeleteRedirectSp, new Dictionary<string, object>
            {
                {"RedirectId", redirect.RedirectId},
                {"DeletionDate", redirect.DeletionDate},
                {"DeletionUser", redirect.DeletionUser}
            }) > 0;

        public IEnumerable<DataTransfer.Redirect> GetDuplicates(DataTransfer.Redirect redirect) => ExecuteSelect<DataTransfer.Redirect>(GetDuplicatesSp, new Dictionary<string, object>
            {
                {"DomainId", redirect.DomainId},
                {"Source", redirect.Source},
                {"SourceType", redirect.SourceType},
                {"RedirectId", redirect.RedirectId??0}
            });

        public IEnumerable<DataTransfer.Redirect> GetCascades(DataTransfer.Redirect redirect) => ExecuteSelect<DataTransfer.Redirect>(GetCascadesSp, new Dictionary<string, object>
            {
                {"DomainId", redirect.DomainId},
                {"Source", redirect.Source},
                {"SourceType", redirect.SourceType},
                {"Target", redirect.Target},
                {"TargetType", redirect.TargetType}
            });

        public IEnumerable<DataTransfer.Redirect> GetRedirectsToPublish(short domainId)
        {
            return ExecuteSelect<DataTransfer.Redirect>(GetPublishedRedirectsSp, new Dictionary<string, object>
            {
                {"DomainId", domainId}
            });
        }

        public void CheckForValidity(DataTransfer.Redirect redirect)
        {
            if (GetDuplicates(redirect).Any())
            {
                throw new DuplicateException();
            }
            if (GetCascades(redirect).Any())
            {
                throw new CascadeException();
            }
        }

        public IEnumerable<RedirectHistory> GetDraftRedirect(int domainId)
        {
            return ExecuteSelect<RedirectHistory>(GetDraftRedirectsSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId}
            });
        }
    }
}
