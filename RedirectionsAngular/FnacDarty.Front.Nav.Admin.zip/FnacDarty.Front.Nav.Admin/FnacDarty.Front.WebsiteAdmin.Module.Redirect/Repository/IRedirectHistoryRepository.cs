using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public interface IRedirectHistoryRepository
    {
        IEnumerable<RedirectHistory> GetRedirectHistory(int RedirectId);
        int AddRedirectHistory(RedirectHistory redirect);
        bool AddPublicationInfosToHistory(int DomainId, int publicationRequestId);
    }
}
