using System;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public interface IRedirectPublicationRepository
    {
        RedirectPublicationRequest GetCurrentRedirectPublicationForDomain(int domainId);
        int AddPublicationRequest( int domain, DateTime dt, string user, bool isProduction);
        bool PublishRedirect(int publicationRequestId, int domainId, bool isProduction);
    }
}
