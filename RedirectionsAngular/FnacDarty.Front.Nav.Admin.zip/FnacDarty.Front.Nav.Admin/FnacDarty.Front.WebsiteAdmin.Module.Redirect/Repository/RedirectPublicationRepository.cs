using System;
using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public class RedirectPublicationRepository : BaseRepository, IRedirectPublicationRepository
    {
        internal static readonly string PublishRedirectForDomainSp = "seo.sp_PublishDomainRedirects";
        internal static readonly string PublishPreviewRedirectForDomainSp = "seo.sp_PublishPreviewDomainRedirects";
        internal static readonly string AddRedirectPublicationRequestSp = "seo.sp_AddRedirectPublicationRequest";
        internal static readonly string AddPreviewRedirectPublicationRequestSp = "seo.sp_AddPreviewRedirectPublicationRequest";
        internal static readonly string GetCurrentRedirectPublicationForDomainSp = "seo.sp_GetCurrentRedirectPublication";




        public RedirectPublicationRepository(ILogger logger, IConfig config, IPerfmonFactory perfmonFactory, IDbConnectionFactory dbConnectionFactory)
            : base(logger,config, perfmonFactory, dbConnectionFactory)
        {
        }

        /// <summary>
        /// <para>1) Effectue un Delete from publishedRedirect pour la domaine en cours </para>
        /// <para>2) Effectue un Insert dans la table PublishedRedirect avec tous les non deleted redirects pour la domaine en cours</para>
        /// <para>3) Effectue un Update des détails de la publication dans la table RedirectHistory pour chaque dernière version de chaque redirect</para>
        /// </summary>
        /// <param name="publicationRequestId"></param>
        /// <param name="domainId"></param>
        /// <param name="isProduction"></param>
        /// <returns></returns>
        public bool PublishRedirect(int publicationRequestId, int domainId, bool isProduction)
        {
            var procedureName = isProduction
                    ? PublishRedirectForDomainSp
                    : PublishPreviewRedirectForDomainSp;

            return ExecuteNonQuery(procedureName, new Dictionary<string, object>
            {
                {"PublicationRequestId", publicationRequestId},
                {"DomainId", domainId}
            }) > 0;
        }

        public int AddPublicationRequest(int domainId, DateTime publicationDate, string publicationUser, bool isProduction)
        {
            var procedureName = isProduction
                    ? AddRedirectPublicationRequestSp
                    : AddPreviewRedirectPublicationRequestSp;

            return ExecuteScalar<int>(procedureName, new Dictionary<string, object>
            {
                {"DomainId", domainId},
                {"PublicationDate", publicationDate},
                {"PublicationUser", publicationUser}
            });
        }

        public RedirectPublicationRequest GetCurrentRedirectPublicationForDomain(int domainId)
        {
            return ExecuteFirstOrDefault<RedirectPublicationRequest>(GetCurrentRedirectPublicationForDomainSp, new Dictionary<string, object>()
            {
                {"DomainId", domainId}
            });
        }

        public int AddPublicationRequest(int domain, DateTime dt, string user, EnumEnv env)
        {
            throw new NotImplementedException();
        }

        public bool PublishRedirect(int publicationRequestId, int domainId, DateTime publicationDate, string publicationUser)
        {
            return ExecuteNonQuery(PublishRedirectForDomainSp, new Dictionary<string, object>()
            {
                {"PublicationRequestId", publicationRequestId},
                {"DomainId", domainId}
            }) > 0;
        }

    }
}
