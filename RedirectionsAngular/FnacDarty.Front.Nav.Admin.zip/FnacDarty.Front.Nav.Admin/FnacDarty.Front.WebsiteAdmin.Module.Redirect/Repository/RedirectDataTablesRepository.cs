using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public class RedirectDataTablesRepository : BaseDataTablesRepository<DataTransfer.Redirect>
    {
        public RedirectDataTablesRepository(IDbConnectionFactory dbConnectionFactory) : base(dbConnectionFactory) { }

        public override string TableName => "seo.Redirect";

        public override string ConnectionString { get; }

        public override Dictionary<string, string> ColumnNameMapping => new Dictionary<string, string>()
        {
            { "RedirectId", "RedirectId" },
            { "SourceTypeString", "SourceType" },
            { "Source", "Source" },
            { "TargetTypeString", "TargetType" },
            { "Target", "Target" },
            { "RedirectTypeString", "RedirectType" }
        };
    }
}
