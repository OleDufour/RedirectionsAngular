using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public interface IRedirectRepository
    {
        IEnumerable<DataTransfer.Redirect> GetRedirects(int domainId);
        int AddRedirect(DataTransfer.Redirect redirect);

        DataTransfer.Redirect GetRedirectById(int redirectId);

        bool UpdateRedirect(DataTransfer.Redirect redirect);

        bool DeleteRedirect(DataTransfer.Redirect redirect);

        IEnumerable<DataTransfer.Redirect> GetDuplicates(DataTransfer.Redirect redirect);

        IEnumerable<DataTransfer.Redirect> GetCascades(DataTransfer.Redirect redirect);

        IEnumerable<DataTransfer.Redirect> GetRedirectsToPublish(short domainId);

        void CheckForValidity(DataTransfer.Redirect redirect);

        IEnumerable<RedirectHistory> GetDraftRedirect(int domainId);

        IEnumerable<DataTransfer.Redirect> GetRedirectsForPaging(RedirectPaging r, out int filteredCount, out int totalCount);
    }
}
