using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public interface IRedirectPublicationRequestRepository : IPublicationRequestRepository
    {
        IEnumerable<RedirectPublicationRequest> GetPublicationRequest(PublicationRequestCriteria criteria);

        IEnumerable<RedirectHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId);
    }
}
