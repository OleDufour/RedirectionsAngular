using System;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository
{
    public interface IPublicationRequestRepository
    {
        int AddPublicationRequest(int domainId, DateTime publicationDate, string publicationUser, bool isProduction);
    }
}
