using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models.Validation;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models
{
    [ValidSourceAndTarget]
    public class RedirectModel : ICloneable
    {
        public int? RedirectId { get; set; }

        [ValidEnum]
        [Display(Name = "app_domain", ResourceType = typeof(RedirectResources))]
        public EnumDomain? DomainId { get; set; }

        [ValidSource]
        [Display(Name = "app_redirect_sourcetype", ResourceType = typeof(RedirectResources))]
        [Required(ErrorMessageResourceName = "app_redirect_sourcetype_mandatory", ErrorMessageResourceType = typeof(RedirectResources))]
        public EnumSourceTypeTargetType? SourceType { get; set; }

        /// <summary>
        /// Uniquement utilisé pour l'affichage dans wwwroot/content/js/areas/index.js
        /// </summary>
        public string SourceTypeString => SourceType?.ToString();

        [Display(Name = "app_redirect_source", ResourceType = typeof(RedirectResources))]
        [Required(ErrorMessageResourceName = "app_redirect_source_mandatory", ErrorMessageResourceType = typeof(RedirectResources))]
        [StringLength(500)]
        public string Source { get; set; }

        [ValidTarget]
        [Display(Name = "app_redirect_targettype", ResourceType = typeof(RedirectResources))]
        [Required(ErrorMessageResourceName = "app_redirect_targettype_mandatory", ErrorMessageResourceType = typeof(RedirectResources))]
        public EnumSourceTypeTargetType? TargetType { get; set; }

        /// <summary>
        /// Utilisé pour l'affichage sur les pages .cshtml
        /// </summary>
        public string TargetTypeString => TargetType?.ToString();

        [Display(Name = "app_redirect_target", ResourceType = typeof(RedirectResources))]
        [Required(ErrorMessageResourceName = "app_redirect_target_mandatory", ErrorMessageResourceType = typeof(RedirectResources))]
        [StringLength(500)]
        public string Target { get; set; }


        [ValidEnum]
        [Display(Name = "app_redirect_redirecttype", ResourceType = typeof(RedirectResources))]
        [Required(ErrorMessageResourceName = "app_redirect_redirecttype_mandatory", ErrorMessageResourceType = typeof(RedirectResources))]
        public EnumRedirectType? RedirectType { get; set; }

        /// <summary>
        /// Uniquement utilisé pour l'affichage dans wwwroot/content/js/areas/index.js
        /// </summary>
        public string RedirectTypeString => RedirectType?.ToString();

        public DateTime CreationDate { get; set; }

        public string CreationUser { get; set; }

        public DateTime? ModificationDate { get; set; }

        public string ModificationUser { get; set; }

        public DateTime? DeletionDate { get; set; }
        public string DeletionUser { get; set; }

        /// <summary>
        /// True if GetAuthorizedReadWriteDomain("REDIRECT") doesnt DomainId.Value 
        /// </summary>
        public bool ReadOnly { get; set; }

        public bool IsDeleted { get; set; }

        public IEnumerable<RedirectHistoryViewModel> History { get; set; }

        public object Clone()
        {
            return this.MemberwiseClone();
        }
    }
}
