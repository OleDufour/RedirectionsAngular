namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models
{
    public class PublicationRequestViewModel
    {
        public int PublicationRequestId { get; set; }

        public string PublicationRequestDate { get; set; }

        public string PublicationRequestUser { get; set; }

        public int DomainId{ get; set; }

        public bool IsPublishable { get; set; }

        public bool IsCurrentPublication { get; set; }
    }
}
