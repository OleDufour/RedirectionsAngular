using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models
{
    public class PublicationDomainsViewModel
    {
        public IList<int> SelectedDomains { get; set; }

        public IList<DomainModel> DomainsToPublish { get; set; }

    }

    
}
