using System;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models.Validation
{
    public class ValidEnum : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
                return new ValidationResult(RedirectResources.app_invalid_value);
            }
            else
            {
                return Enum.IsDefined(value.GetType(), value) ? ValidationResult.Success : new ValidationResult(value + " " + RedirectResources.app_invalid_value);
            }
        }
    }
}
