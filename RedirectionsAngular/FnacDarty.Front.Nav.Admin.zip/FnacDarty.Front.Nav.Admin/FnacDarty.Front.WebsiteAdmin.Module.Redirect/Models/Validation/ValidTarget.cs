using System;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using FnacDarty.Front.WebsiteAdmin.Constant;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models.Validation
{
    public class ValidTarget : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null)
            {
                return new ValidationResult(RedirectResources.app_invalid_value);
            }
            else
            {
                return Enum.IsDefined(typeof(EnumSourceTypeTargetType), value) && SourceTypeTargetType.TargetTypes.Any(x => x == (EnumSourceTypeTargetType)value) ? ValidationResult.Success : new ValidationResult(value + " " + RedirectResources.app_invalid_value);
            }
        }
    }
}
