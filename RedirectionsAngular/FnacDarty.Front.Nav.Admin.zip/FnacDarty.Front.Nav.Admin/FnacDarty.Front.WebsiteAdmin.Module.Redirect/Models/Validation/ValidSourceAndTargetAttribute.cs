using System;
using System.ComponentModel.DataAnnotations;
using FnacDarty.Front.WebsiteAdmin.Constant;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models.Validation
{
    public class ValidSourceAndTargetAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var msg = string.Empty;
            var isValid = true;
            var redirect = (RedirectModel)validationContext.ObjectInstance;
            var isSourceValid = redirect.SourceType.HasValue && IsValueValid(redirect.Source, redirect.SourceType.Value);
            var isTargetValid = redirect.TargetType.HasValue && IsValueValid(redirect.Target, redirect.TargetType.Value);

            if (!isSourceValid && !isTargetValid)
            {
                msg = RedirectResources.app_redirect_error_source_target;
                isValid = false;
            }
            else if (!isSourceValid)
            {
                msg = RedirectResources.app_redirect_error_source;
                isValid = false;
            }
            else if (!isTargetValid)
            {
                msg = RedirectResources.app_redirect_error_target;
                isValid = false;
            }

            return isValid ? ValidationResult.Success : new ValidationResult(msg);
        }

        /// <summary>
        /// Attention, trouvez l'explication sur \wwwroot\Content\js\areas\redirect\addoredit.js
        /// </summary>
        /// <param name="value"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        private bool IsValueValid(string value, EnumSourceTypeTargetType type)
        {
            switch (type)
            {          
                case EnumSourceTypeTargetType.Artist:
                case EnumSourceTypeTargetType.Brand:             
                case EnumSourceTypeTargetType.CommunityPost:
                case EnumSourceTypeTargetType.CommunityContributor:
                case EnumSourceTypeTargetType.CommunitySecondaryHome:
                case EnumSourceTypeTargetType.CommunityTag:
                case EnumSourceTypeTargetType.Format:
                case EnumSourceTypeTargetType.Node:
                case EnumSourceTypeTargetType.Product:
                case EnumSourceTypeTargetType.ProductPureMarketPlace:
                case EnumSourceTypeTargetType.Series:
                case EnumSourceTypeTargetType.Store:
                case EnumSourceTypeTargetType.Work:
                    return int.TryParse(value, out var n);
                case EnumSourceTypeTargetType.Url:
                    return Uri.TryCreate(value, UriKind.Absolute, out var validatedUri);
                case EnumSourceTypeTargetType.Path:
                    return Uri.TryCreate(value, UriKind.Relative, out var v);
                default:
                    return true;
            }
        }
    }
}
