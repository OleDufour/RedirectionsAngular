using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models
{
    public class RedirectHistoryViewModel
    {
        public int? RedirectId { get; set; }
        public string SourceType { get; set; }
        public string Source { get; set; }

        public string TargetType { get; set; }
        public string Target { get; set; }

        public string RedirectType { get; set; }

        [Display(Name = "app_url_field_date_modification", ResourceType = typeof(RedirectResources))]
        public string CreationDate { get; set; }

        [Display(Name = "app_url_field_user", ResourceType = typeof(RedirectResources))]
        public string CreationUser { get; set; }

        [Display(Name = "app_url_field_publication_id", ResourceType = typeof(RedirectResources))]
        public string PublicationRequestId { get; set; }

        [Display(Name = "app_url_field_publication_date", ResourceType = typeof(RedirectResources))]
        public string PublicationDate { get; set; }

        [Display(Name = "app_url_field_publication_by", ResourceType = typeof(RedirectResources))]
        public string PublicationUser { get; set; }

        [Display(Name = "app_action_type", ResourceType = typeof(RedirectResources))]
        public string ActionType { get; set; }

    }
}
