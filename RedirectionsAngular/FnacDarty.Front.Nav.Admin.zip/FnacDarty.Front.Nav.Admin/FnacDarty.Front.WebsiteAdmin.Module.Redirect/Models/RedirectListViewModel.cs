using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models
{
    public class RedirectListViewModel
    {
        public IEnumerable<DomainModel> Domains { get; set; }

        public IDictionary<EnumDomain, IEnumerable<RedirectModel>> RedirectModelsDictionary { get; set; }

        public IEnumerable<DomainModel> AuthorizedDomainsReadOnly { get; set; }

        public IEnumerable<DomainModel> AuthorizedDomainsReadWrite { get; set; }
    }
}
