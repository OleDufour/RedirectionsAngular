using System.Collections.Generic;
using System.Linq;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models
{
    public class RedirectImportLineReport
    {
        public int Line { get; set; }
        public List<string> Errors { get; } = new List<string>();

        public RedirectImportLineReport(int line, string error)
        {
            Line = line;
            Errors.Add(error);
        }
    }

    public class RedirectImportErrorReport
    {
        public List<RedirectImportLineReport> Reports { get; } = new List<RedirectImportLineReport>();

        public void AddReport (string error, int line)
        {
            var report = Reports.FirstOrDefault(x => x.Line == line);
            if (report != null)
            {
                report.Errors.Add(error);
            }
            else
            {
                Reports.Add(new RedirectImportLineReport(line, error));
            }
        }
    }
}
