using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Mapper
{
    public class RedirectViewModelMapper : DtoModelMapperBase<DataTransfer.Redirect, RedirectModel>
    {
        public override RedirectModel DtoToModel(DataTransfer.Redirect dto)
        {
            return new RedirectModel
            {
                RedirectId = dto.RedirectId ?? 0,
                DomainId = (EnumDomain)dto.DomainId,
                SourceType = (EnumSourceTypeTargetType)dto.SourceType,
                Source = dto.Source,
                TargetType = (EnumSourceTypeTargetType)dto.TargetType,
                Target = dto.Target,
                RedirectType = (EnumRedirectType)dto.RedirectType,
                CreationDate = dto.CreationDate,
                CreationUser = dto.CreationUser,
                ModificationDate = dto.ModificationDate,
                ModificationUser = dto.ModificationUser,
                DeletionDate = dto.DeletionDate,
                DeletionUser = dto.DeletionUser,
                IsDeleted = dto.DeletionDate.HasValue
            };
        }

        public override DataTransfer.Redirect ModelToDto(RedirectModel viewModel)
        {
            return new DataTransfer.Redirect
            {
                RedirectId = viewModel.RedirectId,
                DomainId = (short)viewModel.DomainId,
                SourceType = (short)viewModel.SourceType,
                Source = viewModel.Source,
                TargetType = (short)viewModel.TargetType,
                Target = viewModel.Target,
                RedirectType = (short)viewModel.RedirectType,
                CreationDate = viewModel.CreationDate,
                CreationUser = viewModel.CreationUser,
                ModificationDate = viewModel.ModificationDate,
                ModificationUser = viewModel.ModificationUser,
                DeletionDate = viewModel.DeletionDate,
                DeletionUser = viewModel.DeletionUser
            };
        }
    }
}

