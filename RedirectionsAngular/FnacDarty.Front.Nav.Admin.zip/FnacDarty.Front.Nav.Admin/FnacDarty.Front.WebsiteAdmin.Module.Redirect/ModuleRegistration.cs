using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Helper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect
{
    public class ModuleRegistration : ModuleRegistrationBase
    {
        public override IServiceCollection RegisterServices(IServiceCollection services)
        {
            services.AddSingleton<IRedirectPublicationRequestRepository, RedirectPublicationRequestRepository>();


            services.AddSingleton<IRedirectRepository, RedirectRepository>();
            services.AddSingleton<IRedirectHistoryRepository, RedirectHistoryRepository>();
            services.AddSingleton<IRedirectPublicationRepository, RedirectPublicationRepository>();

            services.AddSingleton<IDataTablesRepository<DataTransfer.Redirect>, RedirectDataTablesRepository>();


            services.AddSingleton<IDtoModelMapper<DataTransfer.Redirect, RedirectModel>, RedirectViewModelMapper>();
            services.AddScoped<IRedirectHelper, RedirectHelper>();
            services.AddSingleton<IRedirectBusinessModule, RedirectBusinessModule>();


            return services;
        }

        public override AuthorizationOptions RegisterAuthorizations(AuthorizationOptions authorizationOptions)
        {

            authorizationOptions.AddPolicy(AuthorizePolicyConsts.Redirect_Read_Write, policy =>
            {
                policy.AddRequirements(new AuthorizedUserRequirement(false,
                    new[]
                    {
                        EnumUserRole.REDIRECT_FR_FR_READ,
                        EnumUserRole.REDIRECT_FR_FR_WRITE,
                        EnumUserRole.REDIRECT_FR_FR_PRO_READ,
                        EnumUserRole.REDIRECT_FR_FR_PRO_WRITE,
                        EnumUserRole.REDIRECT_FR_BE_READ,
                        EnumUserRole.REDIRECT_FR_BE_WRITE,
                        EnumUserRole.REDIRECT_NL_BE_READ,
                        EnumUserRole.REDIRECT_NL_BE_WRITE,
                        EnumUserRole.REDIRECT_FR_CH_READ,
                        EnumUserRole.REDIRECT_FR_CH_WRITE,
                        EnumUserRole.REDIRECT_ES_ES_READ,
                        EnumUserRole.REDIRECT_ES_ES_WRITE,
                        EnumUserRole.REDIRECT_PT_PT_READ,
                        EnumUserRole.REDIRECT_PT_PT_WRITE
                    }
                ));
                policy.RequireAuthenticatedUser();
                policy.AuthenticationSchemes.Add("Windows");
            });
            authorizationOptions.AddPolicy(AuthorizePolicyConsts.Redirect_Read, policy =>
            {
                policy.AddRequirements(new AuthorizedUserRequirement(false,
                    new[]
                    {
                        EnumUserRole.REDIRECT_FR_FR_READ,
                        EnumUserRole.REDIRECT_FR_FR_PRO_READ,
                        EnumUserRole.REDIRECT_FR_BE_READ,
                        EnumUserRole.REDIRECT_NL_BE_READ,
                        EnumUserRole.REDIRECT_FR_CH_READ,
                        EnumUserRole.REDIRECT_ES_ES_READ,
                        EnumUserRole.REDIRECT_PT_PT_READ
                    }
                ));
                policy.RequireAuthenticatedUser();
                policy.AuthenticationSchemes.Add("Windows");
            });
            return authorizationOptions;
        }

        public override IDynamicMenuBuilder RegisterMenu(IDynamicMenuBuilder menuBuilder)
        {
            menuBuilder.AddSection(nameof(RedirectResources.app_redirect_management), new[]
            {
                new MenuItem()
                {
                    Label = nameof(RedirectResources.app_redirect_management),
                    Icon = "fa-reply icon-flip",
                    SubItems = new List<SubMenuItem>
                    {
                        new SubMenuItem
                        {
                            Area = "Redirect",
                            Controller = "Redirect",
                            Action = "Index",
                            Label = nameof(RedirectResources.app_search),
                            AuthorizationRequired = AuthorizePolicyConsts.Redirect_Read
                        },
                        new SubMenuItem
                        {
                            Area = "Redirect",
                            Controller = "Redirect",
                            Action = "Add",
                            Label = nameof(RedirectResources.app_add),
                            AuthorizationRequired = AuthorizePolicyConsts.Redirect_Read_Write
                        },
                        new SubMenuItem
                        {
                            Area = "Redirect",
                            Controller = "Redirect",
                            Action = "Import",
                            Label = nameof(RedirectResources.app_import),
                            AuthorizationRequired = AuthorizePolicyConsts.Redirect_Read_Write
                        },
                        new SubMenuItem
                        {
                            Area = "Redirect",
                            Controller = "Redirect",
                            Action = "Publication",
                            Label = nameof(RedirectResources.app_publish),
                            AuthorizationRequired = AuthorizePolicyConsts.Redirect_Read_Write
                        }
                    }
                },
            }, RedirectResources.ResourceManager);


            return menuBuilder;
        }
    }
}
