using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule
{
    public interface IXmlBusinessModule
    {
        void WriteXmlFile(List<string> paths, RedirectXmlModelList xmlModel);
    }
}
