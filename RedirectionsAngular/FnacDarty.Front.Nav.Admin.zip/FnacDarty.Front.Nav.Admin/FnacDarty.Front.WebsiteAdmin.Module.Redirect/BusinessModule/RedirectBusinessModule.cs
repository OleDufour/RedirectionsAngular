using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Repository;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule
{
    public class RedirectBusinessModule : BaseBusinessModule, IRedirectBusinessModule
    {
        public IRedirectRepository RedirectRepository;
        public IRedirectHistoryRepository RedirectHistoryRepository;
        public IRedirectPublicationRequestRepository PublicationRequestRepository;
        public IRedirectPublicationRepository RedirectPublicationRepository;
        public IDataTablesRepository<DataTransfer.Redirect> RedirectDataTablesRepository;
        public IRestClient RestClient;

        public RedirectBusinessModule(IRedirectRepository redirectRepository,
            IRedirectHistoryRepository redirectHistoryRepository,
            IRedirectPublicationRequestRepository publicationRequestRepository,
            IRedirectPublicationRepository redirectPublicationRepository,
            IDataTablesRepository<DataTransfer.Redirect> redirectDataTablesRepository,
            ILogger logger,
            IConfig config,
            IRestClient restClient)
            : base(logger, config)
        {
            RedirectRepository = redirectRepository;
            RedirectHistoryRepository = redirectHistoryRepository;
            PublicationRequestRepository = publicationRequestRepository;
            RedirectPublicationRepository = redirectPublicationRepository;
            RedirectDataTablesRepository = redirectDataTablesRepository;
            RestClient = restClient;
        }

        public DataTransfer.Redirect AddRedirect(DataTransfer.Redirect redirect)
        {
            using (var transaction = new TransactionScope())
            {
                var redirectId = RedirectRepository.AddRedirect(redirect);
                if (redirectId > 0)
                {
                    redirect.RedirectId = redirectId;

                    var historyResult = RedirectHistoryRepository.AddRedirectHistory(new RedirectHistory
                    {
                        RedirectId = redirectId,
                        SourceType = redirect.SourceType,
                        Source = redirect.Source,
                        TargetType = redirect.TargetType,
                        Target = redirect.Target,
                        RedirectType = redirect.RedirectType,
                        CreationDate = redirect.CreationDate,
                        CreationUser = redirect.CreationUser,
                        ActionTypeId = (short)EnumActionType.Add
                    });

                    if (historyResult > 0)
                    {
                        transaction.Complete();
                        return redirect;
                    }
                }
            }
            return redirect;
        }

        public DataTransfer.Redirect GetRedirect(int redirectId)
        {
            var redirect = RedirectRepository.GetRedirectById(redirectId);
            return redirect;
        }

        public bool UpdateRedirect(DataTransfer.Redirect redirect)
        {
            var redirectVerify = RedirectRepository.GetRedirectById(redirect.RedirectId.Value);
            if (redirectVerify == null)
                throw new NonExistingElementException();
            if (redirectVerify.DeletionDate.HasValue)
                return false;

            using (var transaction = new TransactionScope())
            {
                var result = RedirectRepository.UpdateRedirect(redirect);
                if (result && redirect.RedirectId.HasValue && redirect.ModificationDate.HasValue)
                {
                    var historyResult = RedirectHistoryRepository.AddRedirectHistory(new RedirectHistory
                    {
                        RedirectId = redirect.RedirectId.Value,
                        SourceType = redirect.SourceType,
                        Source = redirect.Source,
                        TargetType = redirect.TargetType,
                        Target = redirect.Target,
                        RedirectType = redirect.RedirectType,
                        CreationDate = redirect.ModificationDate.Value,
                        CreationUser = redirect.ModificationUser,
                        ActionTypeId = (short)EnumActionType.Update
                    });

                    if (historyResult > 0)
                    {
                        transaction.Complete();
                        return true;
                    }
                }
            }
            return false;
        }

        public RedirectPublicationRequest GetCurrentPublicationRequest(EnumDomain domainId)
        {
            return RedirectPublicationRepository.GetCurrentRedirectPublicationForDomain((int)domainId);
        }


        public bool DeleteRedirect(DataTransfer.Redirect redirect)
        {
            if (redirect == null)
            {
                throw new ArgumentNullException(nameof(redirect));
            }

            using (var transactionScope = new TransactionScope())
            {
                var isDeleted = RedirectRepository.DeleteRedirect(redirect);
                if (isDeleted && redirect.RedirectId.HasValue)
                {
                    var historyResult = RedirectHistoryRepository.AddRedirectHistory(new RedirectHistory
                    {
                        RedirectId = redirect.RedirectId.Value,
                        SourceType = redirect.SourceType,
                        Source = redirect.Source,
                        TargetType = redirect.TargetType,
                        Target = redirect.Target,
                        RedirectType = redirect.RedirectType,
                        CreationDate = redirect.DeletionDate ?? DateTime.Now,
                        CreationUser = redirect.DeletionUser,
                        ActionTypeId = (short)EnumActionType.Delete
                    });
                    if (historyResult > 0)
                    {
                        transactionScope.Complete();
                        return true;
                    }
                }
            }

            return false;
        }

        public IEnumerable<DataTransfer.Redirect> GetRedirectDomain(short domainId)
        {
            return RedirectRepository.GetRedirects(domainId);
        }

        public IEnumerable<RedirectHistory> GetRedirectHistory(int redirectId)
        {
            var redirectHistory = RedirectHistoryRepository.GetRedirectHistory(redirectId);
            redirectHistory = KeepPublicationOnlyForLastItem(redirectHistory);
            return redirectHistory;
        }

        private IEnumerable<RedirectHistory> KeepPublicationOnlyForLastItem(IEnumerable<RedirectHistory> redirectHistory)
        {
            // On group par publication Id.
            var groups = redirectHistory.Where(i => i.PublicationRequestId.HasValue).GroupBy(i => i.PublicationRequestId);
            foreach (var group in groups)
            {
                // On trie par date et on laisse le premier avec les infos de publication.
                var toUpdate = group.OrderByDescending(i => i.CreationDate).Skip(1);
                foreach (var item in toUpdate)
                {
                    item.PublicationRequestDate = null;
                    item.PublicationRequestId = null;
                    item.PublicationRequestUser = null;
                }
            }
            return redirectHistory;
        }

        #region Search Redirects
        public IEnumerable<DataTransfer.Redirect> GetRedirectsForPaging(RedirectPaging r, out int filteredCount, out int totalCount)
        {
            var redirects = RedirectRepository.GetRedirectsForPaging(r, out filteredCount, out totalCount);
            return redirects;
        }

        public string OrderByColumn(DataTablesParameters parameters)
        {
            var orderByColumn = RedirectDataTablesRepository.ColumnNameMapping[parameters.Columns[parameters.Order[0].Column].Data];
            return orderByColumn;
        }

        public string AscOrDesc(DataTablesParameters parameters)
        {
            var ascOrDesc = parameters.Order[0].Dir;
            return ascOrDesc;
        }
        #endregion


        #region Publication

        public void CheckForValidity(DataTransfer.Redirect redirect)
        {
            RedirectRepository.CheckForValidity(redirect);
        }

        public IEnumerable<RedirectHistory> GetDraftRedirect(EnumDomain domainId)
        {
            var res = RedirectRepository.GetDraftRedirect((int)domainId);
            return FilterPublicationDetails(res);
        }

        public IEnumerable<RedirectHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId)
        {
            var res = PublicationRequestRepository.GetPublicationRequestDetails(publicationRequestId, domainId);
            return FilterPublicationDetails(res);
        }

        private IEnumerable<RedirectHistory> FilterPublicationDetails(IEnumerable<RedirectHistory> details)
        {
            var res = new List<RedirectHistory>();
            var groups = details.GroupBy(i => i.RedirectId);
            foreach (var group in groups)
            {
                if (WasDeleted(group))
                {
                    if (!WasAdded(group))
                    {
                        // On prend que les éléments qui ont été supprimés et pas ajoutés pour la même publication.
                        res.Add(group.First(i => (EnumActionType)i.ActionTypeId == EnumActionType.Delete));
                    }
                }
                else
                {
                    if (WasAdded(group))
                    {
                        if (WasModified(group))
                        {
                            var item = GetLastModified(group).Clone() as RedirectHistory;
                            item.ActionTypeId = (short)EnumActionType.Add;
                            // l'élément a été ajouté puis modifié, on prend la dernière modification mais on met l'action a ajouté.
                            res.Add(item);
                        }
                        else
                        {
                            // On n'a qu'un ajout du coup. On prend l'élément qui a été ajouté.
                            res.Add(group.First());
                        }
                    }
                    else
                    {
                        // On n'a que des modifications, on prend que la dernière.
                        res.Add(GetLastModified(group));
                    }
                }
            }
            return res;
        }

        private RedirectHistory GetLastModified(IGrouping<int, RedirectHistory> group)
        {
            return group.OrderByDescending(i => i.CreationDate).First();
        }

        private bool WasAdded(IGrouping<int, RedirectHistory> group)
        {
            return group.Any(i => (EnumActionType)i.ActionTypeId == EnumActionType.Add);
        }

        private bool WasModified(IGrouping<int, RedirectHistory> group)
        {
            return group.Any(i => (EnumActionType)i.ActionTypeId == EnumActionType.Update);
        }

        private bool WasDeleted(IGrouping<int, RedirectHistory> group)
        {
            return group.Any(i => (EnumActionType)i.ActionTypeId == EnumActionType.Delete);
        }

        public IEnumerable<RedirectPublicationRequest> GetPublicationRequestHistory(EnumDomain domainId)
        {
            return PublicationRequestRepository.GetPublicationRequest(new PublicationRequestCriteria { DomainId = (int)domainId });
        }

        public bool PublishRedirectDomain(EnumDomain domain, string user, string siteCode, string cultureCode, bool isProduction)
        {
            using (var transactionScope = new TransactionScope())
            {
                var domainId = (int)domain;
                var now = DateTime.Now;
                var newPublicationRequestId = PublicationRequestRepository.AddPublicationRequest(domainId, now, user, isProduction);
                var historyAdded = true;

                if (isProduction)
                {
                    historyAdded = RedirectHistoryRepository.AddPublicationInfosToHistory(domainId, newPublicationRequestId);
                }

                if (historyAdded && RedirectPublicationRepository.PublishRedirect(newPublicationRequestId, domainId, isProduction))
                {
                    var isCacheInvalidatedAndReloaded = NotifyInvalidateAndReloadApiCache(siteCode, cultureCode, isProduction);

                    if (isCacheInvalidatedAndReloaded)
                    {
                        transactionScope.Complete();
                        return true;
                    }
                }
            }

            return false;
        }

        private bool NotifyInvalidateAndReloadApiCache(string siteCode, string cultureCode, bool isProduction)
        {
            // Invalidation du cache sur les n APIs mises en place (on passe par une VIP => Load Balancer)
            var apiConfig = isProduction
                ? Config.GetSettingValue($"Api:Release:{siteCode}:{cultureCode}:Redirect")
                : Config.GetSettingValue($"Api:Unstable:{siteCode}:{cultureCode}:Redirect");
            var config = RestClientConfigurationManager.Get(apiConfig);

            RestClient.BaseAddress = config.BaseAddress;
            RestClient.Timeout = config.Timeout;
            RestClient.NumberOfAttempts = config.NumberOfAttempts;
            RestClient.TimeToSleepBetweenAttempts = config.TimeToSleepBetweenAttempts;

            var isCacheInvalidatedAndReloaded = RestClient.Delete($"NotifyInvalidateAndReloadCache/{siteCode}/{cultureCode}");

            return isCacheInvalidatedAndReloaded;
        }

        #endregion
    }
}
