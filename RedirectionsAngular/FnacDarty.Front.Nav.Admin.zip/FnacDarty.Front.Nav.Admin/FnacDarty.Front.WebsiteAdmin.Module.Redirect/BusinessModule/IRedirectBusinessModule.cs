using System.Collections.Generic;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule
{
    public interface IRedirectBusinessModule
    {
        IEnumerable<DataTransfer.Redirect> GetRedirectDomain(short domainId);
        DataTransfer.Redirect AddRedirect(DataTransfer.Redirect redirect);

        DataTransfer.Redirect GetRedirect(int redirectId);

        bool UpdateRedirect(DataTransfer.Redirect redirect);

        bool DeleteRedirect(DataTransfer.Redirect redirect);

        IEnumerable<RedirectHistory> GetRedirectHistory(int redirectId);

        IEnumerable<RedirectHistory> GetPublicationRequestDetails(int publicationRequestId, int domainId);

        IEnumerable<RedirectPublicationRequest> GetPublicationRequestHistory(EnumDomain domainId);

        bool PublishRedirectDomain(EnumDomain domain, string user, string siteCode, string cultureCode, bool isProduction);
        RedirectPublicationRequest GetCurrentPublicationRequest(EnumDomain domainId);


        #region Search Redirects
        IEnumerable<DataTransfer.Redirect> GetRedirectsForPaging(RedirectPaging r, out int filteredCount, out int totalCount);
        string OrderByColumn(DataTablesParameters parameters);
        string AscOrDesc(DataTablesParameters parameters);
        #endregion


        void CheckForValidity(DataTransfer.Redirect redirect);

        IEnumerable<RedirectHistory> GetDraftRedirect(EnumDomain domainId);





    }
}
