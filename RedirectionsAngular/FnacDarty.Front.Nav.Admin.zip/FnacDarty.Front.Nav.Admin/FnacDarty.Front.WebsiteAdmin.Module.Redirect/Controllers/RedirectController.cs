using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using CsvHelper;
using CsvHelper.Configuration;
using CsvHelper.TypeConversion;
using FnacDarty.Front.WebsiteAdmin.Constant;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.AccessControl;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Exceptions;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Helper;
using FnacDarty.Front.WebsiteAdmin.Module.Redirect.Models;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Controllers;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models;
using FnacDarty.Front.WebsiteAdmin.WebCommon.Models.Common;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Controllers
{
    [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
    [Area("Redirect")]
    public class RedirectController : ApplicationController
    {

        public IRedirectBusinessModule RedirectBusinessModule;
        public IDomainBusinessModule DomainBusinessModule;

        public IDtoModelMapper<DataTransfer.Redirect, RedirectModel> RedirectViewModelMapper;
        public IDtoModelMapper<Domain, DomainModel> DomainModelMapper;

        private const string ControllerRolePattern = "REDIRECT";

        public IRedirectHelper RedirectHelper { get; }

        public RedirectController(ILogger logger,
            IRedirectBusinessModule redirectBusinessModule, IDomainBusinessModule domainBusinessModule,
            IDtoModelMapper<DataTransfer.Redirect, RedirectModel> redirectViewModelMapper,
            IDtoModelMapper<Domain, DomainModel> domainModelMapper,
            IRedirectHelper redirectHelper,
            IAccessControl accessControl) : base(logger, accessControl)
        {
            RedirectBusinessModule = redirectBusinessModule;
            DomainBusinessModule = domainBusinessModule;
            RedirectViewModelMapper = redirectViewModelMapper;
            DomainModelMapper = domainModelMapper;
            RedirectHelper = redirectHelper;
        }

        #region Search
        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect")]
        public ActionResult Index()
        {
            var domains = DomainBusinessModule.GetDomains();
            var autorizedDomainsReadWrite = domains.Where(d => GetAuthorizedReadWriteDomain(ControllerRolePattern).Contains((EnumDomain)d.DomainId)).ToList();
            var autorizedDomainsReadOnly = domains.Where(d => GetAuthorizedReadOnlyDomain(ControllerRolePattern).Contains((EnumDomain)d.DomainId)).ToList();

            var redirectListViewModel = new RedirectListViewModel()
            {
                AuthorizedDomainsReadOnly = DomainModelMapper.DtosToModels(autorizedDomainsReadOnly).ToList(),
                AuthorizedDomainsReadWrite = DomainModelMapper.DtosToModels(autorizedDomainsReadWrite).ToList(),
                RedirectModelsDictionary = new Dictionary<EnumDomain, IEnumerable<RedirectModel>>()
            };

            // Intended for the filters in the JQuery datatable :
            var sourceTypes = SourceTypeTargetType.SourceTypes.Select(d => new { name = d.ToString(), value = ((int)d).ToString() }).ToList();
            sourceTypes.Insert(0, new { name = RedirectResources.app_redirect_any_source_type, value = string.Empty });
            ViewBag.SourceTypesBag = JsonConvert.SerializeObject(sourceTypes);

            var targetTypes = SourceTypeTargetType.TargetTypes.Select(d => new { name = d.ToString(), value = ((int)d).ToString() }).ToList();
            targetTypes.Insert(0, new { name = RedirectResources.app_redirect_any_target_type, value = string.Empty });
            ViewBag.TargetTypesBag = JsonConvert.SerializeObject(targetTypes);

            var redirectTypes = Enum.GetValues(typeof(EnumRedirectType)).Cast<EnumRedirectType>().Select(d => new { name = d.ToString(), value = ((int)d).ToString() }).ToList();
            redirectTypes.Insert(0, new { name = RedirectResources.app_redirect_any_type, value = string.Empty });
            ViewBag.RedirectTypesBag = JsonConvert.SerializeObject(redirectTypes);

            return View(redirectListViewModel);
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/getdatatableredirects")]
        public DataTablesReturnData<RedirectModel> GetDataTableRedirects(DataTablesParameters parameters)
        {
            var r = new RedirectPaging();
            r.DomainId = (short)parameters.DomainId;
            r.OrderByColumn = RedirectBusinessModule.OrderByColumn(parameters);
            r.AscOrDesc = RedirectBusinessModule.AscOrDesc(parameters);
            r.PageNo = parameters.Start / parameters.Length + 1;
            r.PageSize = parameters.Length;
            r.IncludeDeletions = parameters.IncludeDeletions;

            foreach (var p in parameters.Columns)
            {
                switch (p.Data)
                {
                    case nameof(r.SourceTypeString): r.SourceType = Convert.ToInt16(p.Search.Value); break;
                    case nameof(r.Source): r.Source = p.Search.Value; break;
                    case nameof(r.TargetTypeString): r.TargetType = Convert.ToInt16(p.Search.Value); break;
                    case nameof(r.Target): r.Target = p.Search.Value; break;
                    case nameof(r.RedirectTypeString): r.RedirectType = Convert.ToInt16(p.Search.Value); break;
                }
            }
            var res = RedirectBusinessModule.GetRedirectsForPaging(r, out var filteredCount, out var totalCount);
            return new DataTablesReturnData<RedirectModel>
            {
                Draw = parameters.Draw,
                RecordsFiltered = filteredCount,
                RecordsTotal = totalCount,
                Data = RedirectViewModelMapper.DtosToModels(res)
            };
        }
        #endregion

        #region Import from csv file
        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read_Write)]
        [Route("redirect/import")]
        public ActionResult Import()
        {
            var domains = DomainBusinessModule.GetDomains();
            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            return View();
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read_Write)]
        [Route("redirect/import")]
        public ActionResult Import(IFormFile file, int domainId)
        {
            var redirects = new List<DataTransfer.Redirect>();
            var report = new RedirectImportErrorReport();
            var current_line = 2; //not 0 to skip header
            using (var stream = file.OpenReadStream())
            {
                var conf = new Configuration()
                {
                    Delimiter = ";",
                    // disable header and field validation, not all fields are present in the csv file
                    HeaderValidated = null,
                    MissingFieldFound = null,
                    TrimOptions = TrimOptions.Trim,
                    IgnoreBlankLines = true,
                    // Deal with spotty headers, � characters appears sometimes (from Excel ?)
                    PrepareHeaderForMatch = (string header, int index) => header.Replace("�", string.Empty).ToLower().Trim()
                };

                using (var reader = new CsvReader(new StreamReader(stream), conf))
                {
                    // Ignore header case.
                    while (reader.Read())
                    {
                        DataTransfer.Redirect dto = null;
                        try
                        {
                            var record = reader.GetRecord<RedirectModel>();
                            record.CreationDate = DateTime.Now;
                            record.CreationUser = ApplicationUser.Identity.Name;
                            record.DomainId = (EnumDomain)domainId;
                            dto = RedirectHelper.GetValidDto(record, redirects);
                        }
                        catch (ReaderException) // Le fichier est aussi corrompu que François Fillon.
                        {
                            report.AddReport(RedirectResources.app_redirect_csvfile_invalidformat, 0);
                            return BadRequest(report);
                        }
                        catch (TypeConverterException e)
                        {
                            report.AddReport(e.Text + " " + RedirectResources.app_invalid_value, current_line);
                        }

                        catch (DuplicateException)
                        {
                            report.AddReport(RedirectResources.app_redirect_duplicate, current_line);
                        }
                        catch (CascadeException)
                        {
                            report.AddReport(RedirectResources.app_redirect_cascade, current_line);
                        }
                        catch (InvalidRedirectException e)
                        {
                            if (e.Data.Contains("ValidationMessages"))
                            {
                                foreach (ValidationResult res in e.Data["ValidationMessages"] as List<ValidationResult>)
                                {
                                    report.AddReport(res.ErrorMessage, current_line);
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            report.AddReport(e.Message, current_line);
                        }
                        if (dto != null)
                        {
                            redirects.Add(dto);
                        }
                        current_line++;
                    }
                }
            }

            if (report.Reports.Count != 0)
            {
                return BadRequest(report);
            }
            else
            {
                foreach (var redirect in redirects)
                {
                    RedirectBusinessModule.AddRedirect(redirect);
                }
                return Ok();
            }
        }


        #endregion

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/getdomainredirect/{domainId:int}")]
        public IEnumerable<RedirectModel> GetDomainRedirect(short domainId)
        {
            var dtos = RedirectBusinessModule.GetRedirectDomain(domainId);
            var autorizedDomainsReadWrite = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var redirectModels = RedirectViewModelMapper.DtosToModels(dtos).ToList();
            redirectModels.ForEach(x => x.ReadOnly = !x.DomainId.HasValue || !autorizedDomainsReadWrite.Contains(x.DomainId.Value));
            return redirectModels;
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/edit/{redirectId:int}/{editSuccess?}")]
        public ActionResult Edit(int redirectId, bool editSuccess = false)
        {
            var redirect = RedirectBusinessModule.GetRedirect(redirectId);
            if (redirect != null)
            {
                var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
                var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId)).ToList();

                ViewBag.EditSuccess = editSuccess;
                ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList(); // We only show domains that the user can edit a redirect for.  
                ViewBag.TargetSource = Enum.GetValues(typeof(EnumSourceTypeTargetType)).Cast<EnumSourceTypeTargetType>();
                ViewBag.RedirectType = Enum.GetValues(typeof(EnumRedirectType)).Cast<EnumRedirectType>();

                RedirectModel model = RedirectViewModelMapper.DtoToModel(redirect);
                model.History = GetRedirectHistories(redirectId);
                return View("AddOrEdit", model);
            }
            return RedirectToAction("Index");
        }

        // Show add page
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read_Write)]
        [Route("redirect/add")]
        public ActionResult Add()
        {
            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId)).ToList();

            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList(); // We only show domains that the user can create a redirect for.        
            ViewBag.TargetSource = Enum.GetValues(typeof(EnumSourceTypeTargetType)).Cast<EnumSourceTypeTargetType>();
            ViewBag.RedirectType = Enum.GetValues(typeof(EnumRedirectType)).Cast<EnumRedirectType>();

            var model = new RedirectModel
            {        // Get the first value of the EnumDomain as default.
                DomainId = (EnumDomain?)domains.FirstOrDefault()?.DomainId
            };

            return View("AddOrEdit", model);
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read_Write)]
        [Route("redirect/addoredit")]
        public IActionResult AddOrEdit(RedirectModel redirectModel)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var authorizedDomainsReadWrite = GetAuthorizedReadWriteDomain(ControllerRolePattern);
                    if (!authorizedDomainsReadWrite.Contains(redirectModel.DomainId ?? EnumDomain.FR_FR))
                    {
                        throw new Exception(RedirectResources.app_unauthorized_edit);
                    }

                    if (redirectModel.Source.Trim() == redirectModel.Target.Trim() && redirectModel.SourceType == redirectModel.TargetType)
                        throw new IdenticalSourceTargetException();

                    // Update
                    if (redirectModel.RedirectId.HasValue && redirectModel.RedirectId.Value > 0)
                    {
                        var redirectDto = RedirectViewModelMapper.ModelToDto(redirectModel);
                        redirectDto.ModificationUser = ApplicationUser.Identity.Name;
                        redirectDto.ModificationDate = DateTime.Now;
                        bool result = false;
                        try
                        {
                            result = RedirectBusinessModule.UpdateRedirect(redirectDto);
                        }
                        catch (NonExistingElementException)
                        {
                            return Json(new ResultModel
                            {
                                Success = false,
                                Message = RedirectResources.app_nonexisting_element,
                                Data = new { IsDeleted = true }
                            });
                        }
                        if (result)
                        {
                            return Json(new ResultModel
                            {
                                Success = true,
                                Message = RedirectResources.app_update_success,
                                Data = new { RedirectId = redirectDto.RedirectId.Value, historyitems = GetRedirectHistories(redirectDto.RedirectId.Value) }
                            });
                        }
                        // Element exist but has been deleted.
                        return Json(new ResultModel
                        {
                            Success = false,
                            Message = RedirectResources.app_already_deleted,
                            Data = new { IsDeleted = true }
                        });
                    }

                    redirectModel.CreationUser = ApplicationUser.Identity.Name;
                    redirectModel.CreationDate = DateTime.Now;
                    var redirect = RedirectBusinessModule.AddRedirect(RedirectViewModelMapper.ModelToDto(redirectModel));
                    if (redirect.RedirectId.HasValue && redirect.RedirectId.Value > 0)
                    {
                        return Json(new ResultModel
                        {
                            Success = true,
                            Message = RedirectResources.app_add_success,
                            Data = new { RedirectId = redirect.RedirectId.Value, historyitems = GetRedirectHistories(redirect.RedirectId.Value) }
                        });
                    }

                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = RedirectResources.app_add_error
                    });
                }
                catch (DuplicateException)
                {
                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = RedirectResources.app_redirect_duplicate
                    });
                }
                catch (CascadeException)
                {
                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = RedirectResources.app_redirect_cascade
                    });
                }
                catch (IdenticalSourceTargetException)
                {
                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = RedirectResources.app_redirect_identicalsourcetargetexception
                    });
                }
                catch (Exception exception)
                {
                    return Json(new ResultModel
                    {
                        Success = false,
                        Message = $"{RedirectResources.app_errors_list} :<br/> + {exception.Message}"
                    });
                }
            }

            return Json(new ResultModel
            {
                Success = false,
                Message = $"{RedirectResources.app_errors_list}  :<ul>" + string.Join("", ModelStateErrors().Select(m => "<li>" + m + "</li>")) + "</ul>"
            });
        }


        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read_Write)]
        [Route("redirect/delete/{redirectId:int}")]
        public ResultModel Delete(int redirectId)
        {
            var redirectDto = RedirectBusinessModule.GetRedirect(redirectId);
            if (redirectDto == null)
                return new ResultModel
                {
                    Success = false,
                    Message = RedirectResources.app_redirect_not_exist
                };

            var authorizedDomainsReadWrite = GetAuthorizedReadWriteDomain(ControllerRolePattern).Select(x => (short)x);
            if (!authorizedDomainsReadWrite.Contains(redirectDto.DomainId))
            {
                throw new Exception(RedirectResources.app_unauthorized_edit);
            }

            if (redirectDto.DeletionDate.HasValue)
            {
                return new ResultModel
                {
                    Success = false,
                    Message = RedirectResources.app_already_delete_error
                };
            }

            redirectDto.DeletionUser = ApplicationUser.Identity.Name;
            redirectDto.DeletionDate = DateTime.Now;
            var result = RedirectBusinessModule.DeleteRedirect(redirectDto);
            return new ResultModel
            {
                Success = result,
                Message = result ? RedirectResources.app_delete_success : RedirectResources.app_delete_error
            };


        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/history/{redirectId:int}")]
        public ResultModel History(int redirectId)
        {
            var historyViewModel = new
            {
                HistoryItems = GetRedirectHistories(redirectId)
            };
            return GetSuccessResultModel(string.Empty, historyViewModel);
        }

        #region Publication 

        // Affichage des domaines pour lesquelles on souhaite effectuer une publication
        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/publication")]
        public ActionResult Publication()
        {
            var authorizedReadWriteDomain = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedReadWriteDomain.Contains((EnumDomain)d.DomainId));

            ViewBag.Domains = DomainModelMapper.DtosToModels(domains).ToList();
            var model = new PublicationDomainsViewModel()
            {
                DomainsToPublish = DomainModelMapper.DtosToModels(domains).ToList()
            };

            return View(model);
        }

        [HttpPost]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read_Write)]
        [Route("redirect/publish")]
        public JsonResult Publish(int domainId, bool isProduction)
        {
            var authorizedDomains = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedDomains.Contains((EnumDomain)d.DomainId));

            if (domains.Any(d => d.DomainId == domainId))
            {
                bool isPublished = false;
                string errorMessage = null;

                try
                {
                    var domain = DomainBusinessModule.GetDomain((EnumDomain)domainId);
                    isPublished = RedirectBusinessModule.PublishRedirectDomain((EnumDomain)domainId, ApplicationUser.Identity.Name, domain.SiteCode, domain.CultureCode, isProduction);
                }
                catch (Exception exception)
                {
                    Logger.LogError(exception, "Erreur RedirectController - Publish");
                    errorMessage = RedirectResources.app_publish_error;
                }

                if (!isPublished)
                {
                    return Json(new ResultModel()
                    {
                        Success = false,
                        Message = $"{RedirectResources.app_publish_error} - {(EnumDomain)domainId} !"
                    });
                }
            }
            else
            {
                return Json(new ResultModel()
                {
                    Success = false,
                    Message = $"{RedirectResources.app_publish_unauthorized} - {(EnumDomain)domainId} !"
                });
            }

            return Json(new ResultModel()
            {
                Success = true,
                Message = RedirectResources.app_publish_ok
            });
        }


        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/getdraftredirects/{domainId:int}")]
        public ResultModel GetDraftRedirects(int domainId)
        {
            if (!Enum.IsDefined(typeof(EnumDomain), domainId))
            {
                Logger.LogError("Erreur RedirectController - GetdraftRedirects", $"Parametre invalide domainId : {domainId}");
                return GetGenericFailureResultModel($"{RedirectResources.app_url_search_error} Parametre invalide");
            }

            var authorizedDomains = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedDomains.Contains((EnumDomain)d.DomainId));

            try
            {
                var draftRedirects = RedirectBusinessModule.GetDraftRedirect((EnumDomain)domainId);

                var data = GetHistoryViewModel(draftRedirects);

                return GetSuccessResultModel(string.Empty, data);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, "Erreur RedirectController - GetDraftRedirects");
                return GetGenericFailureResultModel($"{RedirectResources.app_url_search_error} {exception.Message}");
            }
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/getpublicationrequesthistory/{domainId:int}")]
        public ResultModel GetPublicationRequestHistory(int domainId)
        {
            if (!Enum.IsDefined(typeof(EnumDomain), domainId))
            {
                Logger.LogError("Erreur RedirectController - GetPublicationRequestHistory", $"Parametre invalide domainId : {domainId}");
                return GetGenericFailureResultModel($"{RedirectResources.app_url_search_error} Parametre invalide");
            }

            var authorizedDomains = GetAuthorizedReadWriteDomain(ControllerRolePattern);
            var domains = DomainBusinessModule.GetDomains().Where(d => authorizedDomains.Contains((EnumDomain)d.DomainId));

            try
            {
                var historyPublication = RedirectBusinessModule.GetPublicationRequestHistory((EnumDomain)domainId)
                                                        .OrderByDescending(h => h.PublicationRequestDate);

                var currentPublicationRequest = RedirectBusinessModule.GetCurrentPublicationRequest((EnumDomain)domainId);
                var data = historyPublication.Select(item =>
                    new PublicationRequestViewModel
                    {
                        PublicationRequestId = item.PublicationRequestId,
                        PublicationRequestDate = item.PublicationRequestDate.ToString("yyyy/MM/dd HH:mm:ss"),
                        PublicationRequestUser = item.PublicationRequestUser,
                        DomainId = item.DomainId,
                        IsPublishable = currentPublicationRequest != null && item.PublicationRequestId < currentPublicationRequest.PublicationRequestId,
                        IsCurrentPublication = currentPublicationRequest != null && item.PublicationRequestId == currentPublicationRequest.PublicationRequestId
                    })
                    .ToList();

                return GetSuccessResultModel(string.Empty, data);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, "Erreur RedirectController - GetPublicationRequestHistory");
                return GetGenericFailureResultModel($"{RedirectResources.app_url_search_error} {exception.Message}");
            }
        }

        [HttpGet]
        [Authorize(Policy = AuthorizePolicyConsts.Redirect_Read)]
        [Route("redirect/getpublicationrequestdetails/{publicationRequestId:int}/{domainId:int}")]
        public ResultModel GetPublicationRequestDetails(int publicationRequestId, int domainId)
        {
            try
            {
                var res = RedirectBusinessModule.GetPublicationRequestDetails(publicationRequestId, domainId);
                var data = GetHistoryViewModel(res);

                return GetSuccessResultModel(string.Empty, data);
            }
            catch (Exception exception)
            {
                Logger.LogError(exception, "Erreur RedirectController - GetPublicationRequestDetails");
                return GetGenericFailureResultModel($"{RedirectResources.app_url_search_error} {exception.Message}");
            }
        }


        #endregion


        private IEnumerable<RedirectHistoryViewModel> GetRedirectHistories(int redirectId)
        {
            var redirectHistory = RedirectBusinessModule.GetRedirectHistory(redirectId);
            if (redirectHistory != null)
            {
                return GetHistoryViewModel(redirectHistory);
            }

            return Enumerable.Empty<RedirectHistoryViewModel>();
        }

        private static IEnumerable<RedirectHistoryViewModel> GetHistoryViewModel(IEnumerable<RedirectHistory> redirectHistory)
        {
            return redirectHistory.Select(item => new RedirectHistoryViewModel
            {
                RedirectId = item.RedirectId,
                SourceType = ((EnumSourceTypeTargetType)item.SourceType).ToString(),
                Source = item.Source,
                TargetType = ((EnumSourceTypeTargetType)item.TargetType).ToString(),
                Target = item.Target,
                RedirectType = ((EnumRedirectType)item.RedirectType).ToString(),
                CreationDate = item.CreationDate.ToString("yyyy/MM/dd HH:mm:ss"),
                CreationUser = item.CreationUser,
                PublicationRequestId = item.PublicationRequestId?.ToString() ?? string.Empty,
                PublicationDate = item.PublicationRequestDate?.ToString("yyyy/MM/dd HH:mm:ss") ?? string.Empty,
                PublicationUser = item.PublicationRequestUser ?? string.Empty,
                ActionType = ((EnumActionType)item.ActionTypeId).ToString()
            }).OrderByDescending(h => h.CreationDate);
        }
    }
}
