# File Import

## Description

This page allows to upload a standard csv file inserting all its redirects into the database.

For every line, duplicates (same source and source type as another redirect) and cascades (a redirect to a page which will do another redirection) are checked. The validity of every value is also checked. 

If any error is found, the file is rejected and a detailed report is presented. If the file is correct, the redirects are added to the database, ready to be published.

The file to be imported follows a template. If this template is not followed, the file will be rejected.

## Template

### Separators

The imported file must use ";" as separator, this is the standard in french-localized Excel.

### Headers

| Source | SourceType | Target | TargetType | RedirectType |

These headers are mandatory and need to be on the first line of the file.
The order of the columns is not important.

### Allowed values

The same rules as manual redirect add applie here.
Numerical values or Names are allowed. 

#### SourceType / TargetType

        Url / 0
        Path / 1
        Node / 2
        CommunityPost / 3
        CommunityTag / 4
        Product / 5
        ProductPureMarketPlace / 6
        Brand / 7
        Format / 8
        Work / 9
        Artist / 10
        Series / 11
        CommunityContributor / 12
        Store / 13
        CommunitySecondaryHome / 14

// TODO: these rules will change


#### RedirectType

        MovedPermanently / 301
        Found / 302


#### Source / Target

Validation rules are used on Source and Target fields :


| Source/TargetType      | Validation Rules                     |
|------------------------|--------------------------------------|
| Node                   | Number                               |
| Artist                 | Number                               |
| Brand                  | Number                               |
| Series                 | Number                               |
| CommunityPost          | Number                               |
| Product                | Number                               |
| ProductPureMarketPlace | Number                               |
| Url                    | Valid URL (https://fnac.com/aaaa)    |
| Path                   | Valid Path (/s123)                   |
| Other                  | No Validation                        |