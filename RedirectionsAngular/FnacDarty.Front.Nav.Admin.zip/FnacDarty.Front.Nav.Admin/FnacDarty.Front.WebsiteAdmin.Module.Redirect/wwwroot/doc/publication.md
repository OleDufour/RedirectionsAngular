<link rel='stylesheet'   type = 'text/css' href='badge.css'> 
<link rel='stylesheet'   type = 'text/css' href='md-styles.css'> 

# Publication

This help page applies to the publish functionality for 
* Url decorations and
* Redirections
 
The publish page for both comprises two sections : 
* Drafts (Brouillons) (see under 1. Drafts)
* Publication history for production (see under 2. Publication history for production)

Publishing in preview will not change the display of any of the sections.  
Redirections and url decorations will hereafter referred to as 'entries'.

## 1. Drafts
 
Drafts are all entries that were created, modified or deleted after the latest publication in production.  
They are displayed in the upper part of the publication page.

Entries added after the last publication in production: <span class="badge badge-success">Added</span><br/>
Entries modified after the last publication in production: <span class="badge badge-secondary">Modified</span><br/>
Entries deleted after the last publication in production:  <span class="badge badge-warning">Deleted</span>

An entry both created and deleted after the latest publication in production will not be displayed.

## 2. Publication history for production

Entries published in preview will not come up in the publication section (lower part of the publication page)  
A publication in production: 
1) deletes all current publications 
2) publishes all drafts and removes the deleted elements.
3) removes all drafts.
