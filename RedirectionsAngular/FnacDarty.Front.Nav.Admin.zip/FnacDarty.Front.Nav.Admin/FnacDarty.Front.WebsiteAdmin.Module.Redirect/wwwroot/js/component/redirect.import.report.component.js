define(["Vue"],
    function (Vue) {
        let reportComponent = Vue.component('redirect-import-report', {
            template: `
            <table class="base-table">
                <tr class="header">
                    <th style="width:10%;">Ligne</th>
                    <th>Erreurs</th>
                </tr>
                <tr v-for="report in reports">
                    <td style="text-align:center;"> {{ report.Line }} </th>
                    <td>
                        <ul>
                            <li v-for="error in report.Errors">
                                {{ error }}
                            </li>
                        </ul>
                    </td>
                </tr>
            </table>
        `,
            props: {
                reports: {
                    type: [Array, Object]
                }
            }
        })
        return reportComponent;
    });