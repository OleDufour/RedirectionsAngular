var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Redirect = fnacdarty.Portal.Repository.Redirect || {};

define(["jquery", "core", "template", "Vue"],

    function ($, core, template, Vue) {

        let InitRows = function (items) {
            var rows = [];
            if (Array.isArray(items)) {
                items.forEach(function (item) {
                    var row = [];

                    var stateRow = '';
                    if (item.ActionType === "Delete") {
                        stateRow = `<span class="badge badge-warning">${fnacdarty.Portal.Repository.Redirect.Wording.Deleted}</span>`;
                    } else if (item.ActionType === "Add") {
                        stateRow = `<span class="badge badge-success">${fnacdarty.Portal.Repository.Redirect.Wording.Added}</span>`;
                    } else if (item.ActionType === "Update") {
                        stateRow = `<span class="badge badge-secondary">${fnacdarty.Portal.Repository.Redirect.Wording.Modified}</span>`;
                    }
                    row.push(item.SourceType);
                    row.push(item.Source);
                    row.push(item.TargetType);
                    row.push(item.Target);
                    row.push(item.RedirectType);
                    row.push(item.CreationDate);
                    row.push(stateRow);
                    row.push(item.CreationUser);
                    row.push(item.PublicationDate);
                    row.push(item.PublicationUser);
                    row.push(item.PublicationRequestId);

                    rows.push(row);
                });
            }
            return rows;
        };

        let historyComponent = Vue.component('data-table-redirect-history', {
            template: '<table class="table table-striped display wrapper" width="100%"></table>',
            props: ['historyitems'],
            data() {
                return {
                    headers: [
                        { title: fnacdarty.Portal.Repository.Redirect.Wording.SourceType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.Source }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.TargetType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.Target }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.RedirectType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.DateAction }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.ActionType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.UserAction }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.PublishedDate }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.PublishedBy }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.PublicationId }
                    ]
                };
            },
            watch: {
                historyitems(val, oldVal) {
                    var vm = this;
                    vm.rows = InitRows(val);
                    vm.dtHandle.clear();
                    vm.dtHandle.rows.add(vm.rows);
                    vm.dtHandle.draw();
                }
            },
            mounted() {
                var vm = this;
                vm.rows = InitRows(vm.historyitems);
                vm.dtHandle = $(this.$el).DataTable({
                    columns: vm.headers,
                    data: vm.rows,
                    responsive: true,
                    columnDefs: [
                        { width: 50, targets: 5 }
                    ],
                    language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                    aLengthMenu: [
                        [10, 25, 50, 100, -1],
                        [10, 25, 50, 100, "Tous"]
                    ],
                    bDestroy: true,
                    drawCallback: function () {
                        template.hideLoader();
                        template.tooltipsPopovers();
                    }
                });
            }
        });

        // module definition
        return historyComponent;
    });
