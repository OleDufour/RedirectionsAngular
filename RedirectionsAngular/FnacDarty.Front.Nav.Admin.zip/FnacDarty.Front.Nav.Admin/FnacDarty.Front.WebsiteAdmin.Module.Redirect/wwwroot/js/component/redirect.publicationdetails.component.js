var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Redirect = fnacdarty.Portal.Repository.Redirect || {};

define(["jquery", "core", "template", "Vue"],

    function ($, core, template, Vue) {

        let publicationDetailsComponent = Vue.component('data-table-redirect-publication-details', {
            template: '<table class="table table-striped display wrapper" width="100%"></table>',
            props: ['publicationsdetails', 'showhistorybutton', 'modalid'],
            data() {
                return {
                    headers: [
                        { title: fnacdarty.Portal.Repository.Redirect.Wording.SourceType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.Source }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.TargetType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.Target }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.RedirectType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.DateAction }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.ActionType }
                        , { title: fnacdarty.Portal.Repository.Redirect.Wording.UserAction }
                        , { title: '#' }
                    ],
                    rows: [],
                    dtHandle: null,
                    models: []
                };
            },
            watch: {
                publicationsdetails(val) {
                    console.log('publicationsdetails');
                    console.log(val);
                    this.updateData(val);
                }
            },
            methods: {
                updateData(data) {
                    var vm = this;
                    vm.models = data;
                    vm.rows = [];
                    
                    if (vm.models && vm.models.length > 0) {
                        vm.models.forEach(function (item) {
                            var row = [];

                            var stateRow = '';
                            if (item.ActionType === "Delete") {
                                stateRow = `<span class="badge badge-warning">${fnacdarty.Portal.Repository.Redirect.Wording.Deleted}</span>`;
                            } else if (item.ActionType === "Add") {
                                stateRow = `<span class="badge badge-success">${fnacdarty.Portal.Repository.Redirect.Wording.Added}</span>`;
                            } else if (item.ActionType === "Update") {
                                stateRow = `<span class="badge badge-secondary">${fnacdarty.Portal.Repository.Redirect.Wording.Modified}</span>`;
                            }

                            var actionsRow = '<div class="btn-group">';
                            //edit button
                            actionsRow = actionsRow +
                                '<a href="'
                                + fnacdarty.Portal.Repository.Redirect.EditUrl
                                + '/' + item.RedirectId
                                + '" target="_blank" class=" btn btn-sm btn-info" rel="tooltip" data-container="body" data-animate="animated tada" data-toggle="tooltip" data-original-title="'
                                + fnacdarty.Portal.Repository.Redirect.Wording.Modify
                                + '"> <i class="fa fa-pencil"></i></a>';

                            if (vm.showhistorybutton) {
                                actionsRow = actionsRow + '<button style="margin-right:5px;" class="btn btn-sm btn-warning" data-RedirectId="'
                                    + item.RedirectId
                                    + '" data-toggle="modal" data-toggle="modal" data-container="body" data-target="#' + vm.modalid + '" rel="tooltip" data-animate="animated tada" data-original-title="'
                                    + fnacdarty.Portal.Repository.Redirect.Wording.History
                                    + '"><i class="fa fa-history"></i></button>';
                            }
                            actionsRow = actionsRow + '</div>';

                            row.push(item.SourceType);
                            row.push(item.Source);
                            row.push(item.TargetType);
                            row.push(item.Target);
                            row.push(item.RedirectType);
                            row.push(item.CreationDate);
                            row.push(stateRow);
                            row.push(item.CreationUser);
                            row.push(actionsRow);


                            vm.rows.push(row);
                        });
                    }
                    vm.dtHandle.clear();
                    vm.dtHandle.rows.add(vm.rows);
                    vm.dtHandle.draw();

                }
            },
            mounted() {
                var vm = this;
                vm.dtHandle = $(this.$el).DataTable({
                    columns: vm.headers,
                    data: vm.rows,
                    responsive: true,
                    columnDefs: [
                        { width: 70, targets: 8, "orderable": false}
                    ],
                    language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                    aLengthMenu: [
                        [10, 25, 50, 100, -1],
                        [10, 25, 50, 100, "Tous"]
                    ],
                    bDestroy: true,
                    drawCallback: function () {
                        template.hideLoader();
                        template.tooltipsPopovers();
                    }
                });
            }
        });

        // module definition
        return publicationDetailsComponent;
    });
