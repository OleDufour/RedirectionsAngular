var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Redirect = fnacdarty.Portal.Repository.Redirect || {};

fnacdarty.Portal.Repository.Redirect.Save = function (model, callback) {

    $.ajax({
        type: "POST",
        url: fnacdarty.Portal.Repository.Redirect.SaveUrl,
        dataType: "json",
        data: model,
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : Redirect.Save" });
        }
    });
};

fnacdarty.Portal.Repository.Redirect.GetDomainRedirect = function (model, callback) {

    $.ajax({
        type: "GET",
        url: fnacdarty.Portal.Repository.Redirect.GetDomainRedirectUrl + '/' + model, // url is defined in Index.cshtml
        dataType: "json",
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : GetDomainRedirect" });
        }
    });
};


fnacdarty.Portal.Repository.Redirect.Delete = function (model, callback) {

    $.ajax({
        type: "POST",
        url: fnacdarty.Portal.Repository.Redirect.DeleteRedirectUrl + "/" + model,
        dataType: "json",
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : Redirect.Delete" });
        }
    });
};

fnacdarty.Portal.Repository.Redirect.GetHistory = function (model, callback) {
    $.ajax({
        type: "GET",
        url: fnacdarty.Portal.Repository.Redirect.HistoryUrl+'/'+model.redirectId,
        dataType: "json",
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : UrlRedirect.History" });
        }
    });
};


fnacdarty.Portal.Repository.Redirect.GetPublicationHistory = function (model, callback) {
    $.ajax({
        type: "GET",
        url: fnacdarty.Portal.Repository.Redirect.GetPublicationHistoryUrl+'/'+model.domainId,
        dataType: "json",
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : UrlRedirect.GetPublicationHistory" });
        }
    });
};

fnacdarty.Portal.Repository.Redirect.GetPublicationDetails = function (model, callback) {
    $.ajax({
        type: "GET",
      url: fnacdarty.Portal.Repository.Redirect.GetPublicationDetailsUrl + '/' + model.publicationRequestId+'/' + model.domainId,
        dataType: "json",
        data: model,
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : UrlRedirect.GetPublicationHistory" });
        }
    });
};

 
fnacdarty.Portal.Repository.Redirect.GetDraftRedirects = function (model, callback) {
    $.ajax({
        type: "GET",
        url: fnacdarty.Portal.Repository.Redirect.GetDraftRedirectsUrl+'/'+model.domainId,
        dataType: "json",
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : UrlRedirect.GetDraftRedirects" });
        }
    });
};


fnacdarty.Portal.Repository.Redirect.Publish = function (model, callback) {
    $.ajax({
        type: "POST",
        url: fnacdarty.Portal.Repository.Redirect.PublishRedirectUrl,
        dataType: "json",
        data: model,
        success: function (data) {
            callback(data);
        },
        error: function () {
            callback({ success: false, message: "Erreur Fatale Serveur : Redirect.Publish" });
        }
    });
};

