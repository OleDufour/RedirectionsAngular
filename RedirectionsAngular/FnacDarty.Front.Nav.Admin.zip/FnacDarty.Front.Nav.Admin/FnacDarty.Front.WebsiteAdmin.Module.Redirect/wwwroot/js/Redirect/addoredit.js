var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Redirect = fnacdarty.Portal.Repository.Redirect || {};

define(["jquery", "core", "template", "dropdownComponent", "redirectHistoryComponent", "Vue"],

    function ($, core, template, dropdownComponent, redirectHistoryComponent, Vue) {

        // module definition
        return {
            ready: function (model) {

                var app = new Vue({
                    el: '#main-content',

                    data() {
                        return {
                            viewModel: model,
                            sourceFormatDescription: this.getTargetSourceFormatDescription(model.SourceType),
                            targetFormatDescription: this.getTargetSourceFormatDescription(model.TargetType)
                        };
                    },

                    mounted() {
                        //init common js for template
                        template.intiJsTemplate();
                        template.hideLoader();
                    },

                    components: {
                        dropdownComponent, redirectHistoryComponent
                    },

                    methods:
                    {
                        save: function () {
                            template.displayLoader();
                            var vm = this;
                            var vmModel = vm.viewModel;

                            fnacdarty.Portal.Repository.Redirect.Save(vmModel,
                                function (response) {
                                    template.hideLoader();
                                    if (response.Success) {
                                        template.showMessage(response.Message, "info");
                                        setTimeout(function () {
                                            vm.viewModel.RedirectId = response.Data.RedirectId;
                                            vm.viewModel.History = response.Data.historyitems;
                                        }, 1000);
                                    }
                                    else // element has been deleted or doesn't exist at all in the db.
                                        template.showMessage(response.Message, "error");
                                });
                        },
                        getFlag: function (domain) {
                            switch (domain) {
                                case "NL_BE":
                                case "FR_BE":
                                    return { "flag-icon-be": true };

                                case "ES_ES":
                                    return { "flag-icon-es": true };

                                case "PT_PT":
                                    return { "flag-icon-pt": true };

                                case "FR_CH":
                                    return { "flag-icon-ch": true };

                                default:
                                    return { "flag-icon-fr": true };
                            }
                        },

                        getTargetSourceFormatDescription: function (targetSourceType) {
                            let targetSourceFormatDescription = '';
                            var sourceAndTargetType = [...sourceType_js, ...targetType_js];
                            var sourceTargetWording = sourceAndTargetType.find(sourceTarget => sourceTarget.Value === targetSourceType);                   

                            if (sourceTargetWording) {
                                // pour les validations c�t� serveur :  \Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Module.Redirect\Models\Validation\ValidSourceAndTargetAttribute.cs
                                switch (sourceTargetWording.Text) {
                                    case 'Artist':
                                    case 'Brand':
                                    case 'CommunityPost':
                                    case 'CommunityContributor':
                                    case 'CommunitySecondaryHome':
                                    case 'CommunityTag':
                                    case 'Format':
                                    case 'Node':
                                    case 'Product':
                                    case 'ProductPureMarketPlace':
                                    case 'Series':
                                    case 'Store':
                                    case 'Work':
                                        targetSourceFormatDescription = '<br/>ex : 123456'; break;
                                    case 'Url':
                                        targetSourceFormatDescription = "<br/>ex : https://www.fnac.com/livre.asp"; break;
                                    default:
                                        targetSourceFormatDescription = ''; break;
                                }
                            }
                            return targetSourceFormatDescription;
                        }
                    },

                    computed: {
                        isUpdateMode: function () {
                            return this.viewModel.RedirectId > 0;
                        },
                        isDeletedRedirect: function () {
                            return this.viewModel.IsDeleted;
                        }
                    },

                    watch: {
                        'viewModel.TargetType'(val) {
                            var vm = this;
                            vm.targetFormatDescription = this.getTargetSourceFormatDescription(val);
                        },
                        'viewModel.SourceType'(val) {
                            var vm = this;
                            vm.sourceFormatDescription = this.getTargetSourceFormatDescription(val);
                        }
                    }
                });

                window.app = app;
            }
        };
    });
