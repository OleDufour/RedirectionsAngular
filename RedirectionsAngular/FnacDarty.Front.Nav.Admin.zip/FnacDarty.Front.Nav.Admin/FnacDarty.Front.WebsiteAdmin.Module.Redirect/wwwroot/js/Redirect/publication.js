var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
//fnacdarty.Portal.Repository.Redirect = fnacdarty.Portal.Repository.Redirect || {};
fnacdarty.Portal.Repository.Redirect.Wording = fnacdarty.Portal.Repository.Redirect.Wording || {};
fnacdarty.Portal.Repository.Publish.Wording = fnacdarty.Portal.Repository.Publish.Wording || {};

define(["jquery", "core", "template", "messenger", "Vue", "multipleCheckboxComponent", "vueTabsComponent", "redirectPublicationDetailsComponent", "redirectHistoryComponent"],

    function ($, core, template, messenger, Vue, multipleCheckboxComponent, vueTabsComponent, redirectPublicationDetailsComponent, redirectHistoryComponent) {

        var tab = vueTabsComponent.Tab;
        var tabs = vueTabsComponent.Tabs;

        let publicationHistory = Vue.component('publication-history', {
            template: '<table class="table table-striped display wrapper" width="100%"></table>',
            props: [
                'publicationHistoResultModel',
                'domain'
            ],
            data() {
                return {
                    headers: [
                        { title: fnacdarty.Portal.Repository.Redirect.Wording.PublicationId },
                        { title: fnacdarty.Portal.Repository.Redirect.Wording.PublishedDate },
                        { title: fnacdarty.Portal.Repository.Redirect.Wording.PublishedBy },
                        { title: '#' }
                    ],
                    rows: [],
                    dtHandle: null,
                    models: []
                };
            },
            methods: {
                updatePublicationHistorytData() {
                    var vm = this;
                    fnacdarty.Portal.Repository.Redirect.GetPublicationHistory({ domainId: vm.domain },
                        function (response) {
                            if (response.Success) {
                                vm.models = response.Data;
                                if (vm.models) {
                                    vm.rows = [];
                                    vm.models.forEach(function (item) {
                                        var row = [];

                                        row.push(item.PublicationRequestId);
                                        row.push(item.PublicationRequestDate);
                                        row.push(item.PublicationRequestUser);

                                        var actionsRow = '<div class="btn-group">';

                                        actionsRow = actionsRow + '<button class="btn btn-sm btn-info " data-publicationrequestid="'
                                            + item.PublicationRequestId
                                            + '" data-domainId="'
                                            + vm.domain
                                            + '" data-toggle="modal" data-toggle="modal" data-container="body" data-target="#PublicationDetailsModal" rel="tooltip" data-animate="animated tada" data-original-title="'
                                            + fnacdarty.Portal.Repository.Redirect.Wording.PublicationDetails
                                            + '"><i class="fa fa-info"></i></button>';

                                        actionsRow = actionsRow + '</div>';

                                        row.push(actionsRow);
                                        vm.rows.push(row);
                                    });
                                }
                                vm.dtHandle.clear();
                                vm.dtHandle.rows.add(vm.rows);
                                vm.dtHandle.draw();
                            } else {
                                vm.models = [];
                                vm.dtHandle.clear();
                                vm.dtHandle.rows.add(vm.rows);
                                vm.dtHandle.draw();
                            }
                        });
                }
            },
            mounted() {
                var vm = this;
                vm.dtHandle = $(this.$el).DataTable({
                    searching: false,
                    order: [[0, 'desc']],
                    pagingType: "simple_numbers",
                    columns: vm.headers,
                    data: vm.rows,
                    responsive: true,
                    columnDefs: [
                        { width: 35, targets: 3, "orderable": false }
                    ],
                    language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" }, // cdn doesn't always work
                    lengthMenu: [
                        [5, 10, 25, 50, -1],
                        [5, 10, 25, 50, "Tous"]
                    ],
                    Destroy: true,
                    drawCallback: function () {
                        template.hideLoader();
                        template.tooltipsPopovers();
                    }
                });
            }
        });


        // module definition
        return {

            ready: function (model) {
                var app = new Vue({
                    el: '#main-content',

                    data: {
                        viewModel: model,
                        error: '',
                        hasDraft: false
                    },

                    components: {
                        multipleCheckboxComponent,
                        publicationHistory,
                        redirectPublicationDetailsComponent,
                        redirectHistoryComponent,
                        tab,
                        tabs
                    },

                    created() {
                    },

                    mounted() {
                        var vm = this;
                        template.intiJsTemplate();
                    },

                    methods: {
                        publish(domainId, isProduction) {
                            var vm = this;
                            publish(app, domainId, isProduction, vm);
                        },

                        tabChanged(selectedTab) {
                            this.updateDraft(selectedTab.tab.id);
                            this.updatePublicationHistory(selectedTab.tab.id);
                        },

                        updateComponents(domainId) {
                            this.updateDraft(domainId);
                            this.updatePublicationHistory(domainId);
                        },

                        updateDraft(domainId) {
                            var vm = this;
                            fnacdarty.Portal.Repository.Redirect.GetDraftRedirects({ domainId: domainId },
                                function (response) {                       
                                    if (response.Success) {
                                        if (response.Data && response.Data.length > 0) {
                                            vm.hasDraft = true;
                                            setTimeout(function () {
                                                vm.$refs['draftTable' + domainId][0].publicationsdetails = response.Data;
                                            }, 100);
                                        }
                                        else {
                                            vm.hasDraft = false;
                                            setTimeout(function () {
                                                vm.$refs['draftTable' + domainId][0].publicationsdetails = [];
                                            }, 100);
                                        }
                                    }
                                });
                        },

                        updatePublicationHistory(domainId) {
                            this.$refs['publicationHistoryTable' + domainId][0].updatePublicationHistorytData();
                        },

                        updatePublishButton(hasDraft) {
                            this.hasDraft = hasDraft;
                        }
                    }
                });

                $(window).scroll(function (event) {
                    // A chaque fois que l'utilisateur va scroller (descendre la page)
                    var y = $(this).scrollTop(); // On r�cup�rer la valeur du scroll vertical

                    //si cette valeur > � 100 on ajouter la class
                    if (y >= 100) {
                        $('.tabs-component-tabs').addClass('fixed');
                    } else {
                        // sinon, on l'enl�ve
                        $('.tabs-component-tabs').removeClass('fixed');
                    }
                });

                window.app = app;

                initRedirectHistory();
            }
        };


        function publish(app, domainId, isProduction, vm) {
            template.displayLoader();
            app.error = '';
            var msg = Messenger().post({
                message: fnacdarty.Portal.Repository.Publish.Wording.PublishQuestion,
                type: 'info',
                actions: {
                    cancel: {
                        label: fnacdarty.Portal.Repository.Publish.Wording.No,
                        action: function () {
                            msg.update({
                                message: fnacdarty.Portal.Repository.Publish.Wording.PublishCanceled,
                                type: 'success',
                                actions: true,
                                showCloseButton: true
                            });
                        }
                    },
                    confirm: {
                        label: fnacdarty.Portal.Repository.Publish.Wording.Yes,
                        action: function () {
                            template.displayLoader();
                            var responsePublish = function (response) {
                                if (response.Success) {
                                    msg.update({
                                        message: response.Message,
                                        type: 'success',
                                        actions: true,
                                        showCloseButton: true
                                    });

                                    if (isProduction) {
                                        vm.updateDraft(domainId);
                                        vm.updatePublicationHistory(domainId);
                                    }
                                } else {
                                    msg.update({
                                        message: response.Message,
                                        type: 'error',
                                        actions: false,
                                        showCloseButton: true
                                    });
                                }
                                template.hideLoader();
                            };
                            // defined in redirect.repository :
                            fnacdarty.Portal.Repository.Redirect.Publish({ domainId: domainId, isProduction: isProduction }, responsePublish);
                        }
                    }
                }
            });

            template.hideLoader();
        }

        function initRedirectHistory() {
            $("#PublicationHistoryModal").on("shown.bs.modal", function (event) {
                var button = $(event.relatedTarget);
                var redirectId = button.data("redirectid");
                template.displayLoader();

                // R�cup�ration de l'historique
                fnacdarty.Portal.Repository.Redirect.GetHistory({ redirectId: redirectId },
                    function (response) {
                        if (response.Success) {
                            app.$refs['refPublicationHistoryModal'].historyitems = response.Data.HistoryItems;
                        } else {
                            app.$refs['refPublicationHistoryModal'].historyitems = [];
                        }
                        template.hideLoader();
                    });
            });

            $("#PublicationDetailsModal").on("shown.bs.modal", function (event) {
                var button = $(event.relatedTarget);
                var publicationRequestId = button.data("publicationrequestid");
                var domainId = button.data("domainid");
                template.displayLoader();

                // R�cup�ration de l'historique            
                fnacdarty.Portal.Repository.Redirect.GetPublicationDetails({ publicationRequestId: publicationRequestId, domainId: domainId },
                    function (response) {
                        if (response.Success && response.Data !== null) {
                            setTimeout(function () {
                                app.$refs['refPublicationDetailsModal'].publicationsdetails = response.Data;
                            }, 100);
                        } else {
                            setTimeout(function () {
                                app.$refs['refPublicationDetailsModal'].publicationsdetails = [];
                            }, 100);
                        }
                       
                        template.hideLoader();
                    });
            });
        }
    });