var fnacdarty = fnacdarty || {};
fnacdarty.Portal = fnacdarty.Portal || {};
fnacdarty.Portal.Repository = fnacdarty.Portal.Repository || {};
fnacdarty.Portal.Repository.Redirect = fnacdarty.Portal.Repository.Redirect || {};
var wording = fnacdarty.Portal.Repository.Redirect.Wording;

var sourceTypes = JSON.parse(fnacdarty.Portal.Repository.Redirect.SourceTypes);
var targetTypes = JSON.parse(fnacdarty.Portal.Repository.Redirect.TargetTypes);
var redirectTypes = JSON.parse(fnacdarty.Portal.Repository.Redirect.RedirectTypes);

var dropdownData = { sourceTypes: sourceTypes, targetTypes: targetTypes, redirectTypes: redirectTypes };

// Type de source, type de cible, redirection type. 
// TargetType : we can't take 0 as a default value since 0 = 'Url' (see \Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Constant\EnumSourceTypeTargetType.cs)
var menuDeroulantDefaultValue = -1; 

define(["jquery", "Vue", "core", "template", "datatables", "moment", "messenger", "redirectHistoryComponent", "dropdownComponent"],

    function ($, Vue, core, template, datatables, moment, messenger, redirectHistoryComponent, dropdownComponent) {


        // module definition
        return {
            ready: function () {

                let colummNames = ["RedirectId", "SourceTypeString", "Source", "TargetTypeString", "Target", "RedirectTypeString"];

                let columnDefinition = [
                    { "data": colummNames[0] }, // RedirectId
                    { "data": colummNames[1], "orderable": false }, // Types de source
                    { "data": colummNames[2] }, // Source
                    { "data": colummNames[3], "orderable": false }, // Types de cible
                    { "data": colummNames[4] },  // Cible
                    { "data": colummNames[5], "orderable": false }  // Types de redirection
                ];
                var viewModel = {
                    SearchFilters: {
                        Domain: '',
                        SourceType: menuDeroulantDefaultValue,
                        Source: '',
                        TargetType: menuDeroulantDefaultValue,
                        Target: '',
                        RedirectType: menuDeroulantDefaultValue,
                        IncludeDeletions: false
                    },
                    ShowResult: false,
                    HistoryItems: [],
                    error: '' // to show when we get a 500 from the server
                };

                var app = new Vue({
                    el: '#main-content',
                    data: viewModel,
                    components: {
                        redirectHistoryComponent, dropdownComponent
                    },
                    methods: {
                        updateDomain: function (selectedOption) {
                            this.SearchFilters.Domain = selectedOption.value;
                        },
                        updateSourceType: function (selectedOption) {
                            this.SearchFilters.SourceType = selectedOption.value ? selectedOption.value : menuDeroulantDefaultValue;
                        },
                        updateTargetType: function (selectedOption) {
                            this.SearchFilters.TargetType = selectedOption.value ? selectedOption.value : menuDeroulantDefaultValue;
                        },
                        updateRedirectType: function (selectedOption) {
                            this.SearchFilters.RedirectType = selectedOption.value ? selectedOption.value : menuDeroulantDefaultValue;
                        },
                        SearchRedirects: function () {
                            template.displayLoader();
                            var $table = $("#Redirect-Table");
                            var vm = this;
                            $table.dataTable({
                                searching: false,
                                autoWidth: false,
                                order: [[0, "asc"]],
                                responsive: true,
                                language: { url: "../conf/dataTables.languagePlugin.1.10.7." + fnacdarty.language + ".json" },
                                lengthMenu: [
                                    [10, 25, 50, 100],
                                    [10, 25, 50, 100]
                                ],
                                processing: true,
                                serverSide: true,
                                ajax: {
                                    url: fnacdarty.Portal.Repository.Redirect.DataTableUrl,
                                    method: "POST",
                                    "data": function (d) {
                                        d.domainId = vm.SearchFilters.Domain;
                                        d.IncludeDeletions = vm.SearchFilters.IncludeDeletions;
                                        d.columns[1].search.value = vm.SearchFilters.SourceType;
                                        d.columns[2].search.value = vm.SearchFilters.Source;
                                        d.columns[3].search.value = vm.SearchFilters.TargetType;
                                        d.columns[4].search.value = vm.SearchFilters.Target;
                                        d.columns[5].search.value = vm.SearchFilters.RedirectType;
                                    }
                                },
                                bDestroy: true,
                                columns: columnDefinition,
                                aoColumnDefs: [

                                    {
                                        "targets": [0],
                                        "visible": false
                                    },
                                    {
                                        "aTargets": [6],
                                        "width": '100px',

                                        "mData": "RedirectId",
                                        "mRender": function (data, type, full) {
                                            var hidden = full.DeletionDate ? "style='visibility: hidden'" : ''; // l'élément doit prendre de la place
                                            var result = '<div class="btn-group">';
                                            result += full.ReadOnly ? '' : '<a href="' + fnacdarty.Portal.Repository.Redirect.EditRedirectUrl + '/' + full.RedirectId + '" class="btn btn-sm btn-info"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-container="body" data-original-title="' + fnacdarty.Portal.Repository.Redirect.Wording.Modify + '" data-placement="top"> <i class="fa fa-pencil"></i></a>';
                                            result += '<a ' + hidden + 'data-RedirectId="' + full.RedirectId + '" class="btn btn-sm btn-danger js-Redirect-delete"  rel="tooltip" data-animate=" animated tada" data-toggle="tooltip" data-container="body" data-original-title="' + fnacdarty.Portal.Repository.Redirect.Wording.Delete + '"  data-placement="top"> <i class="fa fa-trash"></i></a>';
                                            result += '<a data-redirectId="' + full.RedirectId + '" class="btn btn-sm btn-warning " data-toggle="modal" data-container="body" data-target="#HistoryModal" rel="tooltip" data-animate="animated tada" data-original-title="' + fnacdarty.Portal.Repository.Redirect.Wording.History + '" data-placement="top"><i class="fa fa-history"></i></a>';
                                            result += '</div>';
                                            return result;
                                        }
                                    }
                                ],
                                drawCallback: function (settings) {
                                    template.hideLoader();
                                    template.tooltipsPopovers();
                                    addDeleteEvent();
                                }
                            });

                            vm.ShowResult = true;

                            setTimeout(function () {
                                $('html,body').animate({
                                    scrollTop: $("#searchResult").offset().top
                                }, 'slow');
                            }, 200);
                        }

                    },
                    mounted() {
                        this.SearchFilters.Domain = dropdown_domain_selection.value;
                    }
                });
                moment.locale('fr');
                //common init template js
                template.intiJsTemplate();
                //template.displayLoader();

                function addDeleteEvent() {
                    const { DeleteQuestion, DeleteCanceled } = fnacdarty.Portal.Repository.Redirect.Wording;

                    //Add click event for anchor
                    $(".js-Redirect-delete").unbind("click");
                    $(".js-Redirect-delete").click(function (e) {
                        var RedirectId = $(this).attr('data-RedirectId');
                        var msg = Messenger().post({
                            message: DeleteQuestion,
                            type: 'info',
                            actions: {
                                cancel: {
                                    label: wording.No,
                                    action: function () {
                                        return msg.update({
                                            message: DeleteCanceled,
                                            type: 'success',
                                            actions: true,
                                            showCloseButton: true
                                        });
                                    }
                                },
                                confirm: {
                                    label: wording.Yes,
                                    action: function () {
                                        fnacdarty.Portal.Repository.Redirect.Delete(RedirectId,
                                            function (response) {
                                                if (response.Success) {
                                                    msg.update({
                                                        message: response.Message,
                                                        type: 'success',
                                                        actions: true,
                                                        showCloseButton: true
                                                    });
                                                    $(`.js-Redirect-delete[data-redirectid='${RedirectId}']`).css('visibility', 'hidden');
                                                } else {
                                                    msg.update({
                                                        message: response.Message,
                                                        type: 'error',
                                                        actions: false,
                                                        showCloseButton: true
                                                    });
                                                }

                                            });
                                    }

                                }
                            }
                        });
                        return false;
                    });
                }


                core.log("module ready");


              $("#HistoryModal").on("shown.bs.modal", function (event) {
                    var button = $(event.relatedTarget);
                    var redirectId = button.data("redirectid");
                    app.HistoryItems = [];
                    template.displayLoader();
                    // Récupération de l'historique
                    fnacdarty.Portal.Repository.Redirect.GetHistory({ redirectId: redirectId },
                        function (response) {
                            if (response.Success) {
                                app.HistoryRealUrl = response.Data.RealUrl;
                                app.HistoryItems = response.Data.HistoryItems;
                            } else {
                                app.HistoryRealUrl = "";
                                app.HistoryItems = [];
                            }
                            template.hideLoader();
                        });
                });

            }
        };
    });
