using System;

namespace FnacDarty.Front.WebsiteAdmin.Module.Redirect.Exceptions
{
    public class InvalidRedirectException : Exception
    {
    }
}
