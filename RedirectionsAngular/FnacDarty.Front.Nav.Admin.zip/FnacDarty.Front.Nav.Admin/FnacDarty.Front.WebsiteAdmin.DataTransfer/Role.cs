using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.DataTransfer
{
    public class Role
    {
        [Required]
        public int RoleId { get; set; }

        [StringLength(100)]
        public string RoleName { get; set; }
    }
}
