namespace FnacDarty.Front.WebsiteAdmin.DataTransfer
{
    public class PublishedRewriteDto
    {
        public string RewrittenUrl { get; set; }
        public string MobileRealUrl { get; set; }
        public string DesktopRealUrl { get; set; }
    }
}
