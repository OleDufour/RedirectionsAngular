using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.DataTransfer
{
    public class Domain
    {
        public short DomainId { get; set; }

        [Required]
        [StringLength(10)]
        public string DomainCode { get; set; }

        [Required]
        [StringLength(5)]
        public string CultureCode { get; set; }

        [Required]
        [StringLength(50)]
        public string SiteCode { get; set; }

        [Required]
        [StringLength(50)]
        public string DomainName { get; set; }

        [Required]
        [StringLength(100)]
        public string DomainUrl { get; set; }
    }
}
