using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FnacDarty.Front.WebsiteAdmin.DataTransfer
{
    public class User
    {
        public User()
        {
            Roles = new HashSet<Role>();
        }
        [Required]
        public Guid UserId { get; set; }

        [Required]
        [StringLength(200)]
        public string Login { get; set; }

        [Required]
        public bool IsAdmin { get; set; }

        public virtual ICollection<Role> Roles { get; set; }
    }
}
