﻿using FnacDarty.Front.WebsiteAdmin.Constant;

namespace FnacDarty.Front.WebsiteAdmin.DataTransfer
{
    public class PublishedUrlRedirectDto
    {
        public int RedirectId { get; set; }
        public int DomainId { get; set; }
        public EnumSourceTypeTargetType SourceType { get; set; }
        public string Source { get; set; }
        public EnumSourceTypeTargetType TargetType { get; set; }
        public string Target { get; set; }
        public EnumRedirectType RedirectType { get; set; }
        
    }
}
