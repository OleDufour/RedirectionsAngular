using FnacDarty.Front.WebsiteAdmin.Infrastructure;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Menu;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;

namespace FnacDarty.Front.WebsiteAdmin.Module.Template
{
    public class ModuleRegistration : ModuleRegistrationBase
    {
        public override IServiceCollection RegisterServices(IServiceCollection services)
        {
            return services;
        }

        public override AuthorizationOptions RegisterAuthorizations(AuthorizationOptions authorizationOptions)
        {
            return authorizationOptions;
        }

        public override IDynamicMenuBuilder RegisterMenu(IDynamicMenuBuilder menuBuilder)
        {
            return menuBuilder;
        }
    }
}
