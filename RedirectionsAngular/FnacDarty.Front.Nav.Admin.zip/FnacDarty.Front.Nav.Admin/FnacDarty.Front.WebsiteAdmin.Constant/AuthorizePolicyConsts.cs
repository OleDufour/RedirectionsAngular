namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public static class AuthorizePolicyConsts
    {
        public const string Admin = "Admin";
        public const string Redirect_Read_Write = "Redirect_Read_Write";
        public const string Redirect_Read = "Redirect_Read";
        public const string Rewrite_Read_Write = "Rewrite_Read_Write";
        public const string Rewrite_Read = "Rewrite_Read";
    }
}
