namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public enum EnumActionType
    {
        Add = 1,
        Update = 2,
        Delete = 3
    }
}
