namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public enum EnumEnv
    {
        Preview,
        Prod
    }
}
