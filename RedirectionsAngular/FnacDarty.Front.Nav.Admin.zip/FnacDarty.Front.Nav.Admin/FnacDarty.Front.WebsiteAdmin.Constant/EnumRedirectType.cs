using System.Net;

namespace FnacDarty.Front.WebsiteAdmin.Constant
{ 
    public enum EnumRedirectType
    {        
        MovedPermanently = HttpStatusCode.MovedPermanently,
        Found = HttpStatusCode.Found
    }
}
