namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public enum EnumDomain
    {
        FR_FR = 1,
        FR_FR_PRO = 2,
        FR_BE = 3,
        NL_BE = 4,
        FR_CH = 5,
        PT_PT = 6,
        ES_ES = 7
    }
}
