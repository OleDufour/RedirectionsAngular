namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public enum EnumRewriteType
    {
        Search = 1,
        Node = 2
    }
}
