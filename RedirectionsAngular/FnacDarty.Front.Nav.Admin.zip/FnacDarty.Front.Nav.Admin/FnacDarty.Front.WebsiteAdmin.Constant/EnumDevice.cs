namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public enum EnumDevice
    {
        Desktop = 1,
        Mobile = 2
    }
}
