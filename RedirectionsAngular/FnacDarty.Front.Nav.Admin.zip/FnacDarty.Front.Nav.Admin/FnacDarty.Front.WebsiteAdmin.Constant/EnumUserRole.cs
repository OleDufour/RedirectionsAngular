namespace FnacDarty.Front.WebsiteAdmin.Constant
{
    public enum EnumUserRole
    {
        URL_FR_FR_READ = 1,
        URL_FR_FR_WRITE = 2,
        URL_FR_FR_PRO_READ = 3,
        URL_FR_FR_PRO_WRITE = 4,
        URL_FR_BE_READ = 5,
        URL_FR_BE_WRITE = 6,
        URL_NL_BE_READ = 7,
        URL_NL_BE_WRITE = 8,
        URL_FR_CH_READ = 9,
        URL_FR_CH_WRITE = 10,
        URL_PT_PT_READ = 11,
        URL_PT_PT_WRITE = 12,
        URL_ES_ES_READ = 13,
        URL_ES_ES_WRITE = 14,
        REDIRECT_FR_FR_READ = 29,
        REDIRECT_FR_FR_WRITE = 30,
        REDIRECT_FR_FR_PRO_READ = 31,
        REDIRECT_FR_FR_PRO_WRITE = 32,
        REDIRECT_FR_BE_READ = 33,
        REDIRECT_FR_BE_WRITE = 34,
        REDIRECT_NL_BE_READ = 35,
        REDIRECT_NL_BE_WRITE = 36,
        REDIRECT_FR_CH_READ = 37,
        REDIRECT_FR_CH_WRITE = 38,
        REDIRECT_PT_PT_READ = 39,
        REDIRECT_PT_PT_WRITE = 40,
        REDIRECT_ES_ES_READ = 41,
        REDIRECT_ES_ES_WRITE = 42,
        PAYMENTCONFIGURATION_WRITE = 43
    }
}
