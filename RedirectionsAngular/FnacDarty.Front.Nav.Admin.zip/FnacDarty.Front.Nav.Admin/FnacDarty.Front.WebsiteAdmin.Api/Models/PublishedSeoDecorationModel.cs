namespace FnacDarty.Front.WebsiteAdmin.Api.Models
{
    public class PublishedSeoDecorationModel
    {
        public string MobileRealUrl { get; set; }
        public string DesktopRealUrl { get; set; }
        public string Title { get; set; }
        public string MetaDescription { get; set; }
        public string H1Tag { get; set; }
        public string SeoData { get; set; }
    }
}
