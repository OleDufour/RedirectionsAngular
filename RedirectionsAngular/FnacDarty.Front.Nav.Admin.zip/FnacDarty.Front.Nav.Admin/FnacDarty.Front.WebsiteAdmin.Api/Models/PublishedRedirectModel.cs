using FnacDarty.Front.WebsiteAdmin.Constant;

namespace FnacDarty.Front.WebsiteAdmin.Api.Models
{
    public class PublishedRedirectModel
    {
        public EnumSourceTypeTargetType SourceType { get; set; }
        public string Source { get; set; }
        public EnumSourceTypeTargetType TargetType { get; set; }
        public string Target { get; set; }
        public EnumRedirectType HttpCode { get; set; }
    }
}
