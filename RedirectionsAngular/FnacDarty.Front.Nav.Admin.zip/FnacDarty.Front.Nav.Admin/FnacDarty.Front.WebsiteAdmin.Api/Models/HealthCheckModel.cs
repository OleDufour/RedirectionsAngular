namespace FnacDarty.Front.WebsiteAdmin.Api.Models
{
    public class HealthCheckModel
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string MemoryUsage { get; set; }
        public string MachineName { get; set; }
        public string Version { get; internal set; }
    }
}
