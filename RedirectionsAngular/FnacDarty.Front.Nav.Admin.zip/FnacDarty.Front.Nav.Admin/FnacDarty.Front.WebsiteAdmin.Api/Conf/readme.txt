Lancer le configmerge en remplaçant [$GIT] par le chemin du repo GIT sur votre poste :
	* LOCAL :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Api [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.LOCAL.FR.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.LOCAL.FR.functional.properties

	* DEV2 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Api [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.DEV2.FR.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.DEV2.FR.functional.properties

	* REC6 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Api [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.REC6.FR.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.REC6.FR.functional.properties

	* REC2 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Api [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.REC2.FR.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.REC2.FR.functional.properties

	* REC1 :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Api [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.REC1.FR.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.REC1.FR.functional.properties

	* PVW :
	> cd [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin
	> C:\FnacTools\ConfigMerge\ConfigMerge.exe FnacDarty.Front.WebsiteAdmin.Api [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.PVW.FR.technical.properties [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api\Conf\WebSiteAdminWS.PVW.FR.functional.properties

Pour démarrer l'API et le site web en local clique droit sur la solution FnacDarty.Front.WebsiteAdmin.sln dans Visual studio.
	-> Properties -> Start up project -> Multiple start up projects comme suit :
	FnacDarty.Front.WebsiteAdmin.Api  start
	FnacDarty.Front.WebsiteAdmin.Web  start

	IIS express affiche alors deux sites qui tournent.
