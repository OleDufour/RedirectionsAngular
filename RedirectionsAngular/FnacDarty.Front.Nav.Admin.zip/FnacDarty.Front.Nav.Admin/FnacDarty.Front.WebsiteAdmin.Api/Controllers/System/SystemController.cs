using System;
using System.Diagnostics;
using FnacDarty.Front.WebsiteAdmin.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Api.Controllers.System
{
    [Route("api/[controller]")]
    [ApiController]
    public class SystemController : ApiControllerBase
    {
        public SystemController(ILogger logger) : base(logger)
        {
        }


        /// <summary>
        /// Check api status
        /// </summary>
        /// <returns></returns>
        [HttpGet("health/check")]
        public ActionResult<HealthCheckModel> CheckHealth()
        {
            var memory = Process.GetCurrentProcess().PrivateMemorySize64;
            var version = default(Version);


            return new HealthCheckModel
            {
                Success = true,
                Version = version != null ? version.ToString() : "Unknown",
                Message = "Retrieved system health.",
                MemoryUsage = $"{memory/(1024*1024)} Mo",
                MachineName = Environment.MachineName
            };
        }

        [HttpGet, HttpPost, HttpPut, HttpDelete, HttpHead, HttpOptions, AcceptVerbs("PATCH")]
        [ApiExplorerSettings(IgnoreApi = true)]
        public IActionResult Error404()
        {
            return NotFound();
        }
    }
}
