using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Api.Controllers
{
    public abstract class ApiControllerBase : ControllerBase
    {
        public ILogger Logger;

        protected ApiControllerBase(ILogger logger)
        {
            Logger = logger;
        }
    }
}
