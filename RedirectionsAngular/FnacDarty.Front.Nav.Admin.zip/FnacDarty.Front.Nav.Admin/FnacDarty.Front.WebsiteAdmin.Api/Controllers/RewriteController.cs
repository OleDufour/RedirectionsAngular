using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Api.Models;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RewriteController : ApiControllerBase
    {
        private readonly IPublishedRewriteBusinessModule _publishedRewriteModule;
        private readonly IDtoModelMapper<PublishedRewriteDto, PublishedRewriteModel> _publishedRewriteMapper;
        private readonly IDtoModelMapper<PublishedSeoDecorationDto, PublishedSeoDecorationModel> _publishedSeoDecorationMapper;

        public RewriteController(IPublishedRewriteBusinessModule publishedUrlRewriteModule,
            IDtoModelMapper<PublishedRewriteDto, PublishedRewriteModel> publishedRewriteMapper,
            IDtoModelMapper<PublishedSeoDecorationDto, PublishedSeoDecorationModel> publishedSeoDecorationMapper,
            ILogger logger,
            IConfig config) : base(logger)
        {
            _publishedRewriteModule = publishedUrlRewriteModule;
            _publishedRewriteMapper = publishedRewriteMapper;
            _publishedSeoDecorationMapper = publishedSeoDecorationMapper;
        }

        /// <summary>
        /// Get published rewrites config for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpGet("PublishedRewrite/{siteCode}/{cultureCode}")]
        public ActionResult<IEnumerable<PublishedRewriteModel>> GetPublishedRewrites(string siteCode, string cultureCode)
        {
            var dtos = _publishedRewriteModule.GetPublishedRewrites(siteCode, cultureCode);
            return _publishedRewriteMapper.DtosToModels(dtos).ToList();
        }

        /// <summary>
        /// Get published seo decorations for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpGet("PublishedSeoDecoration/{siteCode}/{cultureCode}")]
        public ActionResult<IEnumerable<PublishedSeoDecorationModel>> GetPublishedSeoDecorations(string siteCode, string cultureCode)
        {
            var dtos = _publishedRewriteModule.GetPublishedSeoDecorations(siteCode, cultureCode);
            return _publishedSeoDecorationMapper.DtosToModels(dtos).ToList();
        }

        /// <summary>
        /// Get published urls rewrites for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpGet("PublishedRewrittenUrl/{siteCode}/{cultureCode}")]
        public ActionResult<IEnumerable<string>> GetPublishedRewrittenUrls(string siteCode, string cultureCode)
        {
            return _publishedRewriteModule.GetPublishedRewrittenUrls(siteCode, cultureCode).ToList();
        }

        /// <summary>
        /// Notify other VIP APIs to invalidate and reload url rewrites and seo decorations cache for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpDelete("NotifyInvalidateAndReloadCache/{siteCode}/{cultureCode}")]
        public ActionResult NotifyInvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            if (_publishedRewriteModule.NotifyInvalidateAndReloadCache(siteCode, cultureCode))
            {
                Logger.LogInformation($"Rewrite - NotifyInvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName} is Done");
                return Ok();
            }

            Logger.LogError($"Error Rewrite- NotifyInvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName}");
            return StatusCode(StatusCodes.Status500InternalServerError);
        }

        /// <summary>
        /// Invalidate and reload url rewrites and seo decorations cache for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpDelete("InvalidateAndReloadCache/{siteCode}/{cultureCode}")]
        public ActionResult InvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            if (_publishedRewriteModule.InvalidateAndReloadCache(siteCode, cultureCode))
            {
                Logger.LogInformation($"Rewrite - InvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName} is Done");
                return Ok();
            }

            Logger.LogError($"Error Rewrite - InvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName}");
            return StatusCode(StatusCodes.Status500InternalServerError);
        }
    }
}
