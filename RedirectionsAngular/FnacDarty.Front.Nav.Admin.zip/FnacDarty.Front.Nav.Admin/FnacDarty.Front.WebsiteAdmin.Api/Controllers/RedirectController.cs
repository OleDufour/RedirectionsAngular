using System;
using System.Collections.Generic;
using System.Linq;
using FnacDarty.Front.WebsiteAdmin.Api.Models;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace FnacDarty.Front.WebsiteAdmin.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RedirectController : ApiControllerBase
    {
        private readonly IPublishedRedirectBusinessModule _publishedRedirectModule;
        private readonly IDtoModelMapper<PublishedUrlRedirectDto, PublishedRedirectModel> _publishedRedirectMapper;

        public RedirectController(IPublishedRedirectBusinessModule publishedRedirectModule,
            IDtoModelMapper<PublishedUrlRedirectDto, PublishedRedirectModel> publishedRedirectMapper,
            ILogger logger,
            IConfig config) : base(logger)
        {
            _publishedRedirectModule = publishedRedirectModule;
            _publishedRedirectMapper = publishedRedirectMapper;
        }

        /// <summary>
        /// Get Published Redirects for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpGet("PublishedRedirects/{siteCode}/{cultureCode}")]
        public ActionResult<IEnumerable<PublishedRedirectModel>> GetPublishedRedirects(string siteCode, string cultureCode)
        {
            var dtos = _publishedRedirectModule.GetPublishedUrlRedirectDtos(siteCode, cultureCode);
            return _publishedRedirectMapper.DtosToModels(dtos).ToList();
        }

        /// <summary>
        /// Notify other VIP APIs to invalidate and reload rewrite config cache for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpDelete("NotifyInvalidateAndReloadCache/{siteCode}/{cultureCode}")]
        public ActionResult NotifyInvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            if (_publishedRedirectModule.NotifyInvalidateAndReloadCache(siteCode, cultureCode))
            {
                Logger.LogInformation($"Redirect - NotifyInvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName} is Done");
                return Ok();
            }

            Logger.LogError($"Error Redirect - NotifyInvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName}");
            return StatusCode(StatusCodes.Status500InternalServerError);
        }

        /// <summary>
        /// Invalidate and reload redirect config cache for specific site and culture
        /// </summary>
        /// <param name="siteCode">Site Code</param>
        /// <param name="cultureCode">Cultrue Code</param>
        /// <returns></returns>
        [HttpDelete("InvalidateAndReloadCache/{siteCode}/{cultureCode}")]
        public ActionResult<bool> InvalidateAndReloadCache(string siteCode, string cultureCode)
        {
            if (_publishedRedirectModule.InvalidateAndReloadCache(siteCode, cultureCode))
            {
                Logger.LogInformation($"Redirect - InvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName} is Done");
                return Ok();
            }

            Logger.LogError($"Error Redirect - InvalidateAndReloadCache {siteCode} {cultureCode} in server {Environment.MachineName}");
            return StatusCode(StatusCodes.Status500InternalServerError);
        }
    }
}
