Profils de debug :
	* IIS Express : avant d'utiliser ce profil, veiller à avoir effectué les opérations suivantes au préalable

	* IIS : avant d'utiliser ce profil, veiller à avoir effectué les opérations suivantes au préalable :
		1. modifier l'installation de Micorsoft Visual Studio 2017 pour intégrer l'option "Prise en charge d'IIS pendant le développement"
			(dans la section "Développement web et ASP.NET" puis "Développement multiplateforme .NET Core")
		2. sous IIS :
			- créer un pool applicatif "FRDEVPOOL-WebAdmWS" avec comme version du CLR .NET : aucun code managé
			- créer un nouvelle site "WebSiteAdminWS-FR" en précisant le chemin suivant : [$GIT]\Front.Nav.Admin\FnacDarty.Front.Nav.Admin\FnacDarty.Front.WebsiteAdmin.Api ou [$GIT] est le chemin de votre repo GIT
			- définir le port 49183 avec le menu "Modifier les liaisons..."


Pour démarrer l'API et le site web en local clique droit sur la solution FnacDarty.Front.WebsiteAdmin.sln dans Visual studio.
	-> Properties -> Start up project -> Multiple start up projects comme suit :
	FnacDarty.Front.WebsiteAdmin.Api  start
	FnacDarty.Front.WebsiteAdmin.Web  start

	IIS express affiche alors deux sites qui tournent.     
