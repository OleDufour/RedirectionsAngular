using FnacDarty.Front.WebsiteAdmin.Api.Models;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;

namespace FnacDarty.Front.WebsiteAdmin.Api.Mapper
{
    public class PublishedRewriteModelMapper : DtoModelMapperBase<PublishedRewriteDto, PublishedRewriteModel>
    {
        public override PublishedRewriteModel DtoToModel(PublishedRewriteDto dto)
        {
            return new PublishedRewriteModel
            {
                RewrittenUrl = dto.RewrittenUrl,
                MobileRealUrl = dto.MobileRealUrl,
                DesktopRealUrl = dto.DesktopRealUrl,
            };
        }

        public override PublishedRewriteDto ModelToDto(PublishedRewriteModel model)
        {
            return new PublishedRewriteDto
            {
                RewrittenUrl = model.RewrittenUrl,
                MobileRealUrl = model.MobileRealUrl,
                DesktopRealUrl = model.DesktopRealUrl,
            };
        }
    }
}
