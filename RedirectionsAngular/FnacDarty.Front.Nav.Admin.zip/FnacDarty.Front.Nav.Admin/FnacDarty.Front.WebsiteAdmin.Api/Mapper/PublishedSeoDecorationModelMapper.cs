using FnacDarty.Front.WebsiteAdmin.Api.Models;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;

namespace FnacDarty.Front.WebsiteAdmin.Api.Mapper
{
    public class PublishedSeoDecorationModelMapper : DtoModelMapperBase<PublishedSeoDecorationDto, PublishedSeoDecorationModel>
    {
        public override PublishedSeoDecorationModel DtoToModel(PublishedSeoDecorationDto dto)
        {
            return new PublishedSeoDecorationModel
            {
                MobileRealUrl = dto.MobileRealUrl,
                DesktopRealUrl = dto.DesktopRealUrl,
                Title = dto.Title,
                MetaDescription = dto.MetaDescription,
                H1Tag = dto.H1Tag,
                SeoData = dto.SeoData
            };
        }

        public override PublishedSeoDecorationDto ModelToDto(PublishedSeoDecorationModel model)
        {
            return new PublishedSeoDecorationDto
            {
                MobileRealUrl = model.MobileRealUrl,
                DesktopRealUrl = model.DesktopRealUrl,
                Title = model.Title,
                MetaDescription = model.MetaDescription,
                H1Tag = model.H1Tag,
                SeoData = model.SeoData
            };
        }
    }
}
