using FnacDarty.Front.WebsiteAdmin.Api.Models;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;

namespace FnacDarty.Front.WebsiteAdmin.Api.Mapper
{
    public class PublishedRedirectModelMapper : DtoModelMapperBase<PublishedUrlRedirectDto, PublishedRedirectModel>
    {
        public override PublishedRedirectModel DtoToModel(PublishedUrlRedirectDto dto)
        {
            return new PublishedRedirectModel
            {
                SourceType = dto.SourceType,
                Source = dto.Source,
                TargetType = dto.TargetType,
                Target = dto.Target,
                HttpCode = dto.RedirectType
            };
        }

        public override PublishedUrlRedirectDto ModelToDto(PublishedRedirectModel viewModel)
        {
            return new PublishedUrlRedirectDto
            {
            };
        }
    }
}
