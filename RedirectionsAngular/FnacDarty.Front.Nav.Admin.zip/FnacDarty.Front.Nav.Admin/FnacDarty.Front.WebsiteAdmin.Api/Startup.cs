using System;
using System.IO;
using System.Reflection;
using System.Xml.XPath;
using FnacDarty.Front.WebsiteAdmin.Api.Mapper;
using FnacDarty.Front.WebsiteAdmin.Api.Middlewares.Exception;
using FnacDarty.Front.WebsiteAdmin.Api.Models;
using FnacDarty.Front.WebsiteAdmin.BusinessModule;
using FnacDarty.Front.WebsiteAdmin.Contract.Module;
using FnacDarty.Front.WebsiteAdmin.Contract.Repository;
using FnacDarty.Front.WebsiteAdmin.DataTransfer;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.ApiClient;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Cache;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Configuration;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Mapper;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Profiler;
using FnacDarty.Front.WebsiteAdmin.Infrastructure.Repository;
using FnacDarty.Front.WebsiteAdmin.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Serialization;
using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace FnacDarty.Front.WebsiteAdmin.Api
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddFnacLogging(builder =>
            {
                builder.AddConfiguration(Configuration.GetSection("Logging"));

                var rabbitConf = Configuration.GetSection("Logging").GetSection("Rabbitmq");
                var kafkaConf = Configuration.GetSection("Logging").GetSection("Kafka");
                var consoleConf = Configuration.GetSection("Logging").GetSection("Console");
                bool enabled;

                //Rabbit log activate
                if (bool.TryParse(rabbitConf["Enabled"], out enabled))
                {
                    builder.AddRabbitmq(rabbitConf);
                }

                //kafka log activate
                if (bool.TryParse(kafkaConf["Enabled"], out enabled))
                {
                    builder.AddKafka(kafkaConf);
                }

                //console log activate
                if (bool.TryParse(consoleConf["Enabled"], out enabled))
                {
                    builder.AddConsole().AddAspNetCoreLogEntryEnricher();
                }
            });

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1)
            // Set JSON output to Pascalcase instead of camelCase
            .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

            // Add Swagger Gen for API Documentation
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Info { Title = "Front Admin Api", Version = "v1", Description = "An admin API to get configurations for Fnac web sites" });
                options.DescribeAllEnumsAsStrings();
                var xmlDocFile = Path.Combine(AppContext.BaseDirectory, $"FnacDarty.Front.WebsiteAdmin.Api.xml");
                if (File.Exists(xmlDocFile))
                {
                    var comments = new XPathDocument(xmlDocFile);
                    options.OperationFilter<XmlCommentsOperationFilter>(comments);
                }
            });

            // Add HttpContextAccessor
            services.AddHttpContextAccessor();
            var serviceProviderp = services.BuildServiceProvider();
            var httpContextAccessor = serviceProviderp.GetService<IHttpContextAccessor>();

            //logger
            var loggerFactory = (ILoggerFactory)serviceProviderp.GetService(typeof(ILoggerFactory));
            var logger = loggerFactory.CreateLogger<Startup>();
            services.AddSingleton<ILogger>(logger);

            var config = new CoreConfig(Configuration);
            services.AddSingleton<IConfig>(config);

            services.AddSingleton<ILocalCache>(new CacheFactory(config).CreateLocalCacheFromConfiguration());
            services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
            services.AddSingleton<IPerfmonFactory>(new PerfmonFactory(config, httpContextAccessor).CreatePerfmonFromConfiguration());

            services.AddSingleton<IRestClient, RestClient>();

            //register Repo & Modulea
            RegisterRepositories(services, config);
            RegisterModules(services);
            RegisterMappers(services);


            // log startup application
            logger.LogInformation($"{Assembly.GetExecutingAssembly()} in server {Environment.MachineName} started");
        }

        private void RegisterMappers(IServiceCollection services)
        {
            services.AddSingleton<IDtoModelMapper<PublishedRewriteDto, PublishedRewriteModel>, PublishedRewriteModelMapper>();
            services.AddSingleton<IDtoModelMapper<PublishedSeoDecorationDto, PublishedSeoDecorationModel>, PublishedSeoDecorationModelMapper>();
            services.AddSingleton<IDtoModelMapper<PublishedUrlRedirectDto, PublishedRedirectModel>, PublishedRedirectModelMapper>();
        }

        private void RegisterModules(IServiceCollection services)
        {
            services.AddSingleton<IPublishedRewriteBusinessModule, PublishedRewriteBusinessModule>();
            services.AddSingleton<IPublishedRedirectBusinessModule, PublishedRedirectBusinessModule>();
        }

        private void RegisterRepositories(IServiceCollection services, IConfig config)
        {
            var isProduction = config.GetSettingValue<bool>("IsProduction");

            if (isProduction)
            {
                services.AddSingleton<IPublishedRewriteRepository, PublishedRewriteRepository>();
                services.AddSingleton<IPublishedRedirectRepository, PublishedRedirectRepository>();
            }
            else
            {
                services.AddSingleton<IPublishedRewriteRepository, PreviewPublishedRewriteRepository>();
                services.AddSingleton<IPublishedRedirectRepository, PreviewPublishedRedirectRepository>();
            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILogger logger)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                // global cors policy
                app.UseCors(x => x
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            }
            else
            {
                // Handle 500 and others
                app.UseStatusCodePagesWithReExecute("/Error");
                // Handle 404
                app.Use(async (ctx, next) =>
                {
                    await next();
                    if (ctx.Response.StatusCode == 404 && !ctx.Response.HasStarted)
                    {
                        //Re-execute the request so the user gets the error page
                        ctx.Items["originalPath"] = ctx.Request.Path.Value;
                        ctx.Request.Path = "/Error";
                        await next();
                    }
                });
            }

            // Gestion des exceptions
            app.ConfigureExceptionHandler(logger);

            app.UseHttpsRedirection();
            app.UseMvc();
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Front Admin Api");
            });
        }
    }
}
