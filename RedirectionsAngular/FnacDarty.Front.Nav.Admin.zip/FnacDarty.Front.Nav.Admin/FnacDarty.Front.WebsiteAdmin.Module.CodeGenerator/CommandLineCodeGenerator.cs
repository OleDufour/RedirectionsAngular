using System;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.CommandLine;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    [Alias("uiconfig")]
    public class CommandLineCodeGenerator : ICodeGenerator
    {
        private readonly IServiceProvider _serviceProvider;

        public CommandLineCodeGenerator(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider ?? throw new ArgumentNullException(nameof(serviceProvider));
        }

        public async Task GenerateCode(CommandLineGeneratorModel model)
        {
            if (model == null)
            {
                throw new ArgumentNullException(nameof(model));
            }

            if (string.IsNullOrEmpty(model.ModelClass))
            {
                throw new ArgumentOutOfRangeException(nameof(model.ModelClass), "You must provide a Model class");
            }

            if(string.IsNullOrEmpty(model.AreaName))
            {
                throw new ArgumentOutOfRangeException(nameof(model.AreaName), "You must provide an Area name");
            }

            var resourceGenerator = ActivatorUtilities.CreateInstance<ResourceGenerator>(_serviceProvider);

            await resourceGenerator.Generate(model);

            var customizeMeGenerator = ActivatorUtilities.CreateInstance<CustomizeMeGenerator>(_serviceProvider);

            await customizeMeGenerator.Generate(model);

            var repositoryGenerator = ActivatorUtilities.CreateInstance<RepositoryGenerator>(_serviceProvider);

            await repositoryGenerator.Generate(model);

            var controllerGenerator = ActivatorUtilities.CreateInstance<ControllerGenerator>(_serviceProvider);

            await controllerGenerator.Generate(model);

            var viewGenerator = ActivatorUtilities.CreateInstance<ViewGenerator>(_serviceProvider);

            await viewGenerator.Generate(model);

            var jsGenerator = ActivatorUtilities.CreateInstance<JsGenerator>(_serviceProvider);

            await jsGenerator.Generate(model);

            var moduleRegistrationCodeGenerator = ActivatorUtilities.CreateInstance<ModuleRegistrationCodeGenerator>(_serviceProvider);

            await moduleRegistrationCodeGenerator.Generate(model);
        }
    }
}
