using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.ProjectModel;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class CustomizeMeGenerator : GeneratorBase
    {
        private readonly IProjectContext _projectContext;
        private readonly IApplicationInfo _applicationInfo;
        private readonly ICodeGeneratorActionsService _codeGeneratorActionsService;

        public CustomizeMeGenerator(IProjectContext projectContext,
                                   IApplicationInfo applicationInfo,
                                   IModelTypesLocator modelTypesLocator,
                                   ICodeGeneratorActionsService codeGeneratorActionsService,
                                   IServiceProvider serviceProvider)
            : base(applicationInfo, modelTypesLocator, serviceProvider)
        {
            _projectContext = projectContext;
            _applicationInfo = applicationInfo;
            _codeGeneratorActionsService = codeGeneratorActionsService;
        }

        public async Task Generate(CommandLineGeneratorModel model)
        {
            var namespaceName = NameSpaceUtilities.GetSafeNameSpaceFromPath(model.RelativeFolderPath, _applicationInfo.ApplicationName);

            var templateFolders = TemplateFoldersUtilities.GetTemplateFolders(containingProject: typeof(ControllerGenerator).Assembly.GetName().Name,
                                                    applicationBasePath: _applicationInfo.ApplicationBasePath,
                                                    baseFolders: new[] { "CustomizeMeGenerator" },
                                                    projectContext: _projectContext);
            
            var templateModel = await GetDefaultTemplateModel(model);

            var className = $"{templateModel.ModelClass}_CustomizeMe";
            var classOutputPath = ValidateAndGetOutputPath(model, className + ".cs");
            templateModel.ClassName = className;

            await _codeGeneratorActionsService.AddFileFromTemplateAsync(classOutputPath, "CustomizeMe.cshtml", templateFolders, templateModel);
        }
    }
}
