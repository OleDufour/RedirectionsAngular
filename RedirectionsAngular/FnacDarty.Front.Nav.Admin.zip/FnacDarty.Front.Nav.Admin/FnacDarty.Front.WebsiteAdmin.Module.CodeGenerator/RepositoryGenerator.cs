using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.ProjectModel;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class RepositoryGenerator : GeneratorBase
    {
        private readonly IProjectContext _projectContext;
        private readonly IApplicationInfo _applicationInfo;
        private readonly ICodeGeneratorActionsService _codeGeneratorActionsService;
        
        public RepositoryGenerator(IProjectContext projectContext,
                                   IApplicationInfo applicationInfo,
                                   IModelTypesLocator modelTypesLocator,
                                   ICodeGeneratorActionsService codeGeneratorActionsService,
                                   IServiceProvider serviceProvider)
            : base(applicationInfo, modelTypesLocator, serviceProvider)
        {
            _projectContext = projectContext;
            _applicationInfo = applicationInfo;
            _codeGeneratorActionsService = codeGeneratorActionsService;
        }

        public async Task Generate(CommandLineGeneratorModel model)
        {
            var className = model.ModelClass + "Repository";

            var interfaceOutputPath = ValidateAndGetOutputPath(model, "I" + className + ".cs");
            var classOutputPath = ValidateAndGetOutputPath(model, className + ".cs");

            var templateFolders = TemplateFoldersUtilities.GetTemplateFolders(containingProject: typeof(ControllerGenerator).Assembly.GetName().Name,
                                                    applicationBasePath: _applicationInfo.ApplicationBasePath,
                                                    baseFolders: new[] { "RepositoryGenerator" },
                                                    projectContext: _projectContext);

            var templateModel = await GetDefaultTemplateModel(model);

            templateModel.ClassName = className;

            await _codeGeneratorActionsService.AddFileFromTemplateAsync(interfaceOutputPath, "IRepository.cshtml", templateFolders, templateModel);
            await _codeGeneratorActionsService.AddFileFromTemplateAsync(classOutputPath, "Repository.cshtml", templateFolders, templateModel);
        }
    }
}
