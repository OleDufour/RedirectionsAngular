using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;
using Microsoft.VisualStudio.Web.CodeGeneration.EntityFrameworkCore;
using Microsoft.VisualStudio.Web.CodeGenerators.Mvc;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public abstract class GeneratorBase
    {
        private readonly IApplicationInfo _applicationInfo;
        private readonly IModelTypesLocator _modelTypesLocator;
        private readonly CodeModelService _codeModelService;


        protected GeneratorBase(IApplicationInfo applicationInfo,
                                IModelTypesLocator modelTypesLocator,
                                IServiceProvider serviceProvider)
        {
            _applicationInfo = applicationInfo;
            _modelTypesLocator = modelTypesLocator;
            _codeModelService = ActivatorUtilities.CreateInstance<CodeModelService>(serviceProvider);
        }

        protected string ValidateAndGetOutputPath(CommandLineGeneratorModel model, string outputFileName)
        {
            string outputFolder = _applicationInfo.ApplicationBasePath;

            var outputPath = Path.Combine(outputFolder, outputFileName);

            return outputPath;
        }

        protected async Task<DefaultTemplateModel> GetDefaultTemplateModel(CommandLineGeneratorModel model)
        {
            var namespaceName = NameSpaceUtilities.GetSafeNameSpaceFromPath(model.RelativeFolderPath, _applicationInfo.ApplicationName);

            var modelType = ValidationUtil.ValidateType(model.ModelClass, "model", _modelTypesLocator);

            var contextProcessingResult = await _codeModelService.GetModelMetadata(modelType);

            if (contextProcessingResult.ContextProcessingStatus != ContextProcessingStatus.ContextAvailable)
            {
                throw new InvalidOperationException(contextProcessingResult.ContextProcessingStatus.ToString());
            }

            var templateModel = new DefaultTemplateModel
            {
                AreaName = model.AreaName,
                AreaUrl = model.AreaName.ToUrl(),
                NamespaceName = namespaceName,
                ModelClass = model.ModelClass,
                ControllerClassName = model.ModelClass + "Controller",
                RepositoryClassName = model.ModelClass + "Repository",
                ControllerUrl = model.ModelClass.ToUrl(),
                ModelMetadata = contextProcessingResult.ModelMetadata,
                ResourcesClass = $"{model.AreaName}_{model.ModelClass}_Resources",
                PrimaryKeyIsManual = model.PrimaryKeyIsManual
            };

            return templateModel;
        }
    }
}
