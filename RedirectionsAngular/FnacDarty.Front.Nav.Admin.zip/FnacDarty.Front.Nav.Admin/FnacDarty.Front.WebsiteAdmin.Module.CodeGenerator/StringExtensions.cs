using System.Collections.Generic;
using System.Linq;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public static class StringExtensions
    {
        public static string ToUrl(this string str)
        {
            var output = new List<string>();

            var buffer = new char[str.Length];
            var bufferPosition = 0;
            var isWaitingWordBreak = false;

            for (var i = 0; i < str.Length; i++)
            {
                var c = str[i];

                if (char.IsUpper(c) || char.IsNumber(c))
                {
                    if (isWaitingWordBreak)
                    {
                        output.Add(new string(buffer.Take(bufferPosition).ToArray()));
                        bufferPosition = 0;
                    }
                    buffer[bufferPosition] = char.ToLowerInvariant(c);
                    bufferPosition++;
                }
                else if (char.IsLower(c))
                {
                    if (!isWaitingWordBreak && bufferPosition > 1)
                    {
                        output.Add(new string(buffer.Take(bufferPosition - 1).ToArray()));
                        buffer[0] = buffer[bufferPosition - 1];
                        bufferPosition = 1;
                    }
                    buffer[bufferPosition] = char.ToLowerInvariant(c);
                    bufferPosition++;
                    isWaitingWordBreak = true;
                }
            }

            if (bufferPosition > 0)
            {
                output.Add(new string(buffer.Take(bufferPosition).ToArray()));
            }

            return string.Join("-", output);
        }
    }
}
