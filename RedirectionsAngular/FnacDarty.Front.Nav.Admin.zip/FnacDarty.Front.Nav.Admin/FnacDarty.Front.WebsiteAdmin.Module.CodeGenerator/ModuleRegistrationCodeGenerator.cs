using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class ModuleRegistrationCodeGenerator : GeneratorBase
    {
        private readonly Workspace _workspace;
        private readonly IModelTypesLocator _modelTypesLocator;

        public ModuleRegistrationCodeGenerator(IApplicationInfo applicationInfo, 
                                               IModelTypesLocator modelTypesLocator, 
                                               IServiceProvider serviceProvider,
                                               Workspace workspace) 
            : base(applicationInfo, modelTypesLocator, serviceProvider)
        {
            _modelTypesLocator = modelTypesLocator;
            _workspace = workspace;
        }

        public async Task Generate(CommandLineGeneratorModel model)
        {
            var templateModel = await GetDefaultTemplateModel(model);

            var moduleRegistrationType = _modelTypesLocator.GetType("ModuleRegistration").FirstOrDefault();

            var declarationReference = moduleRegistrationType.TypeSymbol.DeclaringSyntaxReferences.FirstOrDefault();
            if (declarationReference != null)
            {
                var sourceTree = declarationReference.SyntaxTree;
                var rootNode = sourceTree.GetRoot();

                var moduleRegistrationClassNode = rootNode.FindNode(declarationReference.Span) as ClassDeclarationSyntax;
                
                var isDirty = false;

                var registerAuthorizationsMethod = moduleRegistrationClassNode.ChildNodes()
                                                                     .FirstOrDefault(n => n is MethodDeclarationSyntax
                                                                       && ((MethodDeclarationSyntax)n).Identifier.ToString() == "RegisterAuthorizations")
                                                                       as MethodDeclarationSyntax;

                if(registerAuthorizationsMethod != null)
                {

                }

                var registerServicesMethod = moduleRegistrationClassNode.ChildNodes()
                                                                     .FirstOrDefault(n => n is MethodDeclarationSyntax
                                                                       && ((MethodDeclarationSyntax)n).Identifier.ToString() == "RegisterServices")
                                                                       as MethodDeclarationSyntax;

                if (registerServicesMethod != null)
                {
                    var serviceCollectionParameter = registerServicesMethod.ParameterList.Parameters.FirstOrDefault(p => p.Type.ToString() == "IServiceCollection") as ParameterSyntax;

                    if (serviceCollectionParameter != null)
                    {
                        var statementLeadingTrivia = registerServicesMethod.Body.OpenBraceToken.LeadingTrivia.ToString() + "    ";
                        var newStatementRaw = $"{statementLeadingTrivia}{serviceCollectionParameter.Identifier}.AddSingleton<I{templateModel.RepositoryClassName}, {templateModel.RepositoryClassName}>();{Environment.NewLine}";
                        var expression = SyntaxFactory.ParseStatement(newStatementRaw);

                        var currentStatements = registerServicesMethod.Body.Statements;
                        var statementAlreadyExists = false;

                        foreach (var currentStatement in currentStatements)
                        {
                            if (currentStatement.GetText().ToString().Contains(newStatementRaw))
                            {
                                statementAlreadyExists = true;
                            }
                        }

                        if (!statementAlreadyExists)
                        {
                            MethodDeclarationSyntax newRegisterServicesMethod = registerServicesMethod.InsertNodesBefore(currentStatements.Last(), new[] { expression });

                            rootNode = rootNode.ReplaceNode(registerServicesMethod, newRegisterServicesMethod);

                            sourceTree = sourceTree.WithRootAndOptions(rootNode, sourceTree.Options);

                            isDirty = true;
                        }
                    }
                }

                moduleRegistrationClassNode = rootNode.FindNode(declarationReference.Span) as ClassDeclarationSyntax;
                
                var registerControllerMenuMethod = moduleRegistrationClassNode.ChildNodes()
                                                                      .FirstOrDefault(n => n is MethodDeclarationSyntax
                                                                        && ((MethodDeclarationSyntax)n).Identifier.ToString() == $"Register{templateModel.ModelClass}Menu")
                                                                        as MethodDeclarationSyntax;

                if (registerControllerMenuMethod == null)
                {
                    // generated statements declaration, see http://roslynquoter.azurewebsites.net/
                    var method = GetMemberDeclarationSyntax(templateModel);

                    var newModuleRegistrationClassNode = moduleRegistrationClassNode.AddMembers(new[] { method });

                    rootNode = rootNode.ReplaceNode(moduleRegistrationClassNode, newModuleRegistrationClassNode);

                    moduleRegistrationClassNode = newModuleRegistrationClassNode;

                    rootNode = Microsoft.CodeAnalysis.Formatting.Formatter.Format(rootNode, _workspace);

                    sourceTree = sourceTree.WithRootAndOptions(rootNode, sourceTree.Options);
                    isDirty = true;
                }

                moduleRegistrationClassNode = rootNode.FindNode(declarationReference.Span) as ClassDeclarationSyntax;

                var registerMenuMethod = moduleRegistrationClassNode.ChildNodes()
                                                                      .FirstOrDefault(n => n is MethodDeclarationSyntax
                                                                        && ((MethodDeclarationSyntax)n).Identifier.ToString() == "RegisterMenu")
                                                                        as MethodDeclarationSyntax;

                if (registerMenuMethod != null)
                {
                    var statementLeadingTrivia = registerMenuMethod.Body.OpenBraceToken.LeadingTrivia.ToString() + "    ";
                    var newStatementRaw = $"{statementLeadingTrivia}Register{templateModel.ModelClass}Menu(menuBuilder);{Environment.NewLine}";
                    var expression = SyntaxFactory.ParseStatement(newStatementRaw);

                    var currentStatements = registerMenuMethod.Body.Statements;
                    var statementAlreadyExists = false;

                    foreach (var currentStatement in currentStatements)
                    {
                        if (currentStatement.GetText().ToString().Contains(newStatementRaw))
                        {
                            statementAlreadyExists = true;
                        }
                    }

                    if (!statementAlreadyExists)
                    {
                        MethodDeclarationSyntax newregisterMenuMethod = registerMenuMethod.InsertNodesBefore(currentStatements.Last(), new[] { expression });

                        rootNode = rootNode.ReplaceNode(registerMenuMethod, newregisterMenuMethod);

                        sourceTree = sourceTree.WithRootAndOptions(rootNode, sourceTree.Options);

                        isDirty = true;
                    }
                }

                if (isDirty)
                {
                    File.WriteAllText(sourceTree.FilePath, sourceTree.GetText().ToString());
                }
            }
        }

        private MethodDeclarationSyntax GetMemberDeclarationSyntax(DefaultTemplateModel templateModel)
        {
            return SyntaxFactory.MethodDeclaration(
                        SyntaxFactory.PredefinedType(
                            SyntaxFactory.Token(
                                SyntaxFactory.TriviaList(),
                                SyntaxKind.VoidKeyword,
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.Space))),
                        SyntaxFactory.Identifier("Register" + templateModel.ModelClass + "Menu"))
                    .WithModifiers(
                        SyntaxFactory.TokenList(
                            SyntaxFactory.Token(
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.Whitespace("        ")),
                                SyntaxKind.PrivateKeyword,
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.Space))))
                    .WithParameterList(
                        SyntaxFactory.ParameterList(
                            SyntaxFactory.SingletonSeparatedList<ParameterSyntax>(
                                SyntaxFactory.Parameter(
                                    SyntaxFactory.Identifier("menuBuilder"))
                                .WithType(
                                    SyntaxFactory.IdentifierName(
                                        SyntaxFactory.Identifier(
                                            SyntaxFactory.TriviaList(),
                                            "IDynamicMenuBuilder",
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Space))))))
                        .WithCloseParenToken(
                            SyntaxFactory.Token(
                                SyntaxFactory.TriviaList(),
                                SyntaxKind.CloseParenToken,
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.LineFeed))))
                    .WithBody(
                        SyntaxFactory.Block(
                            SyntaxFactory.LocalDeclarationStatement(
                                SyntaxFactory.VariableDeclaration(
                                    SyntaxFactory.IdentifierName(
                                        SyntaxFactory.Identifier(
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Whitespace("            ")),
                                            "var",
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Space))))
                                .WithVariables(
                                    SyntaxFactory.SingletonSeparatedList<VariableDeclaratorSyntax>(
                                        SyntaxFactory.VariableDeclarator(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "indexMenuItem",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))
                                        .WithInitializer(
                                            SyntaxFactory.EqualsValueClause(
                                                SyntaxFactory.ObjectCreationExpression(
                                                    SyntaxFactory.IdentifierName("SubMenuItem"))
                                                .WithNewKeyword(
                                                    SyntaxFactory.Token(
                                                        SyntaxFactory.TriviaList(),
                                                        SyntaxKind.NewKeyword,
                                                        SyntaxFactory.TriviaList(
                                                            SyntaxFactory.Space)))
                                                .WithArgumentList(
                                                    SyntaxFactory.ArgumentList()))
                                            .WithEqualsToken(
                                                SyntaxFactory.Token(
                                                    SyntaxFactory.TriviaList(),
                                                    SyntaxKind.EqualsToken,
                                                    SyntaxFactory.TriviaList(
                                                        SyntaxFactory.Space)))))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.LocalDeclarationStatement(
                                SyntaxFactory.VariableDeclaration(
                                    SyntaxFactory.IdentifierName(
                                        SyntaxFactory.Identifier(
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Whitespace("            ")),
                                            "var",
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Space))))
                                .WithVariables(
                                    SyntaxFactory.SingletonSeparatedList<VariableDeclaratorSyntax>(
                                        SyntaxFactory.VariableDeclarator(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "createMenuItem",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))
                                        .WithInitializer(
                                            SyntaxFactory.EqualsValueClause(
                                                SyntaxFactory.ObjectCreationExpression(
                                                    SyntaxFactory.IdentifierName("SubMenuItem"))
                                                .WithNewKeyword(
                                                    SyntaxFactory.Token(
                                                        SyntaxFactory.TriviaList(),
                                                        SyntaxKind.NewKeyword,
                                                        SyntaxFactory.TriviaList(
                                                            SyntaxFactory.Space)))
                                                .WithArgumentList(
                                                    SyntaxFactory.ArgumentList()))
                                            .WithEqualsToken(
                                                SyntaxFactory.Token(
                                                    SyntaxFactory.TriviaList(),
                                                    SyntaxKind.EqualsToken,
                                                    SyntaxFactory.TriviaList(
                                                        SyntaxFactory.Space)))))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "indexMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Area",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal(templateModel.AreaName)))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "createMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Area",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal(templateModel.AreaName)))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "indexMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Controller",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal(templateModel.ModelClass)))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "createMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Controller",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal(templateModel.ModelClass)))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "indexMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Action",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal("Index")))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "createMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Action",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal("Create")))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "indexMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Label",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.MemberAccessExpression(
                                            SyntaxKind.SimpleMemberAccessExpression,
                                            SyntaxFactory.IdentifierName("Resources"),
                                            SyntaxFactory.IdentifierName(templateModel.ResourcesClass)),
                                        SyntaxFactory.IdentifierName("menu_item_index")))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "createMenuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Label",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.MemberAccessExpression(
                                            SyntaxKind.SimpleMemberAccessExpression,
                                            SyntaxFactory.IdentifierName("Resources"),
                                            SyntaxFactory.IdentifierName(templateModel.ResourcesClass)),
                                        SyntaxFactory.IdentifierName("menu_item_create")))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.LocalDeclarationStatement(
                                SyntaxFactory.VariableDeclaration(
                                    SyntaxFactory.IdentifierName(
                                        SyntaxFactory.Identifier(
                                            SyntaxFactory.TriviaList(
                                                new[]{
                                                    SyntaxFactory.LineFeed,
                                                    SyntaxFactory.Whitespace("            ")}),
                                            "var",
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Space))))
                                .WithVariables(
                                    SyntaxFactory.SingletonSeparatedList<VariableDeclaratorSyntax>(
                                        SyntaxFactory.VariableDeclarator(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "menuItem",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))
                                        .WithInitializer(
                                            SyntaxFactory.EqualsValueClause(
                                                SyntaxFactory.ObjectCreationExpression(
                                                    SyntaxFactory.IdentifierName("MenuItem"))
                                                .WithNewKeyword(
                                                    SyntaxFactory.Token(
                                                        SyntaxFactory.TriviaList(),
                                                        SyntaxKind.NewKeyword,
                                                        SyntaxFactory.TriviaList(
                                                            SyntaxFactory.Space)))
                                                .WithArgumentList(
                                                    SyntaxFactory.ArgumentList()))
                                            .WithEqualsToken(
                                                SyntaxFactory.Token(
                                                    SyntaxFactory.TriviaList(),
                                                    SyntaxKind.EqualsToken,
                                                    SyntaxFactory.TriviaList(
                                                        SyntaxFactory.Space)))))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "menuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Label",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.MemberAccessExpression(
                                            SyntaxKind.SimpleMemberAccessExpression,
                                            SyntaxFactory.IdentifierName("Resources"),
                                            SyntaxFactory.IdentifierName(templateModel.ResourcesClass)),
                                        SyntaxFactory.IdentifierName("uiconfig_title")))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "menuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "Icon",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.LiteralExpression(
                                        SyntaxKind.StringLiteralExpression,
                                        SyntaxFactory.Literal("fa-database")))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.AssignmentExpression(
                                    SyntaxKind.SimpleAssignmentExpression,
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Whitespace("            ")),
                                                "menuItem",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(),
                                                "SubItems",
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space)))),
                                    SyntaxFactory.ImplicitArrayCreationExpression(
                                        SyntaxFactory.InitializerExpression(
                                            SyntaxKind.ArrayInitializerExpression,
                                            SyntaxFactory.SeparatedList<ExpressionSyntax>(new[] {
                                                SyntaxFactory.IdentifierName(
                                                    SyntaxFactory.Identifier(
                                                        SyntaxFactory.TriviaList(),
                                                        "indexMenuItem",
                                                        SyntaxFactory.TriviaList(
                                                            SyntaxFactory.Space))),
                                                SyntaxFactory.IdentifierName(
                                                    SyntaxFactory.Identifier(
                                                        SyntaxFactory.TriviaList(),
                                                        "createMenuItem",
                                                        SyntaxFactory.TriviaList(
                                                            SyntaxFactory.Space))),
                                            }))
                                        .WithOpenBraceToken(
                                            SyntaxFactory.Token(
                                                SyntaxFactory.TriviaList(),
                                                SyntaxKind.OpenBraceToken,
                                                SyntaxFactory.TriviaList(
                                                    SyntaxFactory.Space))))
                                    .WithCloseBracketToken(
                                        SyntaxFactory.Token(
                                            SyntaxFactory.TriviaList(),
                                            SyntaxKind.CloseBracketToken,
                                            SyntaxFactory.TriviaList(
                                                SyntaxFactory.Space))))
                                .WithOperatorToken(
                                    SyntaxFactory.Token(
                                        SyntaxFactory.TriviaList(),
                                        SyntaxKind.EqualsToken,
                                        SyntaxFactory.TriviaList(
                                            SyntaxFactory.Space))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))),
                            SyntaxFactory.ExpressionStatement(
                                SyntaxFactory.InvocationExpression(
                                    SyntaxFactory.MemberAccessExpression(
                                        SyntaxKind.SimpleMemberAccessExpression,
                                        SyntaxFactory.IdentifierName(
                                            SyntaxFactory.Identifier(
                                                SyntaxFactory.TriviaList(
                                                    new[]{
                                                        SyntaxFactory.LineFeed,
                                                        SyntaxFactory.Whitespace("            ")}),
                                                "menuBuilder",
                                                SyntaxFactory.TriviaList())),
                                        SyntaxFactory.IdentifierName("AddSection")))
                                .WithArgumentList(
                                    SyntaxFactory.ArgumentList(
                                        SyntaxFactory.SeparatedList<ArgumentSyntax>(
                                            new SyntaxNodeOrToken[]{
                                                SyntaxFactory.Argument(
                                                    SyntaxFactory.MemberAccessExpression(
                                                        SyntaxKind.SimpleMemberAccessExpression,
                                                        SyntaxFactory.MemberAccessExpression(
                                                            SyntaxKind.SimpleMemberAccessExpression,
                                                            SyntaxFactory.IdentifierName("Resources"),
                                                            SyntaxFactory.IdentifierName(templateModel.ResourcesClass)),
                                                        SyntaxFactory.IdentifierName("menu_section"))),
                                                SyntaxFactory.Token(
                                                    SyntaxFactory.TriviaList(),
                                                    SyntaxKind.CommaToken,
                                                    SyntaxFactory.TriviaList(
                                                        SyntaxFactory.Space)),
                                                SyntaxFactory.Argument(
                                                    SyntaxFactory.ImplicitArrayCreationExpression(
                                                        SyntaxFactory.InitializerExpression(
                                                            SyntaxKind.ArrayInitializerExpression,
                                                            SyntaxFactory.SingletonSeparatedList<ExpressionSyntax>(
                                                                SyntaxFactory.IdentifierName(
                                                                    SyntaxFactory.Identifier(
                                                                        SyntaxFactory.TriviaList(
                                                                            SyntaxFactory.Whitespace("                ")),
                                                                        "menuItem",
                                                                        SyntaxFactory.TriviaList(
                                                                            SyntaxFactory.LineFeed)))))
                                                        .WithOpenBraceToken(
                                                            SyntaxFactory.Token(
                                                                SyntaxFactory.TriviaList(
                                                                    SyntaxFactory.Whitespace("            ")),
                                                                SyntaxKind.OpenBraceToken,
                                                                SyntaxFactory.TriviaList(
                                                                    SyntaxFactory.LineFeed)))
                                                        .WithCloseBraceToken(
                                                            SyntaxFactory.Token(
                                                                SyntaxFactory.TriviaList(
                                                                    SyntaxFactory.Whitespace("            ")),
                                                                SyntaxKind.CloseBraceToken,
                                                                SyntaxFactory.TriviaList())))
                                                    .WithCloseBracketToken(
                                                        SyntaxFactory.Token(
                                                            SyntaxFactory.TriviaList(),
                                                            SyntaxKind.CloseBracketToken,
                                                            SyntaxFactory.TriviaList(
                                                                SyntaxFactory.LineFeed))))}))))
                            .WithSemicolonToken(
                                SyntaxFactory.Token(
                                    SyntaxFactory.TriviaList(),
                                    SyntaxKind.SemicolonToken,
                                    SyntaxFactory.TriviaList(
                                        SyntaxFactory.LineFeed))))
                        .WithOpenBraceToken(
                            SyntaxFactory.Token(
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.Whitespace("        ")),
                                SyntaxKind.OpenBraceToken,
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.LineFeed)))
                        .WithCloseBraceToken(
                            SyntaxFactory.Token(
                                SyntaxFactory.TriviaList(
                                    SyntaxFactory.Whitespace("        ")),
                                SyntaxKind.CloseBraceToken,
                                SyntaxFactory.TriviaList())));
        }

    }
}
