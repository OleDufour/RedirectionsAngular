using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.ProjectModel;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class ResourceGenerator : GeneratorBase
    {
        private readonly IProjectContext _projectContext;
        private readonly IApplicationInfo _applicationInfo;
        private readonly ICodeGeneratorActionsService _codeGeneratorActionsService;

        public ResourceGenerator(IProjectContext projectContext,
                                  IApplicationInfo applicationInfo,
                                  IModelTypesLocator modelTypesLocator,
                                  ICodeGeneratorActionsService codeGeneratorActionsService,
                                  IServiceProvider serviceProvider)
           : base(applicationInfo, modelTypesLocator, serviceProvider)
        {
            _projectContext = projectContext;
            _applicationInfo = applicationInfo;
            _codeGeneratorActionsService = codeGeneratorActionsService;
        }

        public async Task Generate(CommandLineGeneratorModel model)
        {
            var templateFolders = TemplateFoldersUtilities.GetTemplateFolders(containingProject: typeof(ControllerGenerator).Assembly.GetName().Name,
                                                        applicationBasePath: _applicationInfo.ApplicationBasePath,
                                                        baseFolders: new[] { "ResourceGenerator" },
                                                        projectContext: _projectContext);

            var templateModel = await GetDefaultTemplateModel(model);

            var resourceDesignerCs = $"{templateModel.ResourcesClass}.Designer.cs";
            var resourceResx = $"{templateModel.ResourcesClass}.resx";

            var indexOutputPath = ValidateAndGetOutputPath(model, resourceResx);

            await _codeGeneratorActionsService.AddFileFromTemplateAsync(indexOutputPath, "Resources.cshtml", templateFolders, templateModel);

            var csProjPath = _projectContext.ProjectFullPath;

            var xDocument = XDocument.Parse(File.ReadAllText(csProjPath));

            var isDirty = false;

            // doest content already exsists ?
            var compileElement = xDocument.Descendants("Compile").FirstOrDefault(x => x.Attribute("Update")?.Value == resourceDesignerCs);

            if (compileElement == null)
            {
                compileElement = new XElement("ItemGroup",
                                    new XElement("Compile", new XAttribute("Update", resourceDesignerCs),
                                        new XElement("DesignTime", "True"),
                                        new XElement("AutoGen", "True"),
                                        new XElement("DependentUpon", resourceResx)));

                xDocument.Root.Add(compileElement);
                isDirty = true;
            }

            var embeddedResourceElement = xDocument.Descendants("EmbeddedResource").FirstOrDefault(x => x.Attribute("Update")?.Value == resourceResx);

            if (embeddedResourceElement == null)
            {
                embeddedResourceElement = new XElement("ItemGroup",
                                                       new XElement("EmbeddedResource", new XAttribute("Update", resourceResx),
                                                            new XElement("ExcludeFromManifest", "True"),
                                                            new XElement("CustomToolNamespace", "Resources"),
                                                            new XElement("LastGenOutput", resourceDesignerCs),
                                                            new XElement("Generator", "PublicResXFileCodeGenerator")));

                xDocument.Root.Add(embeddedResourceElement);
                isDirty = true;
            }

            if(isDirty)
            {
                xDocument.Save(csProjPath);
            }
        }
    }
}
