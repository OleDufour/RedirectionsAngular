using Microsoft.VisualStudio.Web.CodeGeneration.EntityFrameworkCore;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class DefaultTemplateModel
    {
        public string NamespaceName { get; set; }
        public string ClassName { get; set; }
        public string RepositoryClassName { get; set; }
        public string ControllerClassName { get; set; }
        public string ModelClass { get; set; }
        public string ResourcesClass { get; set; }
        public IModelMetadata ModelMetadata { get; set; }
        public string AreaName { get; set; }
        public string AreaUrl { get; set; }
        public string ControllerUrl { get; set; }
        public bool PrimaryKeyIsManual { get; set; }
    }
}
