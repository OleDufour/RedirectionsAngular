using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml.Linq;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.ProjectModel;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class JsGenerator : GeneratorBase
    {
        private readonly IProjectContext _projectContext;
        private readonly IApplicationInfo _applicationInfo;
        private readonly ICodeGeneratorActionsService _codeGeneratorActionsService;

        public JsGenerator(IProjectContext projectContext,
                                  IApplicationInfo applicationInfo,
                                  IModelTypesLocator modelTypesLocator,
                                  ICodeGeneratorActionsService codeGeneratorActionsService,
                                  IServiceProvider serviceProvider)
           : base(applicationInfo, modelTypesLocator, serviceProvider)
        {
            _projectContext = projectContext;
            _applicationInfo = applicationInfo;
            _codeGeneratorActionsService = codeGeneratorActionsService;
        }

        public async Task Generate(CommandLineGeneratorModel model)
        {
            var indexOutputPath = ValidateAndGetOutputPath(model, Path.Combine("wwwroot", "js", model.AreaName, model.ModelClass, "index.js"));

            var templateFolders = TemplateFoldersUtilities.GetTemplateFolders(containingProject: typeof(ControllerGenerator).Assembly.GetName().Name,
                                                        applicationBasePath: _applicationInfo.ApplicationBasePath,
                                                        baseFolders: new[] { "JsGenerator" },
                                                        projectContext: _projectContext);

            var templateModel = await GetDefaultTemplateModel(model);

            await _codeGeneratorActionsService.AddFileFromTemplateAsync(indexOutputPath, "index.cshtml", templateFolders, templateModel);

            var csProjPath = _projectContext.ProjectFullPath;

            var xDocument = XDocument.Parse(File.ReadAllText(csProjPath));

            var isDirty = false;

            // doest content already exsists ?
            var embeddedResourceElement = xDocument.Descendants("EmbeddedResource").FirstOrDefault(x => x.Attribute("Include")?.Value == @"wwwroot\**\*");

            if (embeddedResourceElement == null)
            {
                embeddedResourceElement = new XElement("ItemGroup", new XElement("EmbeddedResource", new XAttribute("Include", @"wwwroot\**\*")));

                xDocument.Root.Add(embeddedResourceElement);

                isDirty = true;
            }

            if (isDirty)
            {
                xDocument.Save(csProjPath);
            }
        }
    }
}
