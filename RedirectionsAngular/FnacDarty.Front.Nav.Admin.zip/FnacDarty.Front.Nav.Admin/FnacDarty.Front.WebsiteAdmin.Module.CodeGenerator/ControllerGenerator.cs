using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.Web.CodeGeneration;
using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.ProjectModel;
using Microsoft.VisualStudio.Web.CodeGeneration.DotNet;

namespace FnacDarty.Front.WebsiteAdmin.Module.CodeGenerator
{
    public class ControllerGenerator : GeneratorBase
    {
        private readonly IProjectContext _projectContext;
        private readonly IApplicationInfo _applicationInfo;
        private readonly ICodeGeneratorActionsService _codeGeneratorActionsService;

        public ControllerGenerator(IProjectContext projectContext,
                                   IApplicationInfo applicationInfo,
                                   IModelTypesLocator modelTypesLocator,
                                   ICodeGeneratorActionsService codeGeneratorActionsService,
                                   IServiceProvider serviceProvider)
            : base(applicationInfo, modelTypesLocator, serviceProvider)
        {
            _projectContext = projectContext;
            _applicationInfo = applicationInfo;
            _codeGeneratorActionsService = codeGeneratorActionsService;
        }

        public async Task Generate(CommandLineGeneratorModel model)
        {
            var className = model.ModelClass + "Controller";

            var outputPath = ValidateAndGetOutputPath(model, className + ".cs");

            var templateFolders = TemplateFoldersUtilities.GetTemplateFolders(containingProject: typeof(ControllerGenerator).Assembly.GetName().Name,
                                                        applicationBasePath: _applicationInfo.ApplicationBasePath,
                                                        baseFolders: new[] { "ControllerGenerator" },
                                                        projectContext: _projectContext);

            var templateModel = await GetDefaultTemplateModel(model);
            
            templateModel.ClassName = className;

            await _codeGeneratorActionsService.AddFileFromTemplateAsync(outputPath, "Controller.cshtml", templateFolders, templateModel);
        }
    }
}
